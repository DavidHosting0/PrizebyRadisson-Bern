import{b as ce,S as A,P as F,c as W,d as ae,A as Me,e as Q,f as Le,g as we,T as me,h as Re,s as ze}from"./storage-DTWcLCTt.js";import{l as ne,w as oe,i as J,g as $,a as _e,b as Fe,p as De,c as $e,d as Pe,t as be,B as Ne,e as He,f as qe}from"./bernticket-api-DAinuR-j.js";const ie=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function Oe(t){const e=parseInt(t,10);return Number.isFinite(e)?e%100===13:!0}function je(t){if(Oe(t))return null;const e=parseInt(t,10);if(!Number.isFinite(e))return null;if(e>=1&&e<=17)return-1;if(e>=21&&e<=37)return 0;for(let n=1;n<=ie.length;n++){const[o,r]=ie[n-1];if(e>=o&&e<=r)return n}return null}function Ge(){const t=[];for(let e=1;e<=17;e++)e%100!==13&&t.push(String(e));for(let e=21;e<=37;e++)t.push(String(e));for(const[e,n]of ie)for(let o=e;o<=n;o++)o%100!==13&&t.push(String(o));return t}function Ue(t,e){const n=parseInt(t,10),o=parseInt(e,10),r=Number.isFinite(n),a=Number.isFinite(o);return r&&a?n-o:r&&!a?-1:!r&&a?1:t.localeCompare(e)}function We(t){return t==null?"—":t===-2?"Lobby":t===-1?"Floor -1":t===8?"Rooftop Bar":`Floor ${t}`}let q=$("de");const k="prize-panel-chat-toast",fe="prize-panel-chat-toast-style",Ve=8e3,Ye=7e3;function Xe(t){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(t)}function Ke(t){return t==="/r"||t.startsWith("/r/")}function Ze(t,e=72){const n=t.replace(/\s+/g," ").trim();return n.length<=e?n:`${n.slice(0,e-1)}…`}function Qe(){if(document.getElementById(fe))return;const t=document.createElement("style");t.id=fe,t.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${k}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${W} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${ae};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${k}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${k} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${k} .pb-ct-body{min-width:0;flex:1;}
    #${k} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${Me};margin-bottom:2px;
    }
    #${k} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${k} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${k} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${k} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(t)}let V=null;function R(t=!0){const e=document.getElementById(k);if(e){if(V&&(window.clearTimeout(V),V=null),!t){e.remove();return}e.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>e.remove(),220)}}function Je(){try{const t=window.AudioContext||window.webkitAudioContext;if(!t)return;const e=new t,n=e.currentTime,o=e.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(e.destination);const r=(a,i,s)=>{const l=e.createOscillator(),c=e.createGain();l.type="sine",l.frequency.setValueAtTime(a,i),c.gain.setValueAtTime(1e-4,i),c.gain.exponentialRampToValueAtTime(.9,i+.015),c.gain.exponentialRampToValueAtTime(1e-4,i+s),l.connect(c),c.connect(o),l.start(i),l.stop(i+s+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{e.close()},600)}catch{}}function et(t,e){Qe(),R(!1);const n=document.createElement("div");n.id=k,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),s=r.querySelector(".pb-ct-preview");a.textContent=q.toast.eyebrow,i.textContent=J(q.toast.newMessageFrom,{author:t}),s.textContent=Ze(e);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",q.toast.close),l.textContent="×",l.addEventListener("click",c=>{c.stopPropagation(),R(!0)}),n.addEventListener("click",()=>R(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),Je(),V=window.setTimeout(()=>{R(!0)},Ye)}function tt(){return new Promise(t=>{try{chrome.runtime.sendMessage({type:F.latestChat},e=>{if(chrome.runtime.lastError){t({ok:!1});return}t(e??{ok:!1})})}catch{t({ok:!1})}})}function nt(t){let e=!1,n=null,o=!0;ne().then(s=>{q=$(s)});const r=oe(s=>{q=$(s)});ce(A.chatNotificationsEnabled,!0).then(s=>{o=s});try{chrome.storage.onChanged.addListener((s,l)=>{if(l==="local"&&s[A.chatNotificationsEnabled]){const c=s[A.chatNotificationsEnabled].newValue;o=c===void 0?!0:!!c,o||R(!1)}})}catch{}const a=async()=>{var s,l,c;if(!e)try{if(!o)return;const u=await tt();if(!u.ok)return;const b=u.msg;if(!(b!=null&&b.id))return;if(n===null){n=b.id;return}if(b.id===n||(n=b.id,(s=b.author)!=null&&s.id&&u.meId&&b.author.id===u.meId)||t()||Xe(window.location.pathname)||Ke(window.location.pathname))return;const y=((c=(l=b.author)==null?void 0:l.name)==null?void 0:c.trim())||"Team";et(y,b.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},Ve);return()=>{e=!0,window.clearInterval(i),r(),R(!1)}}let d=$("de");const m="prize-bt-checkin-host",ee="prize-bt-checkin-style",C="prize-bt-fallback-bar",f="prize-bt-create-dialog";function ot(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function rt(){const t=window.location.hash||"",e=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const r of e){const a=t.match(r);if(a)return a[1].replace(/^0+/,"")||a[1]}for(const r of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const a=(r.textContent||"").trim();if(/^\d{6,}$/.test(a))return a.replace(/^0+/,"")||a}const n=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),o=((n==null?void 0:n.textContent)||"").match(/\b(\d{6,})\b/);return o?o[1].replace(/^0+/,"")||o[1]:null}function ke(){const t=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="Toolbar"]','[id*="checkinToolbar"]',".sapUxAPObjectPageFloatingFooter.sapMTB",".sapUxAPObjectPageFloatingFooter",".sapFDynamicPageFooter .sapMTB"];for(const e of t){const n=document.querySelector(e);if(n)return n}return null}function de(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}const at={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function ge(t){const e=t.trim().replace(/\s+/g," ");if(!e)return null;const n=e.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=e.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=e.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=at[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(e);if(!Number.isNaN(a)){const i=new Date(a),s=i.getFullYear(),l=String(i.getMonth()+1).padStart(2,"0"),c=String(i.getDate()).padStart(2,"0");if(s>=2e3)return`${s}-${l}-${c}`}return null}function z(t,e){const n=t.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!e.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const u=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(u&&!e.test(u))return u}a=a.parentElement}}return null}function it(){return new Date().toISOString().slice(0,10)}function st(){const t=new Date;return t.setDate(t.getDate()+1),t.toISOString().slice(0,10)}function lt(){const t=de()||document.body,e=z(t,/^Arrival\s*Date$/i)||z(t,/^Anreise(datum)?$/i),n=z(t,/^Departure\s*Date$/i)||z(t,/^Abreise(datum)?$/i),o=e&&ge(e)||it(),r=n&&ge(n)||st();return{from:o,to:r}}function ct(){const t=de()||document.body,e=document.querySelector('[id*="FolioPaxTypes"]')||t;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=z(e,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of e.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function dt(){const t=de()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=z(t,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const e=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of e){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function pt(t){const e=lt();return{guestName:dt(),bookingNumber:t,from:e.from,to:e.to,ticketsAmount:ct()}}function ut(){const t=document.getElementById(ee);t&&t.remove();const e=document.createElement("style");e.id=ee,e.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${m}),
    .sapMTBSpacerFlex:has(#${m}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${m}.sapMBarChild,
    #${m}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${m} *{box-sizing:border-box;}
    #${m} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${m} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);font-weight:700;
      letter-spacing:.04em;line-height:1.2;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.25rem;
      padding:0.35rem 0.6rem;
      min-width:0;text-align:center;
    }
    #${m} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${m} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${m} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${m} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${m} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${m} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Fallback strip when no toolbar — still flat / SAP-ish */
    #${C}{
      position:fixed;left:50%;bottom:4.5rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.5rem;
      padding:0.35rem 0.75rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      color:#32363a;
      background:#fff;
      border:1px solid #d9d9d9;
      border-radius:0.375rem;
      box-shadow:0 0.125rem 0.5rem rgba(0,0,0,.12);
    }
    #${C} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.04em;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.25rem;padding:0.35rem 0.6rem;
    }
    #${C} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      height:2rem;padding:0 0.75rem;border-radius:0.375rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${f}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${f} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${f} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${f} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${f} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${f} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${f} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${f} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${f} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${f} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${f} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${f} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${f} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${f} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${f} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${f} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(e)}function _(){var t;(t=document.getElementById(f))==null||t.remove()}function mt(t){var o,r;(o=document.getElementById(C))==null||o.remove();let e=document.getElementById(m);if(e&&t.contains(e))return e;e==null||e.remove(),e=document.createElement("div"),e.id=m,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",d.emmaBt.brand);const n=t.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||t.querySelector(".sapMTBSpacer");if(n)n.appendChild(e);else{e.className="sapMBarChild";const a=((r=t.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...t.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===t?t.insertBefore(e,a):t.appendChild(e)}return e}function bt(){var e;(e=document.getElementById(m))==null||e.remove();let t=document.getElementById(C);return t||(t=document.createElement("div"),t.id=C,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",d.emmaBt.brand),document.documentElement.appendChild(t),t)}function T(t,e){t.innerHTML=e}function B(t){return`<span class="pb-bt-label">${g(d.emmaBt.brand)}</span>${t}`}async function ft(t){try{await navigator.clipboard.writeText(t)}catch{}}function he(t,e){const n=t.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{ft(e).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=d.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function gt(t,e,n,o){_();const r=document.createElement("div");r.id=f,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${S(d.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${g(d.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${S(d.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${g(d.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${S(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${g(d.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${S(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${g(d.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${S(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${g(d.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${S(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${g(d.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${g(d.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${g(d.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(l=>{l.addEventListener("click",()=>_())});const s=l=>{l.key==="Escape"&&(_(),window.removeEventListener("keydown",s))};window.addEventListener("keydown",s),i.addEventListener("click",()=>{(async()=>{const l=r.querySelector(".pb-bt-dlg-name"),c=r.querySelector(".pb-bt-dlg-from"),u=r.querySelector(".pb-bt-dlg-to"),b=r.querySelector(".pb-bt-dlg-amt"),y=(l==null?void 0:l.value.trim())||"";if(!y){a.hidden=!1,a.textContent=d.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=d.common.ellipsis,a.hidden=!0;try{const L=await Pe({guestName:y,bookingNumber:e,validFrom:be((c==null?void 0:c.value)||n.from),validTo:be((u==null?void 0:u.value)||n.to),ticketsAmount:Math.max(1,parseInt((b==null?void 0:b.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});_(),o($e(L))}catch(L){if(L instanceof Ne&&L.code===He){const pe=window.prompt(d.emmaBt.twoFaPrompt);if(pe)try{await qe(pe),i.disabled=!1,i.textContent=d.emmaBt.create,i.click();return}catch(ue){a.hidden=!1,a.textContent=ue instanceof Error?ue.message:d.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=d.emmaBt.create;return}}a.hidden=!1,a.textContent=L instanceof Error?L.message:d.emmaBt.error,i.disabled=!1,i.textContent=d.emmaBt.create}})()})}let v=null,O=null,G=0;async function se(t,e,n){var a,i;const o=++G,r=await _e();if(o===G){if(!r.access){T(t,B(`<span class="pb-bt-muted">${g(d.emmaBt.loginHint)}</span>`));return}T(t,B(`<span class="pb-bt-muted">${g(d.emmaBt.loading)}</span>`));try{const s=await Fe(e);if(o!==G)return;const l=De(s,e),c=$e(l),u=d.bernticket.copyCode;if(l&&c){T(t,B(`<button type="button" class="pb-bt-code" title="${S(u)}">${g(c)}</button>`)),he(t,c);return}if(l&&!c){const y=J(d.emmaBt.noCode,{status:l.status});T(t,B(`<span class="pb-bt-muted">${g(y)}</span>`));return}const b=pt(e);T(t,B(`<button type="button" class="pb-bt-btn pb-bt-open-create">${g(d.emmaBt.openCreate)}</button>`)),(a=t.querySelector(".pb-bt-open-create"))==null||a.addEventListener("click",()=>{gt(t,e,b,y=>{y?(T(t,B(`<button type="button" class="pb-bt-code" title="${S(u)}">${g(y)}</button>`)),he(t,y)):(v=null,se(t,e,!0))})})}catch(s){if(o!==G)return;T(t,B(`<span class="pb-bt-muted">${g(s instanceof Error?s.message:d.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${g(d.emmaBt.retry)}</button>`)),(i=t.querySelector(".pb-bt-retry"))==null||i.addEventListener("click",()=>{v=null,se(t,e)})}}}function g(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function S(t){return g(t).replace(/'/g,"&#39;")}function D(){O&&window.clearTimeout(O),O=window.setTimeout(()=>{Ee()},350)}function Ce(t){return document.documentElement.contains(t)}async function Ee(){var o,r,a,i;if(!ot()){(o=document.getElementById(m))==null||o.remove(),(r=document.getElementById(C))==null||r.remove(),_(),v=null;return}ut();const t=rt(),e=ke();if(!t&&!e){(a=document.getElementById(m))==null||a.remove(),(i=document.getElementById(C))==null||i.remove(),v=null;return}const n=e?mt(e):bt();if(!t){T(n,B(`<span class="pb-bt-muted">${g(d.emmaBt.noBooking)}</span>`)),v=null,n.dataset.bound="";return}if(t===v&&n.dataset.bound===t&&Ce(n))if(e&&!e.contains(n))v=null;else return;v=t,n.dataset.bound=t,await se(n,t)}function ht(){ne().then(e=>{d=$(e),v=null,D()}),oe(e=>{d=$(e),v=null,D()}),Ee(),window.addEventListener("hashchange",()=>{v=null,D()});const t=new MutationObserver(e=>{let n=!1;for(const a of e){const i=a.target;if(!(i instanceof Element&&(i.id===m||i.id===C||i.id===ee||i.id===f||i.closest("[data-prize-bernticket]")))){n=!0;break}}if(!n)return;const o=ke(),r=document.getElementById(m)||document.getElementById(C);r&&!Ce(r)&&(v=null),o&&(r==null?void 0:r.id)===m&&!o.contains(r)&&(v=null),o&&!r&&(v=null),D()});t.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((e,n)=>{n==="local"&&(e.btAccessToken||e.btRefreshToken)&&(v=null,D())})}catch{}return()=>{var e,n,o;t.disconnect(),O&&window.clearTimeout(O),(e=document.getElementById(m))==null||e.remove(),(n=document.getElementById(C))==null||n.remove(),(o=document.getElementById(ee))==null||o.remove(),_()}}let x=$("de");const p="prize-ra-host",te="prize-ra-style",P=Ge().sort(Ue);function xt(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Te(){const t=window.location.hash||"",e=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of e){const o=t.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o.replace(/^0+/,"")||o}return null}function Y(t){if(t.classList.contains("sapUiHiddenPlaceholder"))return!1;const e=t.getBoundingClientRect();return e.width>2&&e.height>2}function Be(){var a;const t=['[id$="tms.checkinheaderContent"]','[id*="tms.checkinheaderContent"]','[id*="checkinheaderContent"]','[id$="tms.reservationheaderContent"]','[id*="reservationheaderContent"]','[id*="HeaderContent"][id*="tms."]','[id*="CheckInDetail"][id*="headerContent"]','[id*="ReservationDetail"][id*="headerContent"]','[id*="zey_tms_rs"][id*="headerContent"]'];for(const i of t){const s=document.querySelector(i);if(s&&Y(s))return s}const e=document.querySelector('[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"])')||document.querySelector('[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"])')||document.querySelector('[id$="tms.roomid.valuehelp"]');if(!e||!Y(e))return null;const n=e.closest('[id*="Grid-wrapperfor"]');if(n){const i=n.querySelector(":scope > .sapMVBox, :scope > .sapMFlexBox");if(i&&Y(i))return i}let o=e;for(let i=0;i<10&&o;i++){const s=(o.innerText||"").replace(/\s+/g," ");if(o.classList.contains("sapMVBox")&&/Room/i.test(s)&&/Nights/i.test(s))return o;o=o.parentElement}const r=(a=e.closest(".sapMHBox"))==null?void 0:a.parentElement;return r instanceof HTMLElement?r:null}function re(t){const e=t.replace(/[^\d]/g,"");return e?String(parseInt(e,10)):""}function le(){var e;const t=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of t){const o=document.querySelector(n),r=(e=o==null?void 0:o.value)==null?void 0:e.trim();if(r){const a=re(r);if(a)return a}}return null}function vt(){const t=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const e of t){const n=document.querySelector(e);if(n&&Y(n))return n}for(const e of t){const n=document.querySelector(e);if(n)return n}return null}function yt(t,e){const n=re(t);if(!n)return t;const o=e&&/^\d+$/.test(e.trim())?e.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}function wt(t){const e=re(t);return P.findIndex(n=>n===e)}function Se(t,e,n){const o=n?re(n):null;let r=0;if(o){const l=wt(o);l>=0&&(r=l)}else t&&(r=[...t].reduce((c,u)=>c+u.charCodeAt(0),0)%P.length);e==="higher"?r=Math.min(P.length-1,r+1):e==="lower"?r=Math.max(0,r-1):e==="extra_bed"&&(r=Math.min(P.length-1,r+2));const a=P[r]||"101",i=je(a),s={default:x.emmaRoom.labelDefault,higher:x.emmaRoom.labelHigher,lower:x.emmaRoom.labelLower,extra_bed:x.emmaRoom.labelExtraBed};return{roomNumber:a,floor:i,kind:e,label:s[e]}}function $t(){const t=document.getElementById(te);t&&t.remove();const e=document.createElement("style");e.id=te,e.textContent=`
    #${p}{
      box-sizing:border-box;
      flex:0 0 auto;
      order:-1;
      margin:0 10px 8px 0;
      width:min(220px,100%);
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:linear-gradient(180deg,#ffffff,#f8fafc);
      border:1px solid rgba(45,58,79,.14);
      border-radius:14px;
      box-shadow:0 6px 20px rgba(15,23,42,.1);
      padding:8px 10px;
      z-index:5;
      pointer-events:auto;
      align-self:flex-start;
    }
    #${p} *{box-sizing:border-box;}
    #${p} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:6px;
      margin-bottom:6px;
    }
    #${p} .pb-ra-title{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:6px;
    }
    #${p} .pb-ra-dot{
      width:7px;height:7px;border-radius:999px;background:#3b6fa0;
      box-shadow:0 0 0 3px rgba(59,111,160,.16);
    }
    #${p} .pb-ra-badge{
      font-size:9px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:2px 7px;white-space:nowrap;
    }
    #${p} .pb-ra-main{
      display:flex;align-items:center;gap:8px;
    }
    #${p} .pb-ra-room{
      flex:1;min-width:0;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:20px;font-weight:800;letter-spacing:.04em;line-height:1.1;
      color:#1a2332;
    }
    #${p} .pb-ra-meta{
      font-size:10px;color:#64748b;margin-top:2px;font-weight:500;
      font-family:var(--sapFontFamily,"72",system-ui,sans-serif);
      letter-spacing:0;
    }
    #${p} .pb-ra-actions{
      display:flex;align-items:center;gap:4px;flex-shrink:0;
    }
    #${p} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:30px;height:30px;border-radius:9px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
      transition:background .12s ease,border-color .12s ease,transform .12s ease;
    }
    #${p} .pb-ra-btn:hover{background:#f1f5f9;border-color:#94a3b8;}
    #${p} .pb-ra-btn:active{transform:scale(.96);}
    #${p} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${p} .pb-ra-btn.pb-ra-accept:hover{background:#166534;border-color:#166534;}
    #${p} .pb-ra-btn svg{width:15px;height:15px;display:block;}
    #${p} .pb-ra-menu{
      margin-top:8px;padding-top:8px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:4px;
    }
    #${p} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${p} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:8px;padding:6px 8px;text-align:left;font-size:11px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${p} .pb-ra-opt:hover{background:#f8fafc;border-color:#cbd5e1;}
    #${p} .pb-ra-status{
      margin-top:6px;font-size:10px;font-weight:600;color:#15803d;
    }
    #${p} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${p} .pb-ra-note{
      margin-top:4px;font-size:9px;color:#94a3b8;line-height:1.3;
    }
  `,document.documentElement.appendChild(e)}function kt(t){let e=document.getElementById(p);return e&&t.contains(e)||(e==null||e.remove(),e=document.createElement("div"),e.id=p,e.setAttribute("data-prize-room-assign","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",x.emmaRoom.title),t.classList.contains("sapMFlexBox")||t.querySelector(":scope > .sapMFlexItem")?t.insertBefore(e,t.firstChild):t.prepend(e)),e}function Ct(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function Et(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>'}let w=null,j=null,h=null,M=!1,N="",X=!1;function Tt(t){const e=vt();if(!e)return!1;const n=e.value,o=yt(t,n);return e.focus(),e.value=o,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),e.blur(),!0}function K(t){var a,i;if(!h)return;t.setAttribute("aria-label",x.emmaRoom.title);const e=We(h.floor),n=N?`<div class="pb-ra-status${X?" pb-ra-warn":""}">${E(N)}</div>`:"",o=x.emmaRoom.accept,r=x.emmaRoom.edit;t.innerHTML=`<div class="pb-ra-top"><span class="pb-ra-title"><span class="pb-ra-dot" aria-hidden="true"></span>${E(x.emmaRoom.title)}</span><span class="pb-ra-badge">${E(h.label)}</span></div><div class="pb-ra-main"><div><div class="pb-ra-room">${E(h.roomNumber)}</div><div class="pb-ra-meta">${E(e)}</div></div><div class="pb-ra-actions"><button type="button" class="pb-ra-btn pb-ra-accept" title="${U(o)}" aria-label="${U(o)}">${Ct()}</button><button type="button" class="pb-ra-btn pb-ra-edit" title="${U(r)}" aria-label="${U(r)}" aria-expanded="${M}">${Et()}</button></div></div><div class="pb-ra-menu${M?"":" pb-ra-hidden"}"><button type="button" class="pb-ra-opt" data-kind="higher">${E(x.emmaRoom.higher)}</button><button type="button" class="pb-ra-opt" data-kind="lower">${E(x.emmaRoom.lower)}</button><button type="button" class="pb-ra-opt" data-kind="extra_bed">${E(x.emmaRoom.extraBed)}</button></div>`+n+`<div class="pb-ra-note">${E(x.emmaRoom.previewNote)}</div>`,(a=t.querySelector(".pb-ra-accept"))==null||a.addEventListener("click",()=>{if(!h)return;const s=Tt(h.roomNumber);N=s?J(x.emmaRoom.applied,{room:h.roomNumber}):J(x.emmaRoom.appliedNoField,{room:h.roomNumber}),X=!s,M=!1,K(t)}),(i=t.querySelector(".pb-ra-edit"))==null||i.addEventListener("click",()=>{M=!M,K(t)}),t.querySelectorAll(".pb-ra-opt").forEach(s=>{s.addEventListener("click",()=>{const l=s.dataset.kind||"default",c=Te(),u=le();h=Se(c,l,(h==null?void 0:h.roomNumber)||u),N="",X=!1,M=!1,K(t)})})}function E(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function U(t){return E(t).replace(/'/g,"&#39;")}function H(){j&&window.clearTimeout(j),j=window.setTimeout(()=>{Ie()},350)}async function Ie(){var r,a;if(!xt()){(r=document.getElementById(p))==null||r.remove(),w=null;return}const t=Be(),e=Te();if(!t||!e){(a=document.getElementById(p))==null||a.remove(),w=null,h=null;return}$t();const n=kt(t);if(!t.contains(n)){w=null,H();return}const o=`${e}:${le()||""}`;if(o!==w||!h||!n.querySelector(".pb-ra-room")){const i=!w||!w.startsWith(`${e}:`);w=o,(i||!h)&&(M=!1,N="",X=!1,h=Se(e,"default",le())),K(n)}}function Bt(){ne().then(e=>{x=$(e),w=null,H()}),oe(e=>{x=$(e),w=null,H()}),Ie(),window.addEventListener("hashchange",()=>{w=null,h=null,H()});const t=new MutationObserver(e=>{let n=!1;for(const a of e){const i=a.target;if(!(i instanceof Element&&(i.id===p||i.id===te||i.closest("[data-prize-room-assign]")))){n=!0;break}}if(!n)return;const o=Be(),r=document.getElementById(p);r&&o&&!o.contains(r)&&(w=null),o&&!r&&(w=null),H()});return t.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var e,n;t.disconnect(),j&&window.clearTimeout(j),(e=document.getElementById(p))==null||e.remove(),(n=document.getElementById(te))==null||n.remove()}}const xe="prize-panel-host";let I=$("de");function Ae(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function Z(t,e,n){const o=`${Q}px 0 0 ${Q}px`;n?(t.style.width="0",t.style.opacity="0",t.style.pointerEvents="none",e.style.display="flex",e.innerHTML=Ae(),e.title=I.inject.openPanel,e.setAttribute("aria-label",I.inject.openPanel),e.setAttribute("aria-expanded","false")):(t.style.width=`${we}px`,t.style.opacity="1",t.style.pointerEvents="auto",e.style.display="none",e.title=I.inject.panelTitle,e.setAttribute("aria-expanded","true")),t.style.borderRadius=o,e.style.borderRadius=o}async function ve(t,e,n){var i;const r=!await ce(A.panelCollapsed);await ze({[A.panelCollapsed]:r}),Z(t,e,r);const a=t.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?F.collapsed:F.expanded},"*")}function ye(){if(document.getElementById(xe))return;let t=!1,e=!0;const n=()=>t&&!e,o=`${Q}px 0 0 ${Q}px`,r=document.createElement("div");r.id=xe,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${Le}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:W,border:`1px solid ${ae}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=I.inject.panelTitle,Object.assign(i.style,{width:`${we}px`,height:"100%",border:"none",display:"block",background:W}),a.appendChild(i);const s=document.createElement("button");s.id="prize-panel-tab",s.type="button",Object.assign(s.style,{width:`${me}px`,height:`${Re}px`,minWidth:`${me}px`,border:`1px solid ${ae}`,borderRight:"none",background:`linear-gradient(180deg, ${W} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),s.innerHTML=Ae(),s.addEventListener("mouseenter",()=>{s.style.filter="brightness(1.12)"}),s.addEventListener("mouseleave",()=>{s.style.filter=""}),s.addEventListener("click",()=>{ve(a,s)}),r.appendChild(a),r.appendChild(s),document.documentElement.appendChild(r),ce(A.panelCollapsed).then(l=>{e=l,Z(a,s,l)}),window.addEventListener("message",l=>{var c,u,b,y;((c=l.data)==null?void 0:c.type)===F.toggle&&ve(a,s),((u=l.data)==null?void 0:u.type)===F.chatOpen&&(t=!0,n()&&((b=document.getElementById("prize-panel-chat-toast"))==null||b.remove())),((y=l.data)==null?void 0:y.type)===F.chatClosed&&(t=!1)}),chrome.storage.onChanged.addListener((l,c)=>{c==="local"&&l[A.panelCollapsed]&&(e=!!l[A.panelCollapsed].newValue)}),nt(n),ht(),Bt(),ne().then(l=>{I=$(l),Z(a,s,e),i.title=I.inject.panelTitle}),oe(l=>{I=$(l),Z(a,s,e),i.title=I.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",ye):ye();
