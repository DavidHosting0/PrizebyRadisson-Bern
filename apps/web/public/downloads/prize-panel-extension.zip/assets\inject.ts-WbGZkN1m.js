import{b as _e,S as O,P as Z,c as me,d as Me,A as St,e as he,f as Et,g as nt,T as Ne,h as It,s as Bt}from"./storage-DTWcLCTt.js";import{l as de,w as ue,i as ot,g as S,a as rt,b as Mt,p as Lt,c as at,d as At,t as Oe,B as Rt,e as qt,f as Dt,h as Te}from"./bernticket-api-B5xltN15.js";const Ue=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function _t(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function it(e){if(_t(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=Ue.length;n++){const[o,r]=Ue[n-1];if(t>=o&&t<=r)return n}return null}function zt(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let ae=S("de");const q="prize-panel-chat-toast",je="prize-panel-chat-toast-style",Ht=8e3,Pt=7e3;function Ft(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function Nt(e){return e==="/r"||e.startsWith("/r/")}function Ot(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function Ut(){if(document.getElementById(je))return;const e=document.createElement("style");e.id=je,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${q}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${me} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${Me};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${q}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${q} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${q} .pb-ct-body{min-width:0;flex:1;}
    #${q} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${St};margin-bottom:2px;
    }
    #${q} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${q} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${q} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${q} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let fe=null;function Y(e=!0){const t=document.getElementById(q);if(t){if(fe&&(window.clearTimeout(fe),fe=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function jt(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,s,i)=>{const l=t.createOscillator(),c=t.createGain();l.type="sine",l.frequency.setValueAtTime(a,s),c.gain.setValueAtTime(1e-4,s),c.gain.exponentialRampToValueAtTime(.9,s+.015),c.gain.exponentialRampToValueAtTime(1e-4,s+i),l.connect(c),c.connect(o),l.start(s),l.stop(s+i+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function Gt(e,t){Ut(),Y(!1);const n=document.createElement("div");n.id=q,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),s=r.querySelector(".pb-ct-title"),i=r.querySelector(".pb-ct-preview");a.textContent=ae.toast.eyebrow,s.textContent=ot(ae.toast.newMessageFrom,{author:e}),i.textContent=Ot(t);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",ae.toast.close),l.textContent="×",l.addEventListener("click",c=>{c.stopPropagation(),Y(!0)}),n.addEventListener("click",()=>Y(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),jt(),fe=window.setTimeout(()=>{Y(!0)},Pt)}function Vt(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:Z.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function Wt(e){let t=!1,n=null,o=!0;de().then(i=>{ae=S(i)});const r=ue(i=>{ae=S(i)});_e(O.chatNotificationsEnabled,!0).then(i=>{o=i});try{chrome.storage.onChanged.addListener((i,l)=>{if(l==="local"&&i[O.chatNotificationsEnabled]){const c=i[O.chatNotificationsEnabled].newValue;o=c===void 0?!0:!!c,o||Y(!1)}})}catch{}const a=async()=>{var i,l,c;if(!t)try{if(!o)return;const p=await Vt();if(!p.ok)return;const f=p.msg;if(!(f!=null&&f.id))return;if(n===null){n=f.id;return}if(f.id===n||(n=f.id,(i=f.author)!=null&&i.id&&p.meId&&f.author.id===p.meId)||e()||Ft(window.location.pathname)||Nt(window.location.pathname))return;const g=((c=(l=f.author)==null?void 0:l.name)==null?void 0:c.trim())||"Team";Gt(g,f.body??"")}catch{}};a();const s=window.setInterval(()=>{a()},Ht);return()=>{t=!0,window.clearInterval(s),r(),Y(!1)}}const st=300*1e3,j=new Map,be=new Map;function J(e){return e.replace(/^0+/,"")||e}function Le(e){const t=j.get(J(e));return!t||Date.now()-t.at>=st?null:{code:t.code}}function Yt(e,t){j.set(J(e),{code:t,at:Date.now()})}function ze(){j.clear(),be.clear()}async function lt(e){const t=J(e),n=j.get(t);if(n&&Date.now()-n.at<st)return n.code;let o=be.get(t);return o||(o=(async()=>{try{const r=await rt();if(!(r!=null&&r.access))return j.set(t,{code:null,at:Date.now()}),null;const a=await Mt(t),s=Lt(a,t),i=at(s);return j.set(t,{code:i,at:Date.now()}),i}catch{return j.set(t,{code:null,at:Date.now()}),null}finally{be.delete(t)}})(),be.set(t,o)),o}async function Xt(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}const Kt={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function G(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const s=Kt[r[1].toLowerCase()];if(s)return`${r[3]}-${s}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const s=new Date(a),i=s.getFullYear(),l=String(s.getMonth()+1).padStart(2,"0"),c=String(s.getDate()).padStart(2,"0");if(i>=2e3)return`${i}-${l}-${c}`}return null}function ct(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Zt(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function dt(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:G(e);return!!(t&&t===ct())}let b=S("de");const h="prize-bt-checkin-host",ye="prize-bt-checkin-style",$="prize-bt-fallback-bar",x="prize-bt-create-dialog";function Jt(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function ut(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function ve(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function Qt(){const e=ve();if(e)return e;if(ut())return null;for(const o of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r.replace(/^0+/,"")||r}const t=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),n=((t==null?void 0:t.textContent)||"").match(/\b(\d{6,})\b/);return n?n[1].replace(/^0+/,"")||n[1]:null}function en(){return!!document.querySelector(['.sapUiLocalBusyIndicator:not([style*="display: none"])',".sapUiBusy",".sapMBusyDialog",".sapUiBlockLayer",".sapUiBLy",".sapUiLocalBusyIndicatorAnimation",'[class*="BusyIndicator"]:not([style*="display: none"])'].join(", "))}function Ge(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function He(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function X(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let s=0;s<6&&a;s++){const i=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of i)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const p=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(p&&!t.test(p))return p}a=a.parentElement}}return null}function tn(){const e=He()||document.body,t=X(e,/^Arrival\s*Date$/i)||X(e,/^Anreise(datum)?$/i),n=X(e,/^Departure\s*Date$/i)||X(e,/^Abreise(datum)?$/i),o=t&&G(t)||ct(),r=n&&G(n)||Zt();return{from:o,to:r}}function nn(){const e=He()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=X(t,r);if(a==null)continue;const s=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(s)||(n+=s,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function on(){const e=He()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=X(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function rn(e){const t=tn();return{guestName:on(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:nn()}}function an(){const e=document.getElementById(ye);e&&e.remove();const t=document.createElement("style");t.id=ye,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${h}),
    .sapMTBSpacerFlex:has(#${h}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${h}.sapMBarChild,
    #${h}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${h} *{box-sizing:border-box;}
    #${h} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${h} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:1.35rem;font-weight:700;
      letter-spacing:.05em;line-height:1.15;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.3rem;
      padding:0.45rem 0.85rem;
      min-width:0;text-align:center;
    }
    #${h} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${h} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${h} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${h} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${h} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${h} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${$}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.45rem;
      padding:0.35rem 0.6rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.3rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${$} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${$} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${$} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.05em;
      font-size:1.25rem;line-height:1.15;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.3rem;padding:0.35rem 0.7rem;
    }
    #${$} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${$} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${x}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${x} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${x} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${x} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${x} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${x} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${x} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${x} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${x} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${x} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${x} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${x} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${x} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${x} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${x} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${x} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function K(){var e;(e=document.getElementById(x))==null||e.remove()}function Ve(e){var o,r;(o=document.getElementById($))==null||o.remove();let t=document.getElementById(h);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=h,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",b.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(s=>/check\s*in/i.test(s.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function sn(){var t;(t=document.getElementById(h))==null||t.remove();let e=document.getElementById($);return e||(e=document.createElement("div"),e.id=$,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",b.emmaBt.brand),document.documentElement.appendChild(e),e)}function ee(e,t){e.innerHTML=t}function te(e){return`<span class="pb-bt-label">${T(b.emmaBt.brand)}</span>${e}`}async function ln(e){try{await navigator.clipboard.writeText(e)}catch{}}function cn(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{ln(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=b.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function dn(e,t,n,o){K();const r=document.createElement("div");r.id=x,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${U(b.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${T(b.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${U(b.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${T(b.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${U(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${T(b.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${U(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${T(b.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${U(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${T(b.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${U(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${T(b.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${T(b.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${T(b.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),s=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(l=>{l.addEventListener("click",()=>K())});const i=l=>{l.key==="Escape"&&(K(),window.removeEventListener("keydown",i))};window.addEventListener("keydown",i),s.addEventListener("click",()=>{(async()=>{const l=r.querySelector(".pb-bt-dlg-name"),c=r.querySelector(".pb-bt-dlg-from"),p=r.querySelector(".pb-bt-dlg-to"),f=r.querySelector(".pb-bt-dlg-amt"),g=(l==null?void 0:l.value.trim())||"";if(!g){a.hidden=!1,a.textContent=b.emmaBt.guestNameMissing;return}s.disabled=!0,s.textContent=b.common.ellipsis,a.hidden=!0;try{const B=await At({guestName:g,bookingNumber:t,validFrom:Oe((c==null?void 0:c.value)||n.from),validTo:Oe((p==null?void 0:p.value)||n.to),ticketsAmount:Math.max(1,parseInt((f==null?void 0:f.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});K(),o(at(B))}catch(B){if(B instanceof Rt&&B.code===qt){const k=window.prompt(b.emmaBt.twoFaPrompt);if(k)try{await Dt(k),s.disabled=!1,s.textContent=b.emmaBt.create,s.click();return}catch(v){a.hidden=!1,a.textContent=v instanceof Error?v.message:b.emmaBt.twoFaFailed,s.disabled=!1,s.textContent=b.emmaBt.create;return}}a.hidden=!1,a.textContent=B instanceof Error?B.message:b.emmaBt.error,s.disabled=!1,s.textContent=b.emmaBt.create}})()})}let A=null,W=null,ie=null,pe=0;async function xe(e,t,n){var l,c;const o=++pe,r=await rt();if(o!==pe)return;if(!r.access){ee(e,te(`<span class="pb-bt-muted">${T(b.emmaBt.loginHint)}</span>`)),e.dataset.fetched="1";return}const a=b.bernticket.copyCode,s=p=>{ee(e,te(`<button type="button" class="pb-bt-code" title="${U(a)}">${T(p)}</button>`)),cn(e,p),e.dataset.fetched="1"},i=Le(t);if(i!=null&&i.code){s(i.code);return}if(!(e.dataset.bound===t&&e.dataset.fetched==="1"&&e.querySelector(".pb-bt-code, .pb-bt-open-create, .pb-bt-muted"))){ee(e,te(`<span class="pb-bt-muted">${T(b.emmaBt.loading)}</span>`));try{const p=await lt(t);if(o!==pe)return;if(p){s(p);return}const f=rn(t);ee(e,te(`<button type="button" class="pb-bt-btn pb-bt-open-create">${T(b.emmaBt.openCreate)}</button>`)),e.dataset.fetched="1",(l=e.querySelector(".pb-bt-open-create"))==null||l.addEventListener("click",()=>{dn(e,t,f,g=>{g?(Yt(t,g),s(g)):(e.dataset.fetched="",A=null,xe(e,t,!0))})})}catch(p){if(o!==pe)return;ee(e,te(`<span class="pb-bt-muted">${T(p instanceof Error?p.message:b.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${T(b.emmaBt.retry)}</button>`)),e.dataset.fetched="1",(c=e.querySelector(".pb-bt-retry"))==null||c.addEventListener("click",()=>{ze(),e.dataset.fetched="",A=null,xe(e,t)})}}}function T(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function U(e){return T(e).replace(/'/g,"&#39;")}function ne(){ie&&window.clearTimeout(ie),ie=window.setTimeout(()=>{pt()},700)}function un(e){return document.documentElement.contains(e)}async function pt(){var a,s,i,l,c,p;if(!Jt()){(a=document.getElementById(h))==null||a.remove(),(s=document.getElementById($))==null||s.remove(),K(),A=null,W=null;return}an();const e=en();let t=Qt();if(t?W=t:e&&W?t=W:!e&&!ve()&&(W=null),!e&&ut()&&!ve()){(i=document.getElementById(h))==null||i.remove(),(l=document.getElementById($))==null||l.remove(),A=null;return}if(!t){(c=document.getElementById(h))==null||c.remove(),(p=document.getElementById($))==null||p.remove(),A=null;return}const n=document.getElementById(h)||document.getElementById($);if(t===A&&n&&un(n)&&n.dataset.bound===t&&n.dataset.fetched==="1"){const f=e?null:Ge();if(f&&n.id===$&&!e){const g=Ve(f);g!==n&&(g.dataset.bound=t,g.dataset.fetched="",n.remove(),A=t,await xe(g,t))}return}const o=e?null:Ge(),r=o?Ve(o):sn();A=t,r.dataset.bound=t,await xe(r,t)}function pn(){de().then(t=>{b=S(t),A=null,ne()}),ue(t=>{b=S(t),A=null,ne()}),pt(),window.addEventListener("hashchange",()=>{A=null,ve()||(W=null);const t=document.getElementById(h)||document.getElementById($);t instanceof HTMLElement&&(t.dataset.fetched=""),ne()});const e=new MutationObserver(t=>{let n=!1;for(const o of t){const r=o.target;if(r instanceof Element&&!(r.id===h||r.id===$||r.id===ye||r.id===x||r.closest("[data-prize-bernticket]")||r.closest(`#${h}, #${$}, #${x}`))&&!(o.type==="childList"&&[...o.addedNodes,...o.removedNodes].length>0&&[...o.addedNodes,...o.removedNodes].every(a=>a instanceof Element&&(a.id===h||a.id===$||a.id===x||a.closest(`[data-prize-bernticket], #${h}, #${$}`))))){n=!0;break}}n&&ne()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{if(n==="local"&&(t.btAccessToken||t.btRefreshToken)){A=null,ze();const o=document.getElementById(h)||document.getElementById($);o instanceof HTMLElement&&(o.dataset.fetched=""),ne()}})}catch{}return()=>{var t,n,o;e.disconnect(),ie&&window.clearTimeout(ie),(t=document.getElementById(h))==null||t.remove(),(n=document.getElementById($))==null||n.remove(),(o=document.getElementById(ye))==null||o.remove(),K()}}let D=S("de");const we="prize-bt-list-style",u="data-prize-bt-chip";let se=null;function mn(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function fn(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function bn(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function gn(){let e=document.getElementById(we);e||(e=document.createElement("style"),e.id=we,document.documentElement.appendChild(e)),e.dataset.v!=="7"&&(e.dataset.v="7",e.textContent=`
    [${u}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: BELOW reservation number — do not sit in the number hbox */
    [${u}][data-surface="list"]{
      display:block !important;
      margin:0.15rem 0 0 0 !important;
      max-width:100%;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${u}]),
    .sapUiTableDataCell:has([${u}]),
    .sapMVBox:has([${u}]),
    .sapMHBox:has([${u}]){
      overflow:visible !important;
    }
    .sapUiTableCellInner:has([${u}[data-surface="list"]]){
      max-height:none !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${u}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    /* Room Status detail panel (click a room): large code */
    [${u}][data-surface="room-detail"]{
      display:flex !important;
      flex-direction:column;
      align-items:flex-start;
      gap:0.4rem;
      margin:0.65rem 0.75rem 0.35rem !important;
      padding:0.7rem 0.9rem;
      background:linear-gradient(180deg,#fff 0%,#fff8f8 100%);
      border:1px solid rgba(170,8,8,.28);
      border-radius:0.5rem;
      box-shadow:0 2px 10px rgba(15,23,42,.08);
      position:relative !important;
      left:auto !important;
      bottom:auto !important;
      max-width:min(100%, 20rem);
      z-index:10;
    }
    [${u}][data-surface="room-detail"] .pb-bt-detail-label{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.68rem;
      font-weight:700;
      letter-spacing:.07em;
      text-transform:uppercase;
      color:#6a6d70;
    }
    [${u}][data-surface="room-detail"] .pb-bt-list-code{
      font-size:1.55rem !important;
      font-weight:800;
      letter-spacing:.08em;
      padding:0.4rem 0.85rem;
      border-radius:0.35rem;
      line-height:1.15;
    }
    [${u}][data-surface="room-detail"] .pb-bt-list-muted{
      font-size:0.85rem;
    }
    [${u}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${u}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${u}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${u}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function mt(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${u}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return J(n)}return null}function hn(e){return mt(e)}function yn(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return mt(t)}function vn(e,t){let n=e.querySelector(`:scope > [${u}]`);if(!n){const o=e.querySelector(`[${u}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(u,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function xn(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function wn(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function $n(e,t){let n=null;for(const s of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!s.closest(`[${u}]`)&&/^\d{6,}$/.test((s.textContent||"").trim())){n=s;break}const o=(n==null?void 0:n.closest(".sapMVBox"))||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,r=(n==null?void 0:n.closest(".sapMHBox"))||o.querySelector(":scope > .sapMHBox");let a=e.querySelector(`[${u}]`);return a?(a.dataset.booking!==t&&(a.dataset.booking=t,a.dataset.state="",a.innerHTML=""),a.dataset.surface="list",a.parentElement!==o?r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a):r&&a.previousElementSibling!==r&&r.insertAdjacentElement("afterend",a),a):(a=document.createElement("div"),a.setAttribute(u,"1"),a.dataset.booking=t,a.dataset.surface="list",r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a),a)}function Cn(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function Tn(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Xt(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",D.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||D.emmaBt.clickToCopy)},1200)})})}function kn(e,t){if(e.setAttribute(u,"1"),e.dataset.booking=t,e.dataset.state="loading",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${Ae(D.emmaBt.brand)}</div><span class="pb-bt-list-muted">${Ae(D.emmaBt.loading)}</span>`;return}e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function We(e,t,n){if(e.setAttribute(u,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="",e.dataset.surface==="room-detail"){const r=document.createElement("div");r.className="pb-bt-detail-label",r.textContent=D.emmaBt.brand,e.appendChild(r)}const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=D.emmaBt.clickToCopy,o.setAttribute("aria-label",`${D.emmaBt.brand}: ${n}`),Tn(o,n),e.appendChild(o)}function Ye(e,t){if(e.setAttribute(u,"1"),e.dataset.booking=t,e.dataset.state="none",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${Ae(D.emmaBt.brand)}</div><span class="pb-bt-list-muted">—</span>`;return}e.innerHTML=""}function Ae(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function Pe(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=Le(t);if(r&&r.code===null)return;e.dataset.state=""}const n=Le(t);if(n){n.code?We(e,t,n.code):Ye(e,t);return}kn(e,t);const o=await lt(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?We(e,t,o):Ye(e,t))}function Sn(){const e=fn();if(!e){Cn()||document.querySelectorAll(`[${u}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=wn(r);if(!a)continue;const s=hn(a),i=a.querySelector(`[${u}]`);if(!s){(i==null?void 0:i.dataset.state)==="ok"&&n.add(i);continue}const l=$n(a,s);n.add(l),Pe(l,s)}document.querySelectorAll(`[${u}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function En(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function In(){const e=bn(),t=new Set(e);if(e.length===0){En()||document.querySelectorAll(`[${u}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=yn(o),a=o.querySelector(`[${u}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&xn(o)){n.add(a);continue}a==null||a.remove();continue}const s=vn(o,r);n.add(s),Pe(s,r)}document.querySelectorAll(`[${u}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function Bn(){const e=document.querySelectorAll('.sapMPageEnableScrolling, section.sapMPageEnableScrolling, [id$="-cont"].sapUiScrollDelegate');for(const t of e){if(t.querySelector(".sapMGT.roomTiles, .sapMGT.roomTiles2"))continue;const n=t.querySelector('.sapMTitle, .sapMTitle-inner, [class*="sapMTitle"]'),o=((n==null?void 0:n.textContent)||"").replace(/\s+/g," ").trim();if((/^room\s+\d+/i.test(o)||/^zimmer\s+\d+/i.test(o)||[...t.querySelectorAll("bdi, .sapMBtnContent")].some(a=>/check\s*out|change\s*room\s*status/i.test((a.textContent||"").trim())))&&ft(t))return t}return null}function ft(e){var t;for(const n of e.querySelectorAll(".sapMLabel, .sapMLabel bdi")){const o=(n.textContent||"").replace(/\s+/g," ").trim().replace(/:$/,"");if(!/^(reservation|reservierung)$/i.test(o))continue;const r=((t=n.closest('[class*="wrapperfor"]'))==null?void 0:t.parentElement)||n.closest(".sapUiFormResGridCont")||n.closest(".sapUiRespGrid")||e;for(const a of r.querySelectorAll("a.sapMLnk")){const s=(a.textContent||"").trim();if(/^\d{6,}$/.test(s))return J(s)}}for(const n of e.querySelectorAll("a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return J(o)}return null}function Mn(e,t){let n=e.querySelector(`[${u}][data-surface="room-detail"]`);if(n)return n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n;n=document.createElement("div"),n.setAttribute(u,"1"),n.dataset.booking=t,n.dataset.surface="room-detail",n.setAttribute("role","region"),n.setAttribute("aria-label",D.emmaBt.brand);const o=e.querySelector(":scope > .sapMHBox"),r=e.querySelector('.sapUiForm, [role="form"]');return(o==null?void 0:o.parentElement)===e?o.insertAdjacentElement("afterend",n):r?r.insertAdjacentElement("beforebegin",n):e.insertBefore(n,e.firstChild),n}function Ln(){const e=Bn();if(!e){document.querySelectorAll(`[${u}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const t=ft(e);if(!t){document.querySelectorAll(`[${u}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const n=Mn(e,t);Pe(n,t)}function bt(){if(!mn()){document.querySelectorAll(`[${u}]`).forEach(e=>e.remove());return}gn(),Sn(),In(),Ln()}function oe(){se&&window.clearTimeout(se),se=window.setTimeout(()=>{bt()},280)}function An(){de().then(t=>{D=S(t),oe()}),ue(t=>{D=S(t),document.querySelectorAll(`[${u}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),oe()}),bt(),window.addEventListener("hashchange",()=>oe());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===we||o.closest(`[${u}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${u}]`)||r.closest(`[${u}]`))))){oe();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(ze(),document.querySelectorAll(`[${u}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),oe())})}catch{}return()=>{var t;e.disconnect(),se&&window.clearTimeout(se),(t=document.getElementById(we))==null||t.remove(),document.querySelectorAll(`[${u}]`).forEach(n=>n.remove())}}const Xe="CHBRNPR",Re="100",gt="ZEYUI_RSRVS_SRV";function Rn(e){const t=parseInt(e,10);return Number.isFinite(t)?String(t).padStart(4,"0"):e.trim()}function qn(e,t,n=new Date){const o=(a,s)=>String(a).padStart(s,"0"),r=[o(n.getFullYear(),4),o(n.getMonth()+1,2),o(n.getDate(),2),o(n.getHours(),2),o(n.getMinutes(),2),o(n.getSeconds(),2)].join("");return`${e}   ${t}${r}000`}function Dn(e,t,n){const o=Math.random().toString(16).slice(2,14).padEnd(12,"0"),r=`batch_${o.slice(0,4)}-${o.slice(4,8)}-${o.slice(8,12)}`,a=`changeset_${o.slice(2,6)}-${o.slice(6,10)}-${o.slice(0,4)}`,s=`id-${Date.now()}-1000`;let i=`\r
`;return i+=`--${r}\r
`,i+=`Content-Type: multipart/mixed; boundary=${a}\r
\r
`,i+=`--${a}\r
`,i+=`Content-Type: application/http\r
`,i+=`Content-Transfer-Encoding: binary\r
\r
`,i+=`POST ${e} HTTP/1.1\r
`,i+=`tms-fioriapp: CheckIn\r
`,i+=`Request-Object-Key: ${n}\r
`,i+=`Request-Object-Type: RSRV\r
`,i+=`sap-contextid-accept: header\r
`,i+=`Accept: application/json\r
`,i+=`x-csrf-token: ${t}\r
`,i+=`Accept-Language: en\r
`,i+=`DataServiceVersion: 2.0\r
`,i+=`MaxDataServiceVersion: 2.0\r
`,i+=`X-Requested-With: XMLHttpRequest\r
`,i+=`Content-Type: application/json\r
`,i+=`Content-ID: ${s}\r
\r
`,i+=`\r
`,i+=`--${a}--\r
\r
`,i+=`--${r}--\r
`,{body:i,contentType:`multipart/mixed;boundary=${r}`}}async function _n(){const e=await fetch(`${location.origin}/sap/opu/odata/sap/${gt}/?sap-client=${Re}`,{credentials:"include",headers:{"x-csrf-token":"Fetch",Accept:"application/json","X-Requested-With":"XMLHttpRequest"}}),t=e.headers.get("x-csrf-token");if(!e.ok||!t||t.toLowerCase()==="required")throw new Error("CSRF");return t}function zn(e){const t=e.match(/HTTP\/1\.[01] ([45]\d\d)[^\n]*\n([\s\S]*?)(?:\n--|\s*$)/);if(!t)return null;const o=(t[2]??"").match(/"message"\s*:\s*\{[^}]*"value"\s*:\s*"([^"]+)"/);return(o==null?void 0:o[1])||`EMMA ${t[1]}`}async function Hn(e,t){const n=await _n(),o=Rn(t),r=`RoomAssignment?sap-client=${Re}&HotelId='${Xe}'&ReservationId='${e}'&RoomId='${o}'`,a=Dn(r,n,qn(Xe,e)),s=await fetch(`${location.origin}/sap/opu/odata/sap/${gt}/$batch?sap-client=${Re}`,{method:"POST",credentials:"include",headers:{"Content-Type":a.contentType,"x-csrf-token":n,Accept:"multipart/mixed","X-Requested-With":"XMLHttpRequest",DataServiceVersion:"2.0",MaxDataServiceVersion:"2.0"},body:a.body}),i=await s.text(),l=zn(i);if(!s.ok||l)throw new Error(l||`EMMA ${s.status}`)}let d=S("de");const m="prize-ra-host",le="prize-ra-style",y="data-prize-room-assign";function Pn(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function qe(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${y}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o}return null}function ht(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function ke(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function Fn(e){const t=ke(e);return it(t)!=null}function Nn(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=ke(r);if(a)return a}}return null}function yt(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&ht(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function On(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&ht(o))return o}const t=yt();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function Un(){const e=On();return e?e.closest(".sapMFlexItem")??e.parentElement:null}function Se(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let s=0;s<6&&a;s++){const i=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const l of i)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const p=(l instanceof HTMLInputElement?l.value:l.textContent||"").trim();if(p&&!t.test(p))return p}a=a.parentElement}}return null}function jn(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=Se(n,/^Arrival\s*Date$/i)||Se(n,/^Arrival$/i)||Se(n,/^Anreise(datum)?$/i);if(!o)continue;const r=G(o);if(r)return r}return null}function Gn(){if(Nn())return!1;const e=jn();return e?dt(e):!0}function Vn(e,t){const n=ke(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}const Wn=2e4;let I=null,re=null;const Ee=new Set;let w=null,H=!1,M=!1;function vt(e){const t={vip:d.emmaRoom.reasonVip,premium:d.emmaRoom.reasonPremium,repeat:d.emmaRoom.reasonRepeat,one_night:d.emmaRoom.reasonOneNight,long_stay:d.emmaRoom.reasonLongStay,three_pax:d.emmaRoom.reasonThreePax,no_basement:d.emmaRoom.reasonNoBasement,not_ready:d.emmaRoom.reasonNotReady,category_not_ready:d.emmaRoom.reasonCategoryNotReady,overbook_view:d.emmaRoom.reasonOverbookView,overbook_corner:d.emmaRoom.reasonOverbookCorner,overbook_standard:d.emmaRoom.reasonOverbookStandard,wheelchair:d.emmaRoom.reasonWheelchair};return e.map(n=>t[n]).filter(n=>!!n).slice(0,3).join(" · ")}function xt(e,t){const n=o=>o.replace(/^0+/,"")||o;return e===t||n(e)===n(t)}function $e(e){const t=e instanceof Error?e.message:String(e??"");return/401|unauthorized|invalid token|jwt/i.test(t)?d.emmaRoom.signInRequired:d.emmaRoom.loadFailed}async function wt(){const e=I!=null&&I.error?5e3:Wn;return I&&Date.now()-I.at<e?I:re||(re=(async()=>{let t;try{const n=await Te("/reservations/room-suggestions");t={at:Date.now(),items:n.items??[],error:null}}catch(n){t={at:Date.now(),items:[],error:$e(n)}}return I=t,t})().finally(()=>{re=null}),re)}function Yn(e,t){var n;return((n=e.find(o=>xt(o.reservationId,t)))==null?void 0:n.suggestion)??null}function Fe(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!t.closest(`[${y}]`))return t;return null}function $t(e,t){const n=Fe(e);if(n){n.nextElementSibling!==t&&n.insertAdjacentElement("afterend",t);return}const o=e.querySelector(".sapUiTableCellInner")||e;t.parentElement!==o&&o.appendChild(t)}function Ke(e,t,n){const o=Fe(e);let r=e.querySelector(`[${y}="row"]`);const a=o?o.nextElementSibling===r:(r==null?void 0:r.parentElement)===(e.querySelector(".sapUiTableCellInner")||e);if(r&&a&&r.dataset.note===t&&r.dataset.error===(n?"1":"0"))return r;r||(r=document.createElement("div"),r.setAttribute(y,"row")),$t(e,r),r.dataset.error=n?"1":"0",r.dataset.booking="",r.dataset.room="",r.dataset.note=t,r.innerHTML="";const s=document.createElement("span");return s.className=`pb-ra-row-note${n?" is-error":""}`,s.textContent=t,s.title=t,r.appendChild(s),r}async function Ct(e){return await Hn(e.reservationId,e.roomNumber),I=null,await Te(`/reservations/${encodeURIComponent(e.reservationId)}/room-suggestion/accept`,{method:"POST",body:JSON.stringify({roomNumber:e.roomNumber})}),I=null,e.roomNumber}async function Xn(e){I=null;const t=await Te(`/reservations/${encodeURIComponent(e)}/room-suggestion/arriving-now`,{method:"POST"});return I=null,t.suggestion}async function Kn(e,t){I=null;const n=await Te(`/reservations/${encodeURIComponent(e)}/room-suggestion/shift`,{method:"POST",body:JSON.stringify({direction:t})});return I=null,n.suggestion}function Zn(){let e=document.getElementById(le);e||(e=document.createElement("style"),e.id=le,document.documentElement.appendChild(e)),e.dataset.v!=="8"&&(e.dataset.v="8",e.textContent=`
    /* Detail: inline beside the Room input, never inside the 6rem control */
    #${m}{
      box-sizing:border-box;
      display:inline-flex;
      flex-direction:row;
      flex-wrap:wrap;
      align-items:center;
      gap:6px;
      margin:0 0 0 8px;
      max-width:none;
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:transparent;
      border:0;
      box-shadow:none;
      padding:0;
      z-index:5;
      pointer-events:auto;
      vertical-align:middle;
    }
    #${m} *{box-sizing:border-box;}
    #${m} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${m} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${m} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${m} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${m} .pb-ra-main{
      display:flex;align-items:center;gap:6px;
    }
    #${m} .pb-ra-room{
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:16px;font-weight:800;letter-spacing:.03em;line-height:1.1;
      color:#1a2332;
    }
    #${m} .pb-ra-meta{
      font-size:9px;color:#64748b;margin-top:1px;font-weight:500;
    }
    #${m} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${m} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:26px;height:26px;border-radius:7px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
    }
    #${m} .pb-ra-btn:hover{background:#f1f5f9;}
    #${m} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${m} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${m} .pb-ra-nudge{display:flex;flex-direction:column;gap:2px;}
    #${m} .pb-ra-nudge .pb-ra-btn{width:22px;height:16px;border-radius:5px;}
    #${m} .pb-ra-nudge .pb-ra-btn svg{width:11px;height:11px;}
    #${m} .pb-ra-actions{display:flex;align-items:center;gap:4px;}
    #${m} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${m} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${m} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${m} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${m} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${m} .pb-ra-note{
      font-size:12px;font-weight:650;color:#9a3412;line-height:1.25;
    }

    /* Check-in list Room column — same line as the empty room number */
    .sapUiTableDataCell:has([${y}="row"]) .sapUiTableCellInner,
    .sapUiTableDataCell:has([${y}="row"]) .sapMVBox{
      overflow:visible !important;
      max-height:none !important;
    }
    [${y}="row"]{
      display:inline-flex !important;
      align-items:center;
      gap:0.25rem;
      margin:0;
      line-height:1.15;
      max-width:100%;
      flex-shrink:0;
      position:relative;
      z-index:20;
      pointer-events:auto;
      vertical-align:middle;
    }
    [${y}="row"] .pb-ra-row-code{
      appearance:none;cursor:pointer;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:0.78rem;font-weight:800;letter-spacing:.03em;
      color:#0f172a;
      background:#dbeafe;
      border:1px solid #2563eb;
      border-radius:0.25rem;
      padding:0.15rem 0.45rem;
      white-space:nowrap;
    }
    [${y}="row"] .pb-ra-row-code:hover{filter:brightness(0.97);}
    [${y}="row"] .pb-ra-row-note{
      display:inline-block;max-width:9.5rem;margin-left:4px;
      font-size:10px;font-weight:650;line-height:1.2;color:#9a3412;
    }
    [${y}="row"] .pb-ra-row-note.is-error{color:#9b1c1c;}
    #${m} .pb-ra-now{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      border-radius:6px;padding:3px 6px;font-size:10px;font-weight:700;color:#1a2332;
    }
    #${m} .pb-ra-now:hover{background:#f1f5f9;}
    [${y}="row"] .pb-ra-row-code.pb-ra-dirty{background:#ffedd5;border-color:#c2410c;color:#9a3412;}
    [${y}="row"] .pb-ra-row-accept{
      appearance:none;cursor:pointer;border:1px solid #15803d;background:#15803d;color:#fff;
      border-radius:0.25rem;width:1.35rem;height:1.35rem;font-size:0.75rem;font-weight:800;
      line-height:1;
    }
  `)}function Jn(e){let t=document.getElementById(m);const n=!!(t!=null&&t.closest(".sapMInputBase"));if(t&&!n&&t.previousElementSibling===e)return t;const o=t==null?void 0:t.dataset.key;return t==null||t.remove(),t=document.createElement("div"),t.id=m,t.setAttribute(y,"detail"),t.setAttribute("role","region"),t.setAttribute("aria-label",d.emmaRoom.title),o&&(t.dataset.key=o),e.insertAdjacentElement("afterend",t),t}function Qn(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function Ze(e){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="${e==="up"?"M6 14l6-6 6 6":"M6 10l6 6 6-6"}"/></svg>`}let R=null,ce=null,E="",L=!1,De=!1,Ie=!1,Be=!1;function eo(e){const t=yt();if(!t)return!1;const n=t.value,o=Vn(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function P(e){var f,g,B,k;if(e.setAttribute("aria-label",d.emmaRoom.title),H&&!w){e.innerHTML=`<div class="pb-ra-note">${_(d.emmaRoom.loading)}</div>`;return}if(!w){e.innerHTML=`<div class="pb-ra-note">${_(E||d.emmaRoom.noSuggestion)}</div>`;return}const t=zt(w.floor??it(w.roomNumber)),n=w.readyNow?d.emmaRoom.ready:d.emmaRoom.dirty,o=vt(w.reasons),r=[t,n,o].filter(Boolean).join(" · "),a=E?`<div class="pb-ra-status${L?" pb-ra-warn":""}">${_(E)}</div>`:"",s=d.emmaRoom.accept,i=d.emmaRoom.higher,l=d.emmaRoom.lower,c=d.emmaRoom.arrivingNow;e.innerHTML=`<div class="pb-ra-top"><span class="pb-ra-title"><span class="pb-ra-dot" aria-hidden="true"></span>${_(d.emmaRoom.title)}</span><span class="pb-ra-badge">${_(n)}</span></div><div class="pb-ra-main"><div><div class="pb-ra-room">${_(w.roomNumber)}</div><div class="pb-ra-meta">${_(r)}</div></div><div class="pb-ra-actions"><div class="pb-ra-nudge"><button type="button" class="pb-ra-btn pb-ra-up" title="${V(i)}" aria-label="${V(i)}">${Ze("up")}</button><button type="button" class="pb-ra-btn pb-ra-down" title="${V(l)}" aria-label="${V(l)}">${Ze("down")}</button></div><button type="button" class="pb-ra-btn pb-ra-accept" title="${V(s)}" aria-label="${V(s)}">${Qn()}</button></div></div><button type="button" class="pb-ra-now">${_(c)}</button>`+a+`<div class="pb-ra-note">${_(d.emmaRoom.previewNote)}</div>`;const p=v=>{const z=qe();if(!z||!w||M)return;const C=w;M=!0,H=!0,P(e),Kn(z,v).then(Q=>{w=Q??C,R=null,E=Q?"":v==="up"?d.emmaRoom.noHigher:d.emmaRoom.noLower,L=!Q}).catch(Q=>{w=C,E=$e(Q),L=!0}).finally(()=>{M=!1,H=!1,P(e),N()})};(f=e.querySelector(".pb-ra-up"))==null||f.addEventListener("click",v=>{v.preventDefault(),v.stopPropagation(),p("up")}),(g=e.querySelector(".pb-ra-down"))==null||g.addEventListener("click",v=>{v.preventDefault(),v.stopPropagation(),p("down")}),(B=e.querySelector(".pb-ra-accept"))==null||B.addEventListener("click",v=>{if(v.preventDefault(),v.stopPropagation(),!w||M)return;const z=w;M=!0,Ct(z).then(C=>{eo(C),E=ot(d.emmaRoom.applied,{room:C}),L=!1,w=null,R=null}).catch(C=>{E=C instanceof Error&&C.message&&C.message!=="CSRF"?`${d.emmaRoom.assignFailed}: ${C.message}`:d.emmaRoom.assignFailed,L=!0}).finally(()=>{M=!1,P(e),N()})}),(k=e.querySelector(".pb-ra-now"))==null||k.addEventListener("click",v=>{v.preventDefault(),v.stopPropagation();const z=qe();!z||M||(M=!0,H=!0,P(e),Xn(z).then(C=>{w=C,R=null,E=C?"":d.emmaRoom.noSuggestion,L=!C}).catch(C=>{E=$e(C),L=!0}).finally(()=>{M=!1,H=!1,P(e),N()}))})}function _(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function V(e){return _(e).replace(/'/g,"&#39;")}function to(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function no(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((s,i)=>{const l=(s.textContent||"").replace(/:/g,"").replace(/\s+/g," ").trim().toLowerCase();(l==="room"||l==="zimmer")&&(t=i),(l==="arrival"||l==="anreise")&&(n=i)}),{room:t,arrival:n}}function Je(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function oo(e){const t=/-col0$/;let n=null;for(const o of e.querySelectorAll('[id*="-col"]'))if(t.test(o.id)){n=o;break}if(n||(n=e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")),!n)return null;for(const o of n.querySelectorAll(".sapMText, a.sapMLnk")){if(o.closest(`[${y}]`))continue;const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r}return null}function ro(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${y}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&Fn(n))return ke(n)}return null}function ao(e){for(const t of e.querySelectorAll(".sapMText")){const n=(t.textContent||"").trim(),o=G(n);if(o)return o}return G((e.textContent||"").trim())}function io(e,t){if(t){const n=ao(t);if(n)return n}for(const n of e.querySelectorAll(".sapMText")){if(n.closest(`[${y}]`))continue;const o=G((n.textContent||"").trim());if(o)return o}return null}function so(e,t){const n=t.reservationId,o=t.roomNumber;let r=e.querySelector(`[${y}="row"]`);const a=Fe(e);if(r&&r.dataset.booking===n&&r.dataset.room===o&&r.dataset.ready===String(t.readyNow)&&(a==null?void 0:a.nextElementSibling)===r)return r;r||(r=document.createElement("div"),r.setAttribute(y,"row")),$t(e,r),r.dataset.booking=n,r.dataset.room=o,r.dataset.ready=String(t.readyNow),r.innerHTML="";const s=document.createElement("button");s.type="button",s.className=`pb-ra-row-code${t.readyNow?"":" pb-ra-dirty"}`;const i=o.padStart(4,"0");s.textContent=i;const l=vt(t.reasons);s.title=[d.emmaRoom.title,i,t.readyNow?d.emmaRoom.ready:d.emmaRoom.dirty,l].filter(Boolean).join(" · "),s.setAttribute("aria-label",s.title);const c=document.createElement("button");return c.type="button",c.className="pb-ra-row-accept",c.textContent="✓",c.title=d.emmaRoom.accept,c.setAttribute("aria-label",d.emmaRoom.accept),c.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),!M&&(M=!0,Ct(t).then(()=>{const f=e.querySelector(".sapMText, a.sapMLnk");f&&!f.closest(`[${y}]`)&&(f.textContent=i),r==null||r.remove()}).catch(()=>{s.title=d.emmaRoom.assignFailed}).finally(()=>{M=!1}))}),r.appendChild(s),r.appendChild(c),r}function lo(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}async function co(){const e=to();if(!e){lo()||document.querySelectorAll(`[${y}="row"]`).forEach(i=>i.remove());return}const t=no(e),n=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),o=new Set(n),r=new Set,a=new Set,s=await wt();for(const i of n){const l=oo(i);if(!l)continue;const c=Je(i,t.room),p=Je(i,t.arrival);if(!c)continue;const f=ro(c),g=c.querySelector(`[${y}="row"]`);if(f){g==null||g.remove();continue}const B=io(i,p);if(B&&!dt(B)){g==null||g.remove();continue}if(s.error){r.add(Ke(c,s.error,!0));continue}const k=s.items.find(z=>xt(z.reservationId,l)),v=k!=null&&k.suggestion?k.suggestion.roomNumber.replace(/^0+/,""):"";if(!(k!=null&&k.suggestion)||v&&a.has(v)){k?r.add(Ke(c,d.emmaRoom.noSuggestion,!1)):g==null||g.remove();continue}a.add(v),r.add(so(c,k.suggestion))}document.querySelectorAll(`[${y}="row"]`).forEach(i=>{if(!(i instanceof HTMLElement)||r.has(i))return;const l=i.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!l||!o.has(l))&&i.remove()})}function Ce(){var e;(e=document.getElementById(m))==null||e.remove(),R=null,w=null,H=!1,E="",L=!1}async function uo(){var s,i;const e=qe(),t=Un();if(!t||!e){Ce();return}if(!Gn()){Ce();return}const n=((s=document.getElementById(m))==null?void 0:s.previousElementSibling)===t&&!((i=document.getElementById(m))!=null&&i.closest(".sapMInputBase")),o=Jn(t),r=e;if(!n&&o.dataset.key===r&&P(o),o.dataset.key===r||Ee.has(r))return;Ee.add(r);const a=R!==r;R=r,a&&(E="",L=!1),H=!0,P(o);try{const l=await wt();if(R!==r)return;l.error?(w=null,E=l.error,L=!0):(w=Yn(l.items,e),w||(E=d.emmaRoom.noSuggestion,L=!0)),o.dataset.key=r}catch(l){if(R!==r)return;w=null,E=$e(l),L=!0,o.dataset.key=r}finally{H=!1,Ee.delete(r)}R===r&&P(o)}async function Tt(){if(Ie){Be=!0;return}Ie=!0,De=!0;try{if(!Pn()){Ce(),document.querySelectorAll(`[${y}="row"]`).forEach(e=>e.remove());return}Zn(),await co(),await uo()}finally{Ie=!1,window.setTimeout(()=>{De=!1,Be&&(Be=!1,N())},0)}}function N(){ce&&window.clearTimeout(ce),ce=window.setTimeout(()=>{Tt()},350)}function po(){de().then(t=>{d=S(t),R=null,N()}),ue(t=>{d=S(t),R=null,N()}),Tt(),window.addEventListener("hashchange",()=>{var t;R=null,w=null,(t=document.getElementById(m))==null||t.removeAttribute("data-key"),N()});const e=new MutationObserver(t=>{if(!De)for(const n of t){const o=n.target;if(o instanceof Element&&(o.id===m||o.id===le||o.closest(`[${y}]`)))continue;const r=[...n.addedNodes];if(!(r.length>0&&r.every(a=>a instanceof Element&&(a.id===m||a.id===le||a.hasAttribute(y))))){N();return}}});return e.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var t;e.disconnect(),ce&&window.clearTimeout(ce),Ce(),document.querySelectorAll(`[${y}="row"]`).forEach(n=>n.remove()),(t=document.getElementById(le))==null||t.remove()}}const Qe="prize-panel-host";let F=S("de");function kt(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function ge(e,t,n){const o=`${he}px 0 0 ${he}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=kt(),t.title=F.inject.openPanel,t.setAttribute("aria-label",F.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${nt}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=F.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function et(e,t,n){var s;const r=!await _e(O.panelCollapsed);await Bt({[O.panelCollapsed]:r}),ge(e,t,r);const a=e.querySelector("iframe");(s=a==null?void 0:a.contentWindow)==null||s.postMessage({type:r?Z.collapsed:Z.expanded},"*")}function tt(){if(document.getElementById(Qe))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${he}px 0 0 ${he}px`,r=document.createElement("div");r.id=Qe,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${Et}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:me,border:`1px solid ${Me}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const s=document.createElement("iframe");s.id="prize-panel-iframe",s.src=chrome.runtime.getURL("src/panel/index.html"),s.title=F.inject.panelTitle,Object.assign(s.style,{width:`${nt}px`,height:"100%",border:"none",display:"block",background:me}),a.appendChild(s);const i=document.createElement("button");i.id="prize-panel-tab",i.type="button",Object.assign(i.style,{width:`${Ne}px`,height:`${It}px`,minWidth:`${Ne}px`,border:`1px solid ${Me}`,borderRight:"none",background:`linear-gradient(180deg, ${me} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),i.innerHTML=kt(),i.addEventListener("mouseenter",()=>{i.style.filter="brightness(1.12)"}),i.addEventListener("mouseleave",()=>{i.style.filter=""}),i.addEventListener("click",()=>{et(a,i)}),r.appendChild(a),r.appendChild(i),document.documentElement.appendChild(r),_e(O.panelCollapsed).then(l=>{t=l,ge(a,i,l)}),window.addEventListener("message",l=>{var c,p,f,g;((c=l.data)==null?void 0:c.type)===Z.toggle&&et(a,i),((p=l.data)==null?void 0:p.type)===Z.chatOpen&&(e=!0,n()&&((f=document.getElementById("prize-panel-chat-toast"))==null||f.remove())),((g=l.data)==null?void 0:g.type)===Z.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((l,c)=>{c==="local"&&l[O.panelCollapsed]&&(t=!!l[O.panelCollapsed].newValue)}),Wt(n),pn(),An(),po(),de().then(l=>{F=S(l),ge(a,i,t),s.title=F.inject.panelTitle}),ue(l=>{F=S(l),ge(a,i,t),s.title=F.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",tt):tt();
