import{b as Fe,S as U,P as Q,c as ve,d as De,A as qt,e as Te,f as Dt,g as dt,T as We,h as _t,s as zt}from"./storage-DTWcLCTt.js";import{l as be,w as ge,i as ut,g as I,a as pt,b as Ht,p as Pt,c as mt,d as Nt,t as Ye,B as Ft,e as Ot,f as Ut,h as he}from"./bernticket-api-B5xltN15.js";const Xe=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function jt(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function ft(e){if(jt(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=Xe.length;n++){const[o,r]=Xe[n-1];if(t>=o&&t<=r)return n}return null}function Gt(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let le=I("de");const q="prize-panel-chat-toast",Ke="prize-panel-chat-toast-style",Vt=8e3,Wt=7e3;function Yt(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function Xt(e){return e==="/r"||e.startsWith("/r/")}function Kt(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function Zt(){if(document.getElementById(Ke))return;const e=document.createElement("style");e.id=Ke,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${q}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${ve} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${De};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${q}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${q} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${q} .pb-ct-body{min-width:0;flex:1;}
    #${q} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${qt};margin-bottom:2px;
    }
    #${q} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${q} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${q} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${q} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let we=null;function X(e=!0){const t=document.getElementById(q);if(t){if(we&&(window.clearTimeout(we),we=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function Jt(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,i,s)=>{const l=t.createOscillator(),c=t.createGain();l.type="sine",l.frequency.setValueAtTime(a,i),c.gain.setValueAtTime(1e-4,i),c.gain.exponentialRampToValueAtTime(.9,i+.015),c.gain.exponentialRampToValueAtTime(1e-4,i+s),l.connect(c),c.connect(o),l.start(i),l.stop(i+s+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function Qt(e,t){Zt(),X(!1);const n=document.createElement("div");n.id=q,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),s=r.querySelector(".pb-ct-preview");a.textContent=le.toast.eyebrow,i.textContent=ut(le.toast.newMessageFrom,{author:e}),s.textContent=Kt(t);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",le.toast.close),l.textContent="×",l.addEventListener("click",c=>{c.stopPropagation(),X(!0)}),n.addEventListener("click",()=>X(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),Jt(),we=window.setTimeout(()=>{X(!0)},Wt)}function en(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:Q.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function tn(e){let t=!1,n=null,o=!0;be().then(s=>{le=I(s)});const r=ge(s=>{le=I(s)});Fe(U.chatNotificationsEnabled,!0).then(s=>{o=s});try{chrome.storage.onChanged.addListener((s,l)=>{if(l==="local"&&s[U.chatNotificationsEnabled]){const c=s[U.chatNotificationsEnabled].newValue;o=c===void 0?!0:!!c,o||X(!1)}})}catch{}const a=async()=>{var s,l,c;if(!t)try{if(!o)return;const d=await en();if(!d.ok)return;const f=d.msg;if(!(f!=null&&f.id))return;if(n===null){n=f.id;return}if(f.id===n||(n=f.id,(s=f.author)!=null&&s.id&&d.meId&&f.author.id===d.meId)||e()||Yt(window.location.pathname)||Xt(window.location.pathname))return;const v=((c=(l=f.author)==null?void 0:l.name)==null?void 0:c.trim())||"Team";Qt(v,f.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},Vt);return()=>{t=!0,window.clearInterval(i),r(),X(!1)}}const bt=300*1e3,G=new Map,xe=new Map;function ee(e){return e.replace(/^0+/,"")||e}function _e(e){const t=G.get(ee(e));return!t||Date.now()-t.at>=bt?null:{code:t.code}}function nn(e,t){G.set(ee(e),{code:t,at:Date.now()})}function Oe(){G.clear(),xe.clear()}async function gt(e){const t=ee(e),n=G.get(t);if(n&&Date.now()-n.at<bt)return n.code;let o=xe.get(t);return o||(o=(async()=>{try{const r=await pt();if(!(r!=null&&r.access))return G.set(t,{code:null,at:Date.now()}),null;const a=await Ht(t),i=Pt(a,t),s=mt(i);return G.set(t,{code:s,at:Date.now()}),s}catch{return G.set(t,{code:null,at:Date.now()}),null}finally{xe.delete(t)}})(),xe.set(t,o)),o}async function on(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}const rn={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function V(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=rn[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const i=new Date(a),s=i.getFullYear(),l=String(i.getMonth()+1).padStart(2,"0"),c=String(i.getDate()).padStart(2,"0");if(s>=2e3)return`${s}-${l}-${c}`}return null}function ht(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function an(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function yt(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:V(e);return!!(t&&t===ht())}let b=I("de");const g="prize-bt-checkin-host",Se="prize-bt-checkin-style",x="prize-bt-fallback-bar",w="prize-bt-create-dialog";function sn(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function vt(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function ke(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function ln(){const e=ke();if(e)return e;if(vt())return null;for(const o of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r.replace(/^0+/,"")||r}const t=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),n=((t==null?void 0:t.textContent)||"").match(/\b(\d{6,})\b/);return n?n[1].replace(/^0+/,"")||n[1]:null}function cn(){return!!document.querySelector(['.sapUiLocalBusyIndicator:not([style*="display: none"])',".sapUiBusy",".sapMBusyDialog",".sapUiBlockLayer",".sapUiBLy",".sapUiLocalBusyIndicatorAnimation",'[class*="BusyIndicator"]:not([style*="display: none"])'].join(", "))}function Ze(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function Ue(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function K(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const d=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(d&&!t.test(d))return d}a=a.parentElement}}return null}function dn(){const e=Ue()||document.body,t=K(e,/^Arrival\s*Date$/i)||K(e,/^Anreise(datum)?$/i),n=K(e,/^Departure\s*Date$/i)||K(e,/^Abreise(datum)?$/i),o=t&&V(t)||ht(),r=n&&V(n)||an();return{from:o,to:r}}function un(){const e=Ue()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=K(t,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function pn(){const e=Ue()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=K(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function mn(e){const t=dn();return{guestName:pn(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:un()}}function fn(){const e=document.getElementById(Se);e&&e.remove();const t=document.createElement("style");t.id=Se,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${g}),
    .sapMTBSpacerFlex:has(#${g}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${g}.sapMBarChild,
    #${g}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${g} *{box-sizing:border-box;}
    #${g} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${g} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:1.35rem;font-weight:700;
      letter-spacing:.05em;line-height:1.15;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.3rem;
      padding:0.45rem 0.85rem;
      min-width:0;text-align:center;
    }
    #${g} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${g} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${g} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${g} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${g} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${g} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${x}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.45rem;
      padding:0.35rem 0.6rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.3rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${x} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${x} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${x} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.05em;
      font-size:1.25rem;line-height:1.15;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.3rem;padding:0.35rem 0.7rem;
    }
    #${x} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${x} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${w}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${w} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${w} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${w} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${w} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${w} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${w} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${w} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${w} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${w} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${w} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${w} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${w} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${w} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${w} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${w} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function Z(){var e;(e=document.getElementById(w))==null||e.remove()}function Je(e){var o,r;(o=document.getElementById(x))==null||o.remove();let t=document.getElementById(g);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=g,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",b.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function bn(){var t;(t=document.getElementById(g))==null||t.remove();let e=document.getElementById(x);return e||(e=document.createElement("div"),e.id=x,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",b.emmaBt.brand),document.documentElement.appendChild(e),e)}function oe(e,t){e.innerHTML=t}function re(e){return`<span class="pb-bt-label">${E(b.emmaBt.brand)}</span>${e}`}async function gn(e){try{await navigator.clipboard.writeText(e)}catch{}}function hn(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{gn(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=b.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function yn(e,t,n,o){Z();const r=document.createElement("div");r.id=w,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${j(b.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${E(b.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${j(b.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${E(b.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${j(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${E(b.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${j(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${E(b.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${j(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${E(b.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${j(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${E(b.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${E(b.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${E(b.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(l=>{l.addEventListener("click",()=>Z())});const s=l=>{l.key==="Escape"&&(Z(),window.removeEventListener("keydown",s))};window.addEventListener("keydown",s),i.addEventListener("click",()=>{(async()=>{const l=r.querySelector(".pb-bt-dlg-name"),c=r.querySelector(".pb-bt-dlg-from"),d=r.querySelector(".pb-bt-dlg-to"),f=r.querySelector(".pb-bt-dlg-amt"),v=(l==null?void 0:l.value.trim())||"";if(!v){a.hidden=!1,a.textContent=b.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=b.common.ellipsis,a.hidden=!0;try{const $=await Nt({guestName:v,bookingNumber:t,validFrom:Ye((c==null?void 0:c.value)||n.from),validTo:Ye((d==null?void 0:d.value)||n.to),ticketsAmount:Math.max(1,parseInt((f==null?void 0:f.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});Z(),o(mt($))}catch($){if($ instanceof Ft&&$.code===Ot){const P=window.prompt(b.emmaBt.twoFaPrompt);if(P)try{await Ut(P),i.disabled=!1,i.textContent=b.emmaBt.create,i.click();return}catch(T){a.hidden=!1,a.textContent=T instanceof Error?T.message:b.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=b.emmaBt.create;return}}a.hidden=!1,a.textContent=$ instanceof Error?$.message:b.emmaBt.error,i.disabled=!1,i.textContent=b.emmaBt.create}})()})}let R=null,Y=null,ce=null,ye=0;async function Ee(e,t,n){var l,c;const o=++ye,r=await pt();if(o!==ye)return;if(!r.access){oe(e,re(`<span class="pb-bt-muted">${E(b.emmaBt.loginHint)}</span>`)),e.dataset.fetched="1";return}const a=b.bernticket.copyCode,i=d=>{oe(e,re(`<button type="button" class="pb-bt-code" title="${j(a)}">${E(d)}</button>`)),hn(e,d),e.dataset.fetched="1"},s=_e(t);if(s!=null&&s.code){i(s.code);return}if(!(e.dataset.bound===t&&e.dataset.fetched==="1"&&e.querySelector(".pb-bt-code, .pb-bt-open-create, .pb-bt-muted"))){oe(e,re(`<span class="pb-bt-muted">${E(b.emmaBt.loading)}</span>`));try{const d=await gt(t);if(o!==ye)return;if(d){i(d);return}const f=mn(t);oe(e,re(`<button type="button" class="pb-bt-btn pb-bt-open-create">${E(b.emmaBt.openCreate)}</button>`)),e.dataset.fetched="1",(l=e.querySelector(".pb-bt-open-create"))==null||l.addEventListener("click",()=>{yn(e,t,f,v=>{v?(nn(t,v),i(v)):(e.dataset.fetched="",R=null,Ee(e,t,!0))})})}catch(d){if(o!==ye)return;oe(e,re(`<span class="pb-bt-muted">${E(d instanceof Error?d.message:b.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${E(b.emmaBt.retry)}</button>`)),e.dataset.fetched="1",(c=e.querySelector(".pb-bt-retry"))==null||c.addEventListener("click",()=>{Oe(),e.dataset.fetched="",R=null,Ee(e,t)})}}}function E(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function j(e){return E(e).replace(/'/g,"&#39;")}function ae(){ce&&window.clearTimeout(ce),ce=window.setTimeout(()=>{wt()},700)}function vn(e){return document.documentElement.contains(e)}async function wt(){var a,i,s,l,c,d;if(!sn()){(a=document.getElementById(g))==null||a.remove(),(i=document.getElementById(x))==null||i.remove(),Z(),R=null,Y=null;return}fn();const e=cn();let t=ln();if(t?Y=t:e&&Y?t=Y:!e&&!ke()&&(Y=null),!e&&vt()&&!ke()){(s=document.getElementById(g))==null||s.remove(),(l=document.getElementById(x))==null||l.remove(),R=null;return}if(!t){(c=document.getElementById(g))==null||c.remove(),(d=document.getElementById(x))==null||d.remove(),R=null;return}const n=document.getElementById(g)||document.getElementById(x);if(t===R&&n&&vn(n)&&n.dataset.bound===t&&n.dataset.fetched==="1"){const f=e?null:Ze();if(f&&n.id===x&&!e){const v=Je(f);v!==n&&(v.dataset.bound=t,v.dataset.fetched="",n.remove(),R=t,await Ee(v,t))}return}const o=e?null:Ze(),r=o?Je(o):bn();R=t,r.dataset.bound=t,await Ee(r,t)}function wn(){be().then(t=>{b=I(t),R=null,ae()}),ge(t=>{b=I(t),R=null,ae()}),wt(),window.addEventListener("hashchange",()=>{R=null,ke()||(Y=null);const t=document.getElementById(g)||document.getElementById(x);t instanceof HTMLElement&&(t.dataset.fetched=""),ae()});const e=new MutationObserver(t=>{let n=!1;for(const o of t){const r=o.target;if(r instanceof Element&&!(r.id===g||r.id===x||r.id===Se||r.id===w||r.closest("[data-prize-bernticket]")||r.closest(`#${g}, #${x}, #${w}`))&&!(o.type==="childList"&&[...o.addedNodes,...o.removedNodes].length>0&&[...o.addedNodes,...o.removedNodes].every(a=>a instanceof Element&&(a.id===g||a.id===x||a.id===w||a.closest(`[data-prize-bernticket], #${g}, #${x}`))))){n=!0;break}}n&&ae()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{if(n==="local"&&(t.btAccessToken||t.btRefreshToken)){R=null,Oe();const o=document.getElementById(g)||document.getElementById(x);o instanceof HTMLElement&&(o.dataset.fetched=""),ae()}})}catch{}return()=>{var t,n,o;e.disconnect(),ce&&window.clearTimeout(ce),(t=document.getElementById(g))==null||t.remove(),(n=document.getElementById(x))==null||n.remove(),(o=document.getElementById(Se))==null||o.remove(),Z()}}let D=I("de");const Ie="prize-bt-list-style",p="data-prize-bt-chip";let de=null;function xn(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function $n(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Cn(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function Tn(){let e=document.getElementById(Ie);e||(e=document.createElement("style"),e.id=Ie,document.documentElement.appendChild(e)),e.dataset.v!=="7"&&(e.dataset.v="7",e.textContent=`
    [${p}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: BELOW reservation number — do not sit in the number hbox */
    [${p}][data-surface="list"]{
      display:block !important;
      margin:0.15rem 0 0 0 !important;
      max-width:100%;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${p}]),
    .sapUiTableDataCell:has([${p}]),
    .sapMVBox:has([${p}]),
    .sapMHBox:has([${p}]){
      overflow:visible !important;
    }
    .sapUiTableCellInner:has([${p}[data-surface="list"]]){
      max-height:none !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${p}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    /* Room Status detail panel (click a room): large code */
    [${p}][data-surface="room-detail"]{
      display:flex !important;
      flex-direction:column;
      align-items:flex-start;
      gap:0.4rem;
      margin:0.65rem 0.75rem 0.35rem !important;
      padding:0.7rem 0.9rem;
      background:linear-gradient(180deg,#fff 0%,#fff8f8 100%);
      border:1px solid rgba(170,8,8,.28);
      border-radius:0.5rem;
      box-shadow:0 2px 10px rgba(15,23,42,.08);
      position:relative !important;
      left:auto !important;
      bottom:auto !important;
      max-width:min(100%, 20rem);
      z-index:10;
    }
    [${p}][data-surface="room-detail"] .pb-bt-detail-label{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.68rem;
      font-weight:700;
      letter-spacing:.07em;
      text-transform:uppercase;
      color:#6a6d70;
    }
    [${p}][data-surface="room-detail"] .pb-bt-list-code{
      font-size:1.55rem !important;
      font-weight:800;
      letter-spacing:.08em;
      padding:0.4rem 0.85rem;
      border-radius:0.35rem;
      line-height:1.15;
    }
    [${p}][data-surface="room-detail"] .pb-bt-list-muted{
      font-size:0.85rem;
    }
    [${p}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${p}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${p}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${p}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function xt(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${p}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return ee(n)}return null}function Sn(e){return xt(e)}function kn(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return xt(t)}function En(e,t){let n=e.querySelector(`:scope > [${p}]`);if(!n){const o=e.querySelector(`[${p}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(p,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function In(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function Bn(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function Mn(e,t){let n=null;for(const i of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!i.closest(`[${p}]`)&&/^\d{6,}$/.test((i.textContent||"").trim())){n=i;break}const o=(n==null?void 0:n.closest(".sapMVBox"))||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,r=(n==null?void 0:n.closest(".sapMHBox"))||o.querySelector(":scope > .sapMHBox");let a=e.querySelector(`[${p}]`);return a?(a.dataset.booking!==t&&(a.dataset.booking=t,a.dataset.state="",a.innerHTML=""),a.dataset.surface="list",a.parentElement!==o?r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a):r&&a.previousElementSibling!==r&&r.insertAdjacentElement("afterend",a),a):(a=document.createElement("div"),a.setAttribute(p,"1"),a.dataset.booking=t,a.dataset.surface="list",r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a),a)}function Ln(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function Rn(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),on(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",D.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||D.emmaBt.clickToCopy)},1200)})})}function An(e,t){if(e.setAttribute(p,"1"),e.dataset.booking=t,e.dataset.state="loading",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${ze(D.emmaBt.brand)}</div><span class="pb-bt-list-muted">${ze(D.emmaBt.loading)}</span>`;return}e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function Qe(e,t,n){if(e.setAttribute(p,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="",e.dataset.surface==="room-detail"){const r=document.createElement("div");r.className="pb-bt-detail-label",r.textContent=D.emmaBt.brand,e.appendChild(r)}const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=D.emmaBt.clickToCopy,o.setAttribute("aria-label",`${D.emmaBt.brand}: ${n}`),Rn(o,n),e.appendChild(o)}function et(e,t){if(e.setAttribute(p,"1"),e.dataset.booking=t,e.dataset.state="none",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${ze(D.emmaBt.brand)}</div><span class="pb-bt-list-muted">—</span>`;return}e.innerHTML=""}function ze(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function je(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=_e(t);if(r&&r.code===null)return;e.dataset.state=""}const n=_e(t);if(n){n.code?Qe(e,t,n.code):et(e,t);return}An(e,t);const o=await gt(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?Qe(e,t,o):et(e,t))}function qn(){const e=$n();if(!e){Ln()||document.querySelectorAll(`[${p}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=Bn(r);if(!a)continue;const i=Sn(a),s=a.querySelector(`[${p}]`);if(!i){(s==null?void 0:s.dataset.state)==="ok"&&n.add(s);continue}const l=Mn(a,i);n.add(l),je(l,i)}document.querySelectorAll(`[${p}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function Dn(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function _n(){const e=Cn(),t=new Set(e);if(e.length===0){Dn()||document.querySelectorAll(`[${p}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=kn(o),a=o.querySelector(`[${p}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&In(o)){n.add(a);continue}a==null||a.remove();continue}const i=En(o,r);n.add(i),je(i,r)}document.querySelectorAll(`[${p}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function zn(){const e=document.querySelectorAll('.sapMPageEnableScrolling, section.sapMPageEnableScrolling, [id$="-cont"].sapUiScrollDelegate');for(const t of e){if(t.querySelector(".sapMGT.roomTiles, .sapMGT.roomTiles2"))continue;const n=t.querySelector('.sapMTitle, .sapMTitle-inner, [class*="sapMTitle"]'),o=((n==null?void 0:n.textContent)||"").replace(/\s+/g," ").trim();if((/^room\s+\d+/i.test(o)||/^zimmer\s+\d+/i.test(o)||[...t.querySelectorAll("bdi, .sapMBtnContent")].some(a=>/check\s*out|change\s*room\s*status/i.test((a.textContent||"").trim())))&&$t(t))return t}return null}function $t(e){var t;for(const n of e.querySelectorAll(".sapMLabel, .sapMLabel bdi")){const o=(n.textContent||"").replace(/\s+/g," ").trim().replace(/:$/,"");if(!/^(reservation|reservierung)$/i.test(o))continue;const r=((t=n.closest('[class*="wrapperfor"]'))==null?void 0:t.parentElement)||n.closest(".sapUiFormResGridCont")||n.closest(".sapUiRespGrid")||e;for(const a of r.querySelectorAll("a.sapMLnk")){const i=(a.textContent||"").trim();if(/^\d{6,}$/.test(i))return ee(i)}}for(const n of e.querySelectorAll("a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return ee(o)}return null}function Hn(e,t){let n=e.querySelector(`[${p}][data-surface="room-detail"]`);if(n)return n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n;n=document.createElement("div"),n.setAttribute(p,"1"),n.dataset.booking=t,n.dataset.surface="room-detail",n.setAttribute("role","region"),n.setAttribute("aria-label",D.emmaBt.brand);const o=e.querySelector(":scope > .sapMHBox"),r=e.querySelector('.sapUiForm, [role="form"]');return(o==null?void 0:o.parentElement)===e?o.insertAdjacentElement("afterend",n):r?r.insertAdjacentElement("beforebegin",n):e.insertBefore(n,e.firstChild),n}function Pn(){const e=zn();if(!e){document.querySelectorAll(`[${p}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const t=$t(e);if(!t){document.querySelectorAll(`[${p}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const n=Hn(e,t);je(n,t)}function Ct(){if(!xn()){document.querySelectorAll(`[${p}]`).forEach(e=>e.remove());return}Tn(),qn(),_n(),Pn()}function ie(){de&&window.clearTimeout(de),de=window.setTimeout(()=>{Ct()},280)}function Nn(){be().then(t=>{D=I(t),ie()}),ge(t=>{D=I(t),document.querySelectorAll(`[${p}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),ie()}),Ct(),window.addEventListener("hashchange",()=>ie());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===Ie||o.closest(`[${p}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${p}]`)||r.closest(`[${p}]`))))){ie();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(Oe(),document.querySelectorAll(`[${p}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),ie())})}catch{}return()=>{var t;e.disconnect(),de&&window.clearTimeout(de),(t=document.getElementById(Ie))==null||t.remove(),document.querySelectorAll(`[${p}]`).forEach(n=>n.remove())}}const tt="CHBRNPR",He="100",Tt="ZEYUI_RSRVS_SRV";function Fn(e){const t=parseInt(e,10);return Number.isFinite(t)?String(t).padStart(4,"0"):e.trim()}function On(e,t,n=new Date){const o=(a,i)=>String(a).padStart(i,"0"),r=[o(n.getFullYear(),4),o(n.getMonth()+1,2),o(n.getDate(),2),o(n.getHours(),2),o(n.getMinutes(),2),o(n.getSeconds(),2)].join("");return`${e}   ${t}${r}000`}function Un(e,t,n){const o=Math.random().toString(16).slice(2,14).padEnd(12,"0"),r=`batch_${o.slice(0,4)}-${o.slice(4,8)}-${o.slice(8,12)}`,a=`changeset_${o.slice(2,6)}-${o.slice(6,10)}-${o.slice(0,4)}`,i=`id-${Date.now()}-1000`;let s=`\r
`;return s+=`--${r}\r
`,s+=`Content-Type: multipart/mixed; boundary=${a}\r
\r
`,s+=`--${a}\r
`,s+=`Content-Type: application/http\r
`,s+=`Content-Transfer-Encoding: binary\r
\r
`,s+=`POST ${e} HTTP/1.1\r
`,s+=`tms-fioriapp: CheckIn\r
`,s+=`Request-Object-Key: ${n}\r
`,s+=`Request-Object-Type: RSRV\r
`,s+=`sap-contextid-accept: header\r
`,s+=`Accept: application/json\r
`,s+=`x-csrf-token: ${t}\r
`,s+=`Accept-Language: en\r
`,s+=`DataServiceVersion: 2.0\r
`,s+=`MaxDataServiceVersion: 2.0\r
`,s+=`X-Requested-With: XMLHttpRequest\r
`,s+=`Content-Type: application/json\r
`,s+=`Content-ID: ${i}\r
\r
`,s+=`\r
`,s+=`--${a}--\r
\r
`,s+=`--${r}--\r
`,{body:s,contentType:`multipart/mixed;boundary=${r}`}}async function jn(){const e=await fetch(`${location.origin}/sap/opu/odata/sap/${Tt}/?sap-client=${He}`,{credentials:"include",headers:{"x-csrf-token":"Fetch",Accept:"application/json","X-Requested-With":"XMLHttpRequest"}}),t=e.headers.get("x-csrf-token");if(!e.ok||!t||t.toLowerCase()==="required")throw new Error("CSRF");return t}function Gn(e){const t=e.match(/HTTP\/1\.[01] ([45]\d\d)[^\n]*\n([\s\S]*?)(?:\n--|\s*$)/);if(!t)return null;const o=(t[2]??"").match(/"message"\s*:\s*\{[^}]*"value"\s*:\s*"([^"]+)"/);return(o==null?void 0:o[1])||`EMMA ${t[1]}`}async function Vn(e,t){const n=await jn(),o=Fn(t),r=`RoomAssignment?sap-client=${He}&HotelId='${tt}'&ReservationId='${e}'&RoomId='${o}'`,a=Un(r,n,On(tt,e)),i=await fetch(`${location.origin}/sap/opu/odata/sap/${Tt}/$batch?sap-client=${He}`,{method:"POST",credentials:"include",headers:{"Content-Type":a.contentType,"x-csrf-token":n,Accept:"multipart/mixed","X-Requested-With":"XMLHttpRequest",DataServiceVersion:"2.0",MaxDataServiceVersion:"2.0"},body:a.body}),s=await i.text(),l=Gn(s);if(!i.ok||l)throw new Error(l||`EMMA ${i.status}`)}let u=I("de");const m="prize-ra-host",ue="prize-ra-style",h="data-prize-room-assign";function Wn(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Pe(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${h}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o}return null}function St(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function te(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function Yn(e){const t=te(e);return ft(t)!=null}function Xn(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=te(r);if(a)return a}}return null}function fe(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&St(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Kn(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&St(o))return o}const t=fe();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function Zn(){const e=Kn();return e?e.closest(".sapMFlexItem")??e.parentElement:null}function Le(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const d=(l instanceof HTMLInputElement?l.value:l.textContent||"").trim();if(d&&!t.test(d))return d}a=a.parentElement}}return null}function Jn(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=Le(n,/^Arrival\s*Date$/i)||Le(n,/^Arrival$/i)||Le(n,/^Anreise(datum)?$/i);if(!o)continue;const r=V(o);if(r)return r}return null}function Qn(){if(Xn())return!1;const e=Jn();return e?yt(e):!0}function kt(e,t){const n=te(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}const eo=2e4;let B=null,se=null;const Re=new Set;let y=null,N=!1,L=!1;function Et(e){const t={vip:u.emmaRoom.reasonVip,premium:u.emmaRoom.reasonPremium,repeat:u.emmaRoom.reasonRepeat,one_night:u.emmaRoom.reasonOneNight,long_stay:u.emmaRoom.reasonLongStay,three_pax:u.emmaRoom.reasonThreePax,no_basement:u.emmaRoom.reasonNoBasement,not_ready:u.emmaRoom.reasonNotReady,category_not_ready:u.emmaRoom.reasonCategoryNotReady,overbook_view:u.emmaRoom.reasonOverbookView,overbook_corner:u.emmaRoom.reasonOverbookCorner,overbook_standard:u.emmaRoom.reasonOverbookStandard,wheelchair:u.emmaRoom.reasonWheelchair};return e.map(n=>t[n]).filter(n=>!!n).slice(0,3).join(" · ")}function Ge(e,t){const n=o=>o.replace(/^0+/,"")||o;return e===t||n(e)===n(t)}function Be(e){const t=e instanceof Error?e.message:String(e??"");return/401|unauthorized|invalid token|jwt/i.test(t)?u.emmaRoom.signInRequired:u.emmaRoom.loadFailed}async function It(){const e=B!=null&&B.error?5e3:eo;return B&&Date.now()-B.at<e?B:se||(se=(async()=>{let t;try{const n=await he("/reservations/room-suggestions");t={at:Date.now(),items:n.items??[],error:null}}catch(n){t={at:Date.now(),items:[],error:Be(n)}}return B=t,t})().finally(()=>{se=null}),se)}function Bt(e){return e.replace(/^0+/,"")||e}async function to(e){const t=Date.now(),n=[...new Set(e.map(Bt))].filter(o=>t-($e.get(o)??0)>15e3);if(!n.length)return!1;for(const o of n)$e.set(o,t);try{const o=await he("/reservations/room-suggestions/unassigned",{method:"POST",body:JSON.stringify({reservationIds:n})});return B={at:Date.now(),items:o.items??[],error:null},!0}catch{for(const o of n)$e.delete(o);return!1}}function no(e,t){var n;return((n=e.find(o=>Ge(o.reservationId,t)))==null?void 0:n.suggestion)??null}function Ve(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!t.closest(`[${h}]`))return t;return null}function Mt(e,t){const n=Ve(e);if(n){n.nextElementSibling!==t&&n.insertAdjacentElement("afterend",t);return}const o=e.querySelector(".sapUiTableCellInner")||e;t.parentElement!==o&&o.appendChild(t)}function nt(e,t,n){const o=Ve(e);let r=e.querySelector(`[${h}="row"]`);const a=o?o.nextElementSibling===r:(r==null?void 0:r.parentElement)===(e.querySelector(".sapUiTableCellInner")||e);if(r&&a&&r.dataset.note===t&&r.dataset.error===(n?"1":"0"))return r;r||(r=document.createElement("div"),r.setAttribute(h,"row")),Mt(e,r),r.dataset.error=n?"1":"0",r.dataset.booking="",r.dataset.room="",r.dataset.note=t,r.innerHTML="";const i=document.createElement("span");return i.className=`pb-ra-row-note${n?" is-error":""}`,i.textContent=t,i.title=t,r.appendChild(i),r}async function Lt(e){return B=null,await he(`/reservations/${encodeURIComponent(e.reservationId)}/room-suggestion/accept`,{method:"POST",body:JSON.stringify({roomNumber:e.roomNumber})}),B=null,e.roomNumber}async function oo(e){return await Vn(e.reservationId,e.roomNumber),Lt(e)}async function ro(e){var o,r;const t=kt(e.roomNumber,(o=fe())==null?void 0:o.value);if(await uo(t),te(((r=fe())==null?void 0:r.value)??"")!==te(t))throw new Error("room field");return Lt(e)}async function ao(e){B=null;const t=await he(`/reservations/${encodeURIComponent(e)}/room-suggestion/arriving-now`,{method:"POST"});return B=null,t.suggestion}async function io(e,t){B=null;const n=await he(`/reservations/${encodeURIComponent(e)}/room-suggestion/shift`,{method:"POST",body:JSON.stringify({direction:t})});return B=null,n.suggestion}function so(){let e=document.getElementById(ue);e||(e=document.createElement("style"),e.id=ue,document.documentElement.appendChild(e)),e.dataset.v!=="9"&&(e.dataset.v="9",e.textContent=`
    /* Detail: fixed overlay beside the Room input, outside the SAP flex row */
    #${m}{
      box-sizing:border-box;
      position:fixed;
      display:flex;
      flex-direction:column;
      align-items:flex-start;
      gap:2px;
      margin:0;
      max-width:240px;
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:transparent;
      border:0;
      box-shadow:none;
      padding:0;
      z-index:30;
      pointer-events:auto;
    }
    #${m} *{box-sizing:border-box;}
    #${m} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${m} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${m} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${m} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${m} .pb-ra-main{
      display:flex;align-items:center;gap:6px;flex-wrap:nowrap;
      background:#fff;border:1px solid rgba(45,58,79,.16);border-radius:8px;
      padding:3px 6px;box-shadow:0 1px 4px rgba(15,23,42,.12);
    }
    #${m} .pb-ra-room{
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:16px;font-weight:800;letter-spacing:.03em;line-height:1.1;
      color:#1a2332;
    }
    #${m} .pb-ra-meta{
      font-size:9px;color:#64748b;margin-top:1px;font-weight:500;
    }
    #${m} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${m} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:26px;height:26px;border-radius:7px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
    }
    #${m} .pb-ra-btn:hover{background:#f1f5f9;}
    #${m} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${m} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${m} .pb-ra-nudge{display:flex;flex-direction:column;gap:2px;}
    #${m} .pb-ra-nudge .pb-ra-btn{width:22px;height:16px;border-radius:5px;}
    #${m} .pb-ra-nudge .pb-ra-btn svg{width:11px;height:11px;}
    #${m} .pb-ra-actions{display:flex;align-items:center;gap:4px;}
    #${m} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${m} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${m} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${m} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${m} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${m} .pb-ra-note{
      font-size:12px;font-weight:650;color:#9a3412;line-height:1.25;
    }

    /* Check-in list Room column — same line as the empty room number */
    .sapUiTableDataCell:has([${h}="row"]) .sapUiTableCellInner,
    .sapUiTableDataCell:has([${h}="row"]) .sapMVBox{
      overflow:visible !important;
      max-height:none !important;
    }
    [${h}="row"]{
      display:inline-flex !important;
      align-items:center;
      gap:0.25rem;
      margin:0;
      line-height:1.15;
      max-width:100%;
      flex-shrink:0;
      position:relative;
      z-index:20;
      pointer-events:auto;
      vertical-align:middle;
    }
    [${h}="row"] .pb-ra-row-code{
      appearance:none;cursor:pointer;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:0.78rem;font-weight:800;letter-spacing:.03em;
      color:#0f172a;
      background:#dbeafe;
      border:1px solid #2563eb;
      border-radius:0.25rem;
      padding:0.15rem 0.45rem;
      white-space:nowrap;
    }
    [${h}="row"] .pb-ra-row-code:hover{filter:brightness(0.97);}
    [${h}="row"] .pb-ra-row-note{
      display:inline-block;max-width:9.5rem;margin-left:4px;
      font-size:10px;font-weight:650;line-height:1.2;color:#9a3412;
    }
    [${h}="row"] .pb-ra-row-note.is-error{color:#9b1c1c;}
    #${m} .pb-ra-now{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      border-radius:6px;padding:3px 6px;font-size:10px;font-weight:700;color:#1a2332;
    }
    #${m} .pb-ra-now:hover{background:#f1f5f9;}
    [${h}="row"] .pb-ra-row-code.pb-ra-dirty{background:#ffedd5;border-color:#c2410c;color:#9a3412;}
    [${h}="row"] .pb-ra-row-accept{
      appearance:none;cursor:pointer;border:1px solid #15803d;background:#15803d;color:#fff;
      border-radius:0.25rem;width:1.35rem;height:1.35rem;font-size:0.75rem;font-weight:800;
      line-height:1;
    }
  `)}function lo(){let e=document.getElementById(m);const t=!!(e!=null&&e.closest(".sapMHBox, .sapMInputBase, .sapMFlexItem"));if(e&&!t&&e.parentElement===document.body)return e;const n=e==null?void 0:e.dataset.key;return e==null||e.remove(),e=document.createElement("div"),e.id=m,e.setAttribute(h,"detail"),e.setAttribute("role","region"),e.setAttribute("aria-label",u.emmaRoom.title),n&&(e.dataset.key=n),document.body.appendChild(e),e}function J(){const e=document.getElementById(m),t=fe();if(!e||!t)return;const n=t.getBoundingClientRect(),o=e.offsetWidth||220;let r=n.right+8;r+o>window.innerWidth-8&&(r=Math.max(8,n.left)),e.style.top=`${Math.max(8,n.top)}px`,e.style.left=`${r}px`}function co(e){return e.roomStatus==="DIRTY"||e.roomStatus==="CLEAN"||e.roomStatus==="IN_PROGRESS"?!0:e.roomStatus==="INSPECTED"||e.roomStatus==="OUT_OF_ORDER"?!1:!e.readyNow}function uo(e){const t=`${Date.now()}-${Math.random().toString(16).slice(2)}`;return new Promise((n,o)=>{const r=window.setTimeout(()=>{document.removeEventListener("prize-ra-fill-room-done",a),o(new Error("room field"))},2500),a=i=>{const s=i.detail;!s||s.requestId!==t||(window.clearTimeout(r),document.removeEventListener("prize-ra-fill-room-done",a),s.error?o(new Error(s.error)):n())};document.addEventListener("prize-ra-fill-room-done",a),document.dispatchEvent(new CustomEvent("prize-ra-fill-room",{detail:{room:e,requestId:t}}))})}function po(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function ot(e){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="${e==="up"?"M6 14l6-6 6 6":"M6 10l6 6 6-6"}"/></svg>`}let A=null,pe=null,k="",M=!1,Ne=!1,Ae=!1,qe=!1,me=!1;const $e=new Map;function mo(e){const t=fe();if(!t)return!1;const n=t.value,o=kt(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function _(e){var v,$,P,T;if(e.setAttribute("aria-label",u.emmaRoom.title),N&&!y){e.innerHTML=`<div class="pb-ra-note">${H(u.emmaRoom.loading)}</div>`,J();return}if(!y){if(me&&!k){e.innerHTML=`<div class="pb-ra-note">${H(u.emmaRoom.loading)}</div>`,J();return}e.innerHTML=`<div class="pb-ra-note">${H(k||u.emmaRoom.noSuggestion)}</div>`,J();return}const t=Gt(y.floor??ft(y.roomNumber)),n=y.readyNow?u.emmaRoom.ready:u.emmaRoom.dirty,o=Et(y.reasons),r=[t,n,o].filter(Boolean).join(" · "),a=k?`<div class="pb-ra-status${M?" pb-ra-warn":""}">${H(k)}</div>`:"",i=u.emmaRoom.accept,s=u.emmaRoom.higher,l=u.emmaRoom.lower,c=u.emmaRoom.arrivingNow,d=co(y)?`<button type="button" class="pb-ra-now">${H(c)}</button>`:"";e.innerHTML=`<div class="pb-ra-main"><div><div class="pb-ra-room">${H(y.roomNumber)}</div><div class="pb-ra-meta">${H(r)}</div></div><div class="pb-ra-actions"><div class="pb-ra-nudge"><button type="button" class="pb-ra-btn pb-ra-up" title="${W(s)}" aria-label="${W(s)}">${ot("up")}</button><button type="button" class="pb-ra-btn pb-ra-down" title="${W(l)}" aria-label="${W(l)}">${ot("down")}</button></div><button type="button" class="pb-ra-btn pb-ra-accept" title="${W(i)}" aria-label="${W(i)}">${po()}</button></div></div>`+d+a+`<div class="pb-ra-note">${H(u.emmaRoom.previewNote)}</div>`,J();const f=C=>{const z=Pe();if(!z||!y||L)return;const S=y;L=!0,N=!0,_(e),io(z,C).then(ne=>{y=ne??S,A=null,k=ne?"":C==="up"?u.emmaRoom.noHigher:u.emmaRoom.noLower,M=!ne}).catch(ne=>{y=S,k=Be(ne),M=!0}).finally(()=>{L=!1,N=!1,_(e),O()})};(v=e.querySelector(".pb-ra-up"))==null||v.addEventListener("click",C=>{C.preventDefault(),C.stopPropagation(),f("up")}),($=e.querySelector(".pb-ra-down"))==null||$.addEventListener("click",C=>{C.preventDefault(),C.stopPropagation(),f("down")}),(P=e.querySelector(".pb-ra-accept"))==null||P.addEventListener("click",C=>{if(C.preventDefault(),C.stopPropagation(),!y||L)return;const z=y;L=!0,ro(z).then(S=>{mo(S),k=ut(u.emmaRoom.applied,{room:S}),M=!1,y=null,A=null}).catch(S=>{k=S instanceof Error&&S.message&&S.message!=="CSRF"?`${u.emmaRoom.assignFailed}: ${S.message}`:u.emmaRoom.assignFailed,M=!0}).finally(()=>{L=!1,_(e),O()})}),(T=e.querySelector(".pb-ra-now"))==null||T.addEventListener("click",C=>{C.preventDefault(),C.stopPropagation();const z=Pe();!z||L||(L=!0,N=!0,_(e),ao(z).then(S=>{y=S,A=null,k=S?"":u.emmaRoom.noSuggestion,M=!S}).catch(S=>{k=Be(S),M=!0}).finally(()=>{L=!1,N=!1,_(e),O()}))})}function H(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function W(e){return H(e).replace(/'/g,"&#39;")}function fo(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function bo(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((i,s)=>{const l=(i.textContent||"").replace(/:/g,"").replace(/\s+/g," ").trim().toLowerCase();(l==="room"||l==="zimmer")&&(t=s),(l==="arrival"||l==="anreise")&&(n=s)}),{room:t,arrival:n}}function rt(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function go(e){const t=/-col0$/;let n=null;for(const o of e.querySelectorAll('[id*="-col"]'))if(t.test(o.id)){n=o;break}if(n||(n=e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")),!n)return null;for(const o of n.querySelectorAll(".sapMText, a.sapMLnk")){if(o.closest(`[${h}]`))continue;const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r}return null}function ho(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${h}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&Yn(n))return te(n)}return null}function yo(e){for(const t of e.querySelectorAll(".sapMText")){const n=(t.textContent||"").trim(),o=V(n);if(o)return o}return V((e.textContent||"").trim())}function vo(e,t){if(t){const n=yo(t);if(n)return n}for(const n of e.querySelectorAll(".sapMText")){if(n.closest(`[${h}]`))continue;const o=V((n.textContent||"").trim());if(o)return o}return null}function wo(e,t){const n=t.reservationId,o=t.roomNumber;let r=e.querySelector(`[${h}="row"]`);const a=Ve(e);if(r&&r.dataset.booking===n&&r.dataset.room===o&&r.dataset.ready===String(t.readyNow)&&(a==null?void 0:a.nextElementSibling)===r)return r;r||(r=document.createElement("div"),r.setAttribute(h,"row")),Mt(e,r),r.dataset.booking=n,r.dataset.room=o,r.dataset.ready=String(t.readyNow),r.innerHTML="";const i=document.createElement("button");i.type="button",i.className=`pb-ra-row-code${t.readyNow?"":" pb-ra-dirty"}`;const s=o.padStart(4,"0");i.textContent=s;const l=Et(t.reasons);i.title=[u.emmaRoom.title,s,t.readyNow?u.emmaRoom.ready:u.emmaRoom.dirty,l].filter(Boolean).join(" · "),i.setAttribute("aria-label",i.title);const c=document.createElement("button");return c.type="button",c.className="pb-ra-row-accept",c.textContent="✓",c.title=u.emmaRoom.accept,c.setAttribute("aria-label",u.emmaRoom.accept),c.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),!L&&(L=!0,oo(t).then(()=>{const f=e.querySelector(".sapMText, a.sapMLnk");f&&!f.closest(`[${h}]`)&&(f.textContent=s),r==null||r.remove()}).catch(()=>{i.title=u.emmaRoom.assignFailed}).finally(()=>{L=!1}))}),r.appendChild(i),r.appendChild(c),r}function xo(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}async function at(e){const t=fo();if(!t){xo()||document.querySelectorAll(`[${h}="row"]`).forEach(l=>l.remove());return}const n=bo(t),o=t.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),r=new Set(o),a=new Set,i=new Set,s=await It();for(const l of o){const c=go(l);if(!c)continue;const d=rt(l,n.room),f=rt(l,n.arrival);if(!d)continue;const v=ho(d),$=d.querySelector(`[${h}="row"]`);if(v){$e.delete(Bt(c)),$==null||$.remove();continue}const P=vo(l,f);if(P&&!yt(P)){$==null||$.remove();continue}if(s.error){a.add(nt(d,s.error,!0));continue}const T=s.items.find(z=>Ge(z.reservationId,c)),C=T!=null&&T.suggestion?T.suggestion.roomNumber.replace(/^0+/,""):"";if(!(T!=null&&T.suggestion)||C&&i.has(C)){T||e==null||e.add(c),T?a.add(nt(d,u.emmaRoom.noSuggestion,!1)):me||$==null||$.remove();continue}i.add(C),a.add(wo(d,T.suggestion))}document.querySelectorAll(`[${h}="row"]`).forEach(l=>{if(!(l instanceof HTMLElement)||a.has(l))return;const c=l.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!c||!r.has(c))&&l.remove()})}function Me(){var e;(e=document.getElementById(m))==null||e.remove(),A=null,y=null,N=!1,k="",M=!1}async function it(e){var s;const t=Pe();if(!Zn()||!t){Me();return}if(!Qn()){Me();return}const o=((s=document.getElementById(m))==null?void 0:s.parentElement)===document.body,r=lo();J();const a=t;if(!o&&r.dataset.key===a&&_(r),r.dataset.key===a||Re.has(a))return;Re.add(a);const i=A!==a;A=a,i&&(k="",M=!1),N=!0,_(r);try{const l=await It();if(A!==a)return;l.error?(y=null,k=l.error,M=!0):(y=no(l.items,t),y||(l.items.some(d=>Ge(d.reservationId,t))?(k=u.emmaRoom.noSuggestion,M=!0):(e==null||e.add(t),k="",M=!1))),r.dataset.key=a}catch(l){if(A!==a)return;y=null,k=Be(l),M=!0,r.dataset.key=a}finally{N=!1,Re.delete(a)}A===a&&_(r)}async function Rt(){if(Ae){qe=!0;return}Ae=!0,Ne=!0;try{if(!Wn()){Me(),document.querySelectorAll(`[${h}="row"]`).forEach(t=>t.remove());return}so();const e=new Set;if(me=!1,await at(e),await it(e),e.size){me=!0;const t=document.getElementById(m);t&&_(t);const n=await to([...e]);me=!1,n?(t&&delete t.dataset.key,await at(),await it()):t&&_(t)}}finally{Ae=!1,window.setTimeout(()=>{Ne=!1,qe&&(qe=!1,O())},0)}}function O(){pe&&window.clearTimeout(pe),pe=window.setTimeout(()=>{Rt()},350)}function $o(){be().then(n=>{u=I(n),A=null,O()}),ge(n=>{u=I(n),A=null,O()}),Rt();const e=()=>J();window.addEventListener("scroll",e,!0),window.addEventListener("resize",e),window.addEventListener("hashchange",()=>{var n;A=null,y=null,(n=document.getElementById(m))==null||n.removeAttribute("data-key"),O()});const t=new MutationObserver(n=>{if(!Ne)for(const o of n){const r=o.target;if(r instanceof Element&&(r.id===m||r.id===ue||r.closest(`[${h}]`)))continue;const a=[...o.addedNodes];if(!(a.length>0&&a.every(i=>i instanceof Element&&(i.id===m||i.id===ue||i.hasAttribute(h))))){O();return}}});return t.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var n;t.disconnect(),pe&&window.clearTimeout(pe),Me(),document.querySelectorAll(`[${h}="row"]`).forEach(o=>o.remove()),(n=document.getElementById(ue))==null||n.remove()}}const st="prize-panel-host";let F=I("de");function At(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function Ce(e,t,n){const o=`${Te}px 0 0 ${Te}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=At(),t.title=F.inject.openPanel,t.setAttribute("aria-label",F.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${dt}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=F.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function lt(e,t,n){var i;const r=!await Fe(U.panelCollapsed);await zt({[U.panelCollapsed]:r}),Ce(e,t,r);const a=e.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?Q.collapsed:Q.expanded},"*")}function ct(){if(document.getElementById(st))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${Te}px 0 0 ${Te}px`,r=document.createElement("div");r.id=st,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${Dt}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:ve,border:`1px solid ${De}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=F.inject.panelTitle,Object.assign(i.style,{width:`${dt}px`,height:"100%",border:"none",display:"block",background:ve}),a.appendChild(i);const s=document.createElement("button");s.id="prize-panel-tab",s.type="button",Object.assign(s.style,{width:`${We}px`,height:`${_t}px`,minWidth:`${We}px`,border:`1px solid ${De}`,borderRight:"none",background:`linear-gradient(180deg, ${ve} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),s.innerHTML=At(),s.addEventListener("mouseenter",()=>{s.style.filter="brightness(1.12)"}),s.addEventListener("mouseleave",()=>{s.style.filter=""}),s.addEventListener("click",()=>{lt(a,s)}),r.appendChild(a),r.appendChild(s),document.documentElement.appendChild(r),Fe(U.panelCollapsed).then(l=>{t=l,Ce(a,s,l)}),window.addEventListener("message",l=>{var c,d,f,v;((c=l.data)==null?void 0:c.type)===Q.toggle&&lt(a,s),((d=l.data)==null?void 0:d.type)===Q.chatOpen&&(e=!0,n()&&((f=document.getElementById("prize-panel-chat-toast"))==null||f.remove())),((v=l.data)==null?void 0:v.type)===Q.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((l,c)=>{c==="local"&&l[U.panelCollapsed]&&(t=!!l[U.panelCollapsed].newValue)}),tn(n),wn(),Nn(),$o(),be().then(l=>{F=I(l),Ce(a,s,t),i.title=F.inject.panelTitle}),ge(l=>{F=I(l),Ce(a,s,t),i.title=F.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",ct):ct();
