import{S as a,s,D as o}from"./storage-DBVvwjza.js";chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.get([a.apiBase],e=>{e[a.apiBase]||s({[a.apiBase]:o})})});
