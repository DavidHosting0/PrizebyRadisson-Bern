import{b as Te,S as D,P as O,c as ie,d as xe,A as gt,e as de,f as ht,g as Ve,T as Le,h as yt,s as vt}from"./storage-DTWcLCTt.js";import{l as ne,w as oe,i as We,g as C,a as Ye,b as xt,p as $t,c as Xe,d as wt,t as Ae,B as Ct,e as Tt,f as St,h as Se}from"./bernticket-api-Dignfxwu.js";const Re=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function kt(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function Ke(e){if(kt(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=Re.length;n++){const[o,r]=Re[n-1];if(t>=o&&t<=r)return n}return null}function Et(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let Z=C("de");const B="prize-panel-chat-toast",qe="prize-panel-chat-toast-style",Bt=8e3,It=7e3;function Mt(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function Lt(e){return e==="/r"||e.startsWith("/r/")}function At(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function Rt(){if(document.getElementById(qe))return;const e=document.createElement("style");e.id=qe,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${B}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${ie} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${xe};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${B}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${B} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${B} .pb-ct-body{min-width:0;flex:1;}
    #${B} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${gt};margin-bottom:2px;
    }
    #${B} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${B} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${B} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${B} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let se=null;function P(e=!0){const t=document.getElementById(B);if(t){if(se&&(window.clearTimeout(se),se=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function qt(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,i,s)=>{const l=t.createOscillator(),p=t.createGain();l.type="sine",l.frequency.setValueAtTime(a,i),p.gain.setValueAtTime(1e-4,i),p.gain.exponentialRampToValueAtTime(.9,i+.015),p.gain.exponentialRampToValueAtTime(1e-4,i+s),l.connect(p),p.connect(o),l.start(i),l.stop(i+s+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function Dt(e,t){Rt(),P(!1);const n=document.createElement("div");n.id=B,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),s=r.querySelector(".pb-ct-preview");a.textContent=Z.toast.eyebrow,i.textContent=We(Z.toast.newMessageFrom,{author:e}),s.textContent=At(t);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",Z.toast.close),l.textContent="×",l.addEventListener("click",p=>{p.stopPropagation(),P(!0)}),n.addEventListener("click",()=>P(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),qt(),se=window.setTimeout(()=>{P(!0)},It)}function _t(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:O.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function zt(e){let t=!1,n=null,o=!0;ne().then(s=>{Z=C(s)});const r=oe(s=>{Z=C(s)});Te(D.chatNotificationsEnabled,!0).then(s=>{o=s});try{chrome.storage.onChanged.addListener((s,l)=>{if(l==="local"&&s[D.chatNotificationsEnabled]){const p=s[D.chatNotificationsEnabled].newValue;o=p===void 0?!0:!!p,o||P(!1)}})}catch{}const a=async()=>{var s,l,p;if(!t)try{if(!o)return;const c=await _t();if(!c.ok)return;const u=c.msg;if(!(u!=null&&u.id))return;if(n===null){n=u.id;return}if(u.id===n||(n=u.id,(s=u.author)!=null&&s.id&&c.meId&&u.author.id===c.meId)||e()||Mt(window.location.pathname)||Lt(window.location.pathname))return;const f=((p=(l=u.author)==null?void 0:l.name)==null?void 0:p.trim())||"Team";Dt(f,u.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},Bt);return()=>{t=!0,window.clearInterval(i),r(),P(!1)}}const Ze=300*1e3,z=new Map,le=new Map;function V(e){return e.replace(/^0+/,"")||e}function $e(e){const t=z.get(V(e));return!t||Date.now()-t.at>=Ze?null:{code:t.code}}function Ht(e,t){z.set(V(e),{code:t,at:Date.now()})}function ke(){z.clear(),le.clear()}async function Je(e){const t=V(e),n=z.get(t);if(n&&Date.now()-n.at<Ze)return n.code;let o=le.get(t);return o||(o=(async()=>{try{const r=await Ye();if(!(r!=null&&r.access))return z.set(t,{code:null,at:Date.now()}),null;const a=await xt(t),i=$t(a,t),s=Xe(i);return z.set(t,{code:s,at:Date.now()}),s}catch{return z.set(t,{code:null,at:Date.now()}),null}finally{le.delete(t)}})(),le.set(t,o)),o}async function Ft(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}const Pt={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function H(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=Pt[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const i=new Date(a),s=i.getFullYear(),l=String(i.getMonth()+1).padStart(2,"0"),p=String(i.getDate()).padStart(2,"0");if(s>=2e3)return`${s}-${l}-${p}`}return null}function Qe(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Nt(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function et(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:H(e);return!!(t&&t===Qe())}let b=C("de");const h="prize-bt-checkin-host",ue="prize-bt-checkin-style",x="prize-bt-fallback-bar",v="prize-bt-create-dialog";function jt(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function tt(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function pe(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function Ut(){const e=pe();if(e)return e;if(tt())return null;for(const o of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r.replace(/^0+/,"")||r}const t=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),n=((t==null?void 0:t.textContent)||"").match(/\b(\d{6,})\b/);return n?n[1].replace(/^0+/,"")||n[1]:null}function Ot(){return!!document.querySelector(['.sapUiLocalBusyIndicator:not([style*="display: none"])',".sapUiBusy",".sapMBusyDialog",".sapUiBlockLayer",".sapUiBLy",".sapUiLocalBusyIndicatorAnimation",'[class*="BusyIndicator"]:not([style*="display: none"])'].join(", "))}function De(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function Ee(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function N(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const c=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(c&&!t.test(c))return c}a=a.parentElement}}return null}function Gt(){const e=Ee()||document.body,t=N(e,/^Arrival\s*Date$/i)||N(e,/^Anreise(datum)?$/i),n=N(e,/^Departure\s*Date$/i)||N(e,/^Abreise(datum)?$/i),o=t&&H(t)||Qe(),r=n&&H(n)||Nt();return{from:o,to:r}}function Vt(){const e=Ee()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=N(t,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function Wt(){const e=Ee()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=N(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function Yt(e){const t=Gt();return{guestName:Wt(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:Vt()}}function Xt(){const e=document.getElementById(ue);e&&e.remove();const t=document.createElement("style");t.id=ue,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${h}),
    .sapMTBSpacerFlex:has(#${h}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${h}.sapMBarChild,
    #${h}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${h} *{box-sizing:border-box;}
    #${h} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${h} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);font-weight:700;
      letter-spacing:.04em;line-height:1.2;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.25rem;
      padding:0.35rem 0.6rem;
      min-width:0;text-align:center;
    }
    #${h} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${h} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${h} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${h} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${h} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${h} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${x}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.35rem;
      padding:0.2rem 0.45rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.75rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.25rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${x} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${x} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${x} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.04em;
      font-size:0.75rem;line-height:1.2;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.2rem;padding:0.15rem 0.4rem;
    }
    #${x} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${x} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${v}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${v} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${v} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${v} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${v} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${v} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${v} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${v} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${v} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${v} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${v} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${v} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${v} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${v} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${v} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${v} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function j(){var e;(e=document.getElementById(v))==null||e.remove()}function _e(e){var o,r;(o=document.getElementById(x))==null||o.remove();let t=document.getElementById(h);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=h,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",b.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function Kt(){var t;(t=document.getElementById(h))==null||t.remove();let e=document.getElementById(x);return e||(e=document.createElement("div"),e.id=x,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",b.emmaBt.brand),document.documentElement.appendChild(e),e)}function W(e,t){e.innerHTML=t}function Y(e){return`<span class="pb-bt-label">${w(b.emmaBt.brand)}</span>${e}`}async function Zt(e){try{await navigator.clipboard.writeText(e)}catch{}}function Jt(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{Zt(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=b.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function Qt(e,t,n,o){j();const r=document.createElement("div");r.id=v,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${_(b.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${w(b.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${_(b.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${w(b.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${_(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${w(b.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${_(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${w(b.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${_(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${w(b.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${_(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${w(b.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${w(b.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${w(b.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(l=>{l.addEventListener("click",()=>j())});const s=l=>{l.key==="Escape"&&(j(),window.removeEventListener("keydown",s))};window.addEventListener("keydown",s),i.addEventListener("click",()=>{(async()=>{const l=r.querySelector(".pb-bt-dlg-name"),p=r.querySelector(".pb-bt-dlg-from"),c=r.querySelector(".pb-bt-dlg-to"),u=r.querySelector(".pb-bt-dlg-amt"),f=(l==null?void 0:l.value.trim())||"";if(!f){a.hidden=!1,a.textContent=b.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=b.common.ellipsis,a.hidden=!0;try{const S=await wt({guestName:f,bookingNumber:t,validFrom:Ae((p==null?void 0:p.value)||n.from),validTo:Ae((c==null?void 0:c.value)||n.to),ticketsAmount:Math.max(1,parseInt((u==null?void 0:u.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});j(),o(Xe(S))}catch(S){if(S instanceof Ct&&S.code===Tt){const re=window.prompt(b.emmaBt.twoFaPrompt);if(re)try{await St(re),i.disabled=!1,i.textContent=b.emmaBt.create,i.click();return}catch(Me){a.hidden=!1,a.textContent=Me instanceof Error?Me.message:b.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=b.emmaBt.create;return}}a.hidden=!1,a.textContent=S instanceof Error?S.message:b.emmaBt.error,i.disabled=!1,i.textContent=b.emmaBt.create}})()})}let E=null,F=null,J=null,ae=0;async function me(e,t,n){var l,p;const o=++ae,r=await Ye();if(o!==ae)return;if(!r.access){W(e,Y(`<span class="pb-bt-muted">${w(b.emmaBt.loginHint)}</span>`)),e.dataset.fetched="1";return}const a=b.bernticket.copyCode,i=c=>{W(e,Y(`<button type="button" class="pb-bt-code" title="${_(a)}">${w(c)}</button>`)),Jt(e,c),e.dataset.fetched="1"},s=$e(t);if(s!=null&&s.code){i(s.code);return}if(!(e.dataset.bound===t&&e.dataset.fetched==="1"&&e.querySelector(".pb-bt-code, .pb-bt-open-create, .pb-bt-muted"))){W(e,Y(`<span class="pb-bt-muted">${w(b.emmaBt.loading)}</span>`));try{const c=await Je(t);if(o!==ae)return;if(c){i(c);return}const u=Yt(t);W(e,Y(`<button type="button" class="pb-bt-btn pb-bt-open-create">${w(b.emmaBt.openCreate)}</button>`)),e.dataset.fetched="1",(l=e.querySelector(".pb-bt-open-create"))==null||l.addEventListener("click",()=>{Qt(e,t,u,f=>{f?(Ht(t,f),i(f)):(e.dataset.fetched="",E=null,me(e,t,!0))})})}catch(c){if(o!==ae)return;W(e,Y(`<span class="pb-bt-muted">${w(c instanceof Error?c.message:b.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${w(b.emmaBt.retry)}</button>`)),e.dataset.fetched="1",(p=e.querySelector(".pb-bt-retry"))==null||p.addEventListener("click",()=>{ke(),e.dataset.fetched="",E=null,me(e,t)})}}}function w(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function _(e){return w(e).replace(/'/g,"&#39;")}function X(){J&&window.clearTimeout(J),J=window.setTimeout(()=>{nt()},700)}function en(e){return document.documentElement.contains(e)}async function nt(){var a,i,s,l,p,c;if(!jt()){(a=document.getElementById(h))==null||a.remove(),(i=document.getElementById(x))==null||i.remove(),j(),E=null,F=null;return}Xt();const e=Ot();let t=Ut();if(t?F=t:e&&F?t=F:!e&&!pe()&&(F=null),!e&&tt()&&!pe()){(s=document.getElementById(h))==null||s.remove(),(l=document.getElementById(x))==null||l.remove(),E=null;return}if(!t){(p=document.getElementById(h))==null||p.remove(),(c=document.getElementById(x))==null||c.remove(),E=null;return}const n=document.getElementById(h)||document.getElementById(x);if(t===E&&n&&en(n)&&n.dataset.bound===t&&n.dataset.fetched==="1"){const u=e?null:De();if(u&&n.id===x&&!e){const f=_e(u);f!==n&&(f.dataset.bound=t,f.dataset.fetched="",n.remove(),E=t,await me(f,t))}return}const o=e?null:De(),r=o?_e(o):Kt();E=t,r.dataset.bound=t,await me(r,t)}function tn(){ne().then(t=>{b=C(t),E=null,X()}),oe(t=>{b=C(t),E=null,X()}),nt(),window.addEventListener("hashchange",()=>{E=null,pe()||(F=null);const t=document.getElementById(h)||document.getElementById(x);t instanceof HTMLElement&&(t.dataset.fetched=""),X()});const e=new MutationObserver(t=>{let n=!1;for(const o of t){const r=o.target;if(r instanceof Element&&!(r.id===h||r.id===x||r.id===ue||r.id===v||r.closest("[data-prize-bernticket]")||r.closest(`#${h}, #${x}, #${v}`))&&!(o.type==="childList"&&[...o.addedNodes,...o.removedNodes].length>0&&[...o.addedNodes,...o.removedNodes].every(a=>a instanceof Element&&(a.id===h||a.id===x||a.id===v||a.closest(`[data-prize-bernticket], #${h}, #${x}`))))){n=!0;break}}n&&X()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{if(n==="local"&&(t.btAccessToken||t.btRefreshToken)){E=null,ke();const o=document.getElementById(h)||document.getElementById(x);o instanceof HTMLElement&&(o.dataset.fetched=""),X()}})}catch{}return()=>{var t,n,o;e.disconnect(),J&&window.clearTimeout(J),(t=document.getElementById(h))==null||t.remove(),(n=document.getElementById(x))==null||n.remove(),(o=document.getElementById(ue))==null||o.remove(),j()}}let M=C("de");const fe="prize-bt-list-style",d="data-prize-bt-chip";let Q=null;function nn(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function on(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function rn(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function an(){let e=document.getElementById(fe);e||(e=document.createElement("style"),e.id=fe,document.documentElement.appendChild(e)),e.dataset.v!=="7"&&(e.dataset.v="7",e.textContent=`
    [${d}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: BELOW reservation number — do not sit in the number hbox */
    [${d}][data-surface="list"]{
      display:block !important;
      margin:0.15rem 0 0 0 !important;
      max-width:100%;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${d}]),
    .sapUiTableDataCell:has([${d}]),
    .sapMVBox:has([${d}]),
    .sapMHBox:has([${d}]){
      overflow:visible !important;
    }
    .sapUiTableCellInner:has([${d}[data-surface="list"]]){
      max-height:none !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${d}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    /* Room Status detail panel (click a room): large code */
    [${d}][data-surface="room-detail"]{
      display:flex !important;
      flex-direction:column;
      align-items:flex-start;
      gap:0.4rem;
      margin:0.65rem 0.75rem 0.35rem !important;
      padding:0.7rem 0.9rem;
      background:linear-gradient(180deg,#fff 0%,#fff8f8 100%);
      border:1px solid rgba(170,8,8,.28);
      border-radius:0.5rem;
      box-shadow:0 2px 10px rgba(15,23,42,.08);
      position:relative !important;
      left:auto !important;
      bottom:auto !important;
      max-width:min(100%, 20rem);
      z-index:10;
    }
    [${d}][data-surface="room-detail"] .pb-bt-detail-label{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.68rem;
      font-weight:700;
      letter-spacing:.07em;
      text-transform:uppercase;
      color:#6a6d70;
    }
    [${d}][data-surface="room-detail"] .pb-bt-list-code{
      font-size:1.55rem !important;
      font-weight:800;
      letter-spacing:.08em;
      padding:0.4rem 0.85rem;
      border-radius:0.35rem;
      line-height:1.15;
    }
    [${d}][data-surface="room-detail"] .pb-bt-list-muted{
      font-size:0.85rem;
    }
    [${d}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${d}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${d}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${d}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function ot(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${d}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return V(n)}return null}function sn(e){return ot(e)}function ln(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return ot(t)}function cn(e,t){let n=e.querySelector(`:scope > [${d}]`);if(!n){const o=e.querySelector(`[${d}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(d,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function dn(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function un(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function pn(e,t){let n=null;for(const i of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!i.closest(`[${d}]`)&&/^\d{6,}$/.test((i.textContent||"").trim())){n=i;break}const o=(n==null?void 0:n.closest(".sapMVBox"))||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,r=(n==null?void 0:n.closest(".sapMHBox"))||o.querySelector(":scope > .sapMHBox");let a=e.querySelector(`[${d}]`);return a?(a.dataset.booking!==t&&(a.dataset.booking=t,a.dataset.state="",a.innerHTML=""),a.dataset.surface="list",a.parentElement!==o?r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a):r&&a.previousElementSibling!==r&&r.insertAdjacentElement("afterend",a),a):(a=document.createElement("div"),a.setAttribute(d,"1"),a.dataset.booking=t,a.dataset.surface="list",r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a),a)}function mn(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function fn(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Ft(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",M.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||M.emmaBt.clickToCopy)},1200)})})}function bn(e,t){if(e.setAttribute(d,"1"),e.dataset.booking=t,e.dataset.state="loading",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${we(M.emmaBt.brand)}</div><span class="pb-bt-list-muted">${we(M.emmaBt.loading)}</span>`;return}e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function ze(e,t,n){if(e.setAttribute(d,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="",e.dataset.surface==="room-detail"){const r=document.createElement("div");r.className="pb-bt-detail-label",r.textContent=M.emmaBt.brand,e.appendChild(r)}const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=M.emmaBt.clickToCopy,o.setAttribute("aria-label",`${M.emmaBt.brand}: ${n}`),fn(o,n),e.appendChild(o)}function He(e,t){if(e.setAttribute(d,"1"),e.dataset.booking=t,e.dataset.state="none",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${we(M.emmaBt.brand)}</div><span class="pb-bt-list-muted">—</span>`;return}e.innerHTML=""}function we(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function Be(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=$e(t);if(r&&r.code===null)return;e.dataset.state=""}const n=$e(t);if(n){n.code?ze(e,t,n.code):He(e,t);return}bn(e,t);const o=await Je(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?ze(e,t,o):He(e,t))}function gn(){const e=on();if(!e){mn()||document.querySelectorAll(`[${d}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=un(r);if(!a)continue;const i=sn(a),s=a.querySelector(`[${d}]`);if(!i){(s==null?void 0:s.dataset.state)==="ok"&&n.add(s);continue}const l=pn(a,i);n.add(l),Be(l,i)}document.querySelectorAll(`[${d}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function hn(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function yn(){const e=rn(),t=new Set(e);if(e.length===0){hn()||document.querySelectorAll(`[${d}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=ln(o),a=o.querySelector(`[${d}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&dn(o)){n.add(a);continue}a==null||a.remove();continue}const i=cn(o,r);n.add(i),Be(i,r)}document.querySelectorAll(`[${d}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function vn(){const e=document.querySelectorAll('.sapMPageEnableScrolling, section.sapMPageEnableScrolling, [id$="-cont"].sapUiScrollDelegate');for(const t of e){if(t.querySelector(".sapMGT.roomTiles, .sapMGT.roomTiles2"))continue;const n=t.querySelector('.sapMTitle, .sapMTitle-inner, [class*="sapMTitle"]'),o=((n==null?void 0:n.textContent)||"").replace(/\s+/g," ").trim();if((/^room\s+\d+/i.test(o)||/^zimmer\s+\d+/i.test(o)||[...t.querySelectorAll("bdi, .sapMBtnContent")].some(a=>/check\s*out|change\s*room\s*status/i.test((a.textContent||"").trim())))&&rt(t))return t}return null}function rt(e){var t;for(const n of e.querySelectorAll(".sapMLabel, .sapMLabel bdi")){const o=(n.textContent||"").replace(/\s+/g," ").trim().replace(/:$/,"");if(!/^(reservation|reservierung)$/i.test(o))continue;const r=((t=n.closest('[class*="wrapperfor"]'))==null?void 0:t.parentElement)||n.closest(".sapUiFormResGridCont")||n.closest(".sapUiRespGrid")||e;for(const a of r.querySelectorAll("a.sapMLnk")){const i=(a.textContent||"").trim();if(/^\d{6,}$/.test(i))return V(i)}}for(const n of e.querySelectorAll("a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return V(o)}return null}function xn(e,t){let n=e.querySelector(`[${d}][data-surface="room-detail"]`);if(n)return n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n;n=document.createElement("div"),n.setAttribute(d,"1"),n.dataset.booking=t,n.dataset.surface="room-detail",n.setAttribute("role","region"),n.setAttribute("aria-label",M.emmaBt.brand);const o=e.querySelector(":scope > .sapMHBox"),r=e.querySelector('.sapUiForm, [role="form"]');return(o==null?void 0:o.parentElement)===e?o.insertAdjacentElement("afterend",n):r?r.insertAdjacentElement("beforebegin",n):e.insertBefore(n,e.firstChild),n}function $n(){const e=vn();if(!e){document.querySelectorAll(`[${d}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const t=rt(e);if(!t){document.querySelectorAll(`[${d}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const n=xn(e,t);Be(n,t)}function at(){if(!nn()){document.querySelectorAll(`[${d}]`).forEach(e=>e.remove());return}an(),gn(),yn(),$n()}function K(){Q&&window.clearTimeout(Q),Q=window.setTimeout(()=>{at()},280)}function wn(){ne().then(t=>{M=C(t),K()}),oe(t=>{M=C(t),document.querySelectorAll(`[${d}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),K()}),at(),window.addEventListener("hashchange",()=>K());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===fe||o.closest(`[${d}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${d}]`)||r.closest(`[${d}]`))))){K();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(ke(),document.querySelectorAll(`[${d}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),K())})}catch{}return()=>{var t;e.disconnect(),Q&&window.clearTimeout(Q),(t=document.getElementById(fe))==null||t.remove(),document.querySelectorAll(`[${d}]`).forEach(n=>n.remove())}}const Fe="CHBRNPR",Ce="100",it="ZEYUI_RSRVS_SRV";function Cn(e){const t=parseInt(e,10);return Number.isFinite(t)?String(t).padStart(4,"0"):e.trim()}function Tn(e,t,n=new Date){const o=(a,i)=>String(a).padStart(i,"0"),r=[o(n.getFullYear(),4),o(n.getMonth()+1,2),o(n.getDate(),2),o(n.getHours(),2),o(n.getMinutes(),2),o(n.getSeconds(),2)].join("");return`${e}   ${t}${r}000`}function Sn(e,t,n){const o=Math.random().toString(16).slice(2,14).padEnd(12,"0"),r=`batch_${o.slice(0,4)}-${o.slice(4,8)}-${o.slice(8,12)}`,a=`changeset_${o.slice(2,6)}-${o.slice(6,10)}-${o.slice(0,4)}`,i=`id-${Date.now()}-1000`;let s=`\r
`;return s+=`--${r}\r
`,s+=`Content-Type: multipart/mixed; boundary=${a}\r
\r
`,s+=`--${a}\r
`,s+=`Content-Type: application/http\r
`,s+=`Content-Transfer-Encoding: binary\r
\r
`,s+=`POST ${e} HTTP/1.1\r
`,s+=`tms-fioriapp: CheckIn\r
`,s+=`Request-Object-Key: ${n}\r
`,s+=`Request-Object-Type: RSRV\r
`,s+=`sap-contextid-accept: header\r
`,s+=`Accept: application/json\r
`,s+=`x-csrf-token: ${t}\r
`,s+=`Accept-Language: en\r
`,s+=`DataServiceVersion: 2.0\r
`,s+=`MaxDataServiceVersion: 2.0\r
`,s+=`X-Requested-With: XMLHttpRequest\r
`,s+=`Content-Type: application/json\r
`,s+=`Content-ID: ${i}\r
\r
`,s+=`\r
`,s+=`--${a}--\r
\r
`,s+=`--${r}--\r
`,{body:s,contentType:`multipart/mixed;boundary=${r}`}}async function kn(){const e=await fetch(`${location.origin}/sap/opu/odata/sap/${it}/?sap-client=${Ce}`,{credentials:"include",headers:{"x-csrf-token":"Fetch",Accept:"application/json","X-Requested-With":"XMLHttpRequest"}}),t=e.headers.get("x-csrf-token");if(!e.ok||!t||t.toLowerCase()==="required")throw new Error("CSRF");return t}function En(e){const t=e.match(/HTTP\/1\.[01] ([45]\d\d)[^\n]*\n([\s\S]*?)(?:\n--|\s*$)/);if(!t)return null;const o=(t[2]??"").match(/"message"\s*:\s*\{[^}]*"value"\s*:\s*"([^"]+)"/);return(o==null?void 0:o[1])||`EMMA ${t[1]}`}async function Bn(e,t){const n=await kn(),o=Cn(t),r=`RoomAssignment?sap-client=${Ce}&HotelId='${Fe}'&ReservationId='${e}'&RoomId='${o}'`,a=Sn(r,n,Tn(Fe,e)),i=await fetch(`${location.origin}/sap/opu/odata/sap/${it}/$batch?sap-client=${Ce}`,{method:"POST",credentials:"include",headers:{"Content-Type":a.contentType,"x-csrf-token":n,Accept:"multipart/mixed","X-Requested-With":"XMLHttpRequest",DataServiceVersion:"2.0",MaxDataServiceVersion:"2.0"},body:a.body}),s=await i.text(),l=En(s);if(!i.ok||l)throw new Error(l||`EMMA ${i.status}`)}let m=C("de");const g="prize-ra-host",be="prize-ra-style",y="data-prize-room-assign";function In(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function st(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${y}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o}return null}function lt(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function he(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function Mn(e){const t=he(e);return Ke(t)!=null}function Ln(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=he(r);if(a)return a}}return null}function ct(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&lt(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function An(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&lt(o))return o}const t=ct();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function Rn(){const e=An();if(!e)return null;const t=e.querySelector(".sapUiCompSmartFieldValue")||e.querySelector(".sapMInputBaseContentWrapper")||e.querySelector(".sapMInput")||e;let n=t;for(let o=0;o<6&&n;o++){if(n.classList.contains("sapUiVltCell")||n.classList.contains("sapMVBox")||n.classList.contains("sapMHBox"))return n;n=n.parentElement}return t}function ye(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const c=(l instanceof HTMLInputElement?l.value:l.textContent||"").trim();if(c&&!t.test(c))return c}a=a.parentElement}}return null}function qn(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=ye(n,/^Arrival\s*Date$/i)||ye(n,/^Arrival$/i)||ye(n,/^Anreise(datum)?$/i);if(!o)continue;const r=H(o);if(r)return r}return null}function Dn(){if(Ln())return!1;const e=qn();return e?et(e):!0}function _n(e,t){const n=he(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}const zn=2e4;let T=null;const ve=new Set;let $=null,G=!1,R=!1;function dt(e){const t={vip:m.emmaRoom.reasonVip,premium:m.emmaRoom.reasonPremium,repeat:m.emmaRoom.reasonRepeat,one_night:m.emmaRoom.reasonOneNight,long_stay:m.emmaRoom.reasonLongStay,three_pax:m.emmaRoom.reasonThreePax,no_basement:m.emmaRoom.reasonNoBasement,not_ready:m.emmaRoom.reasonNotReady,category_not_ready:m.emmaRoom.reasonCategoryNotReady,overbook_view:m.emmaRoom.reasonOverbookView,overbook_corner:m.emmaRoom.reasonOverbookCorner,overbook_standard:m.emmaRoom.reasonOverbookStandard,wheelchair:m.emmaRoom.reasonWheelchair};return e.map(n=>t[n]).filter(n=>!!n).slice(0,3).join(" · ")}function ut(e,t){const n=o=>o.replace(/^0+/,"")||o;return e===t||n(e)===n(t)}function Ie(e){const t=e instanceof Error?e.message:String(e??"");return/401|unauthorized|invalid token|jwt/i.test(t)?m.emmaRoom.signInRequired:m.emmaRoom.loadFailed}async function pt(){const e=T!=null&&T.error?5e3:zn;if(T&&Date.now()-T.at<e)return T;try{const t=await Se("/reservations/room-suggestions");T={at:Date.now(),items:t.items??[],error:null}}catch(t){T={at:Date.now(),items:[],error:Ie(t)}}return T}function Hn(e,t){var n;return((n=e.find(o=>ut(o.reservationId,t)))==null?void 0:n.suggestion)??null}function Pe(e,t,n){const o=e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e;let r=e.querySelector(`[${y}="row"]`);r||(r=document.createElement("div"),r.setAttribute(y,"row"),o.appendChild(r)),r.dataset.booking="",r.dataset.room="",r.dataset.note=t,r.innerHTML="";const a=document.createElement("span");return a.className=`pb-ra-row-note${n?" is-error":""}`,a.textContent=t,a.title=t,r.appendChild(a),r}async function mt(e){return await Bn(e.reservationId,e.roomNumber),T=null,await Se(`/reservations/${encodeURIComponent(e.reservationId)}/room-suggestion/accept`,{method:"POST",body:JSON.stringify({roomNumber:e.roomNumber})}),T=null,e.roomNumber}async function Fn(e){T=null;const t=await Se(`/reservations/${encodeURIComponent(e)}/room-suggestion/arriving-now`,{method:"POST"});return T=null,t.suggestion}function Pn(){let e=document.getElementById(be);e||(e=document.createElement("style"),e.id=be,document.documentElement.appendChild(e)),e.dataset.v!=="6"&&(e.dataset.v="6",e.textContent=`
    /* Detail: compact chip inline at the Room field */
    #${g}{
      box-sizing:border-box;
      display:inline-flex;
      flex-direction:column;
      gap:4px;
      margin:2px 0 0 0;
      max-width:min(200px,100%);
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:#fff;
      border:1px solid rgba(45,58,79,.16);
      border-radius:8px;
      box-shadow:0 1px 4px rgba(15,23,42,.08);
      padding:6px 8px;
      z-index:5;
      pointer-events:auto;
      vertical-align:middle;
    }
    #${g} *{box-sizing:border-box;}
    #${g} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${g} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${g} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${g} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${g} .pb-ra-main{
      display:flex;align-items:center;gap:6px;
    }
    #${g} .pb-ra-room{
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:16px;font-weight:800;letter-spacing:.03em;line-height:1.1;
      color:#1a2332;
    }
    #${g} .pb-ra-meta{
      font-size:9px;color:#64748b;margin-top:1px;font-weight:500;
    }
    #${g} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${g} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:26px;height:26px;border-radius:7px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
    }
    #${g} .pb-ra-btn:hover{background:#f1f5f9;}
    #${g} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${g} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${g} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${g} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${g} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${g} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${g} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${g} .pb-ra-note{
      font-size:8px;color:#94a3b8;line-height:1.25;
    }

    /* Check-in list Room column — under empty room slot, survive cell clipping */
    .sapUiTableDataCell:has([${y}="row"]) .sapUiTableCellInner,
    .sapUiTableDataCell:has([${y}="row"]) .sapMVBox{
      overflow:visible !important;
      max-height:none !important;
    }
    [${y}="row"]{
      display:flex !important;
      align-items:center;
      gap:0.25rem;
      margin:0.2rem 0 0 0;
      line-height:1.15;
      max-width:100%;
      flex-shrink:0;
      position:relative;
      z-index:20;
      pointer-events:auto;
    }
    [${y}="row"] .pb-ra-row-code{
      appearance:none;cursor:pointer;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:0.78rem;font-weight:800;letter-spacing:.03em;
      color:#0f172a;
      background:#dbeafe;
      border:1px solid #2563eb;
      border-radius:0.25rem;
      padding:0.15rem 0.45rem;
      white-space:nowrap;
    }
    [${y}="row"] .pb-ra-row-code:hover{filter:brightness(0.97);}
    [${y}="row"] .pb-ra-row-note{
      display:inline-block;max-width:9.5rem;margin-left:4px;
      font-size:10px;font-weight:650;line-height:1.2;color:#9a3412;
    }
    [${y}="row"] .pb-ra-row-note.is-error{color:#9b1c1c;}
    #${g} .pb-ra-now{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      border-radius:6px;padding:3px 6px;font-size:10px;font-weight:700;color:#1a2332;
    }
    #${g} .pb-ra-now:hover{background:#f1f5f9;}
    [${y}="row"] .pb-ra-row-code.pb-ra-dirty{background:#ffedd5;border-color:#c2410c;color:#9a3412;}
    [${y}="row"] .pb-ra-row-accept{
      appearance:none;cursor:pointer;border:1px solid #15803d;background:#15803d;color:#fff;
      border-radius:0.25rem;width:1.35rem;height:1.35rem;font-size:0.75rem;font-weight:800;
      line-height:1;
    }
  `)}function Nn(e){var o;let t=document.getElementById(g);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=g,t.setAttribute(y,"detail"),t.setAttribute("role","region"),t.setAttribute("aria-label",m.emmaRoom.title);const n=e.querySelector(".sapMInputBaseContentWrapper")||e.querySelector(".sapUiCompSmartFieldValue")||((o=e.querySelector("input.sapMInputBaseInner"))==null?void 0:o.parentElement);return(n==null?void 0:n.parentElement)===e||n?n.insertAdjacentElement("afterend",t):e.appendChild(t),t}function jn(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}let I=null,ee=null,k="",A=!1;function Un(e){const t=ct();if(!t)return!1;const n=t.value,o=_n(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function te(e){var l,p;if(e.setAttribute("aria-label",m.emmaRoom.title),G&&!$){e.innerHTML=`<div class="pb-ra-note">${L(m.emmaRoom.loading)}</div>`;return}if(!$){e.innerHTML=`<div class="pb-ra-note">${L(k||m.emmaRoom.noSuggestion)}</div>`;return}const t=Et($.floor??Ke($.roomNumber)),n=$.readyNow?m.emmaRoom.ready:m.emmaRoom.dirty,o=dt($.reasons),r=[t,n,o].filter(Boolean).join(" · "),a=k?`<div class="pb-ra-status${A?" pb-ra-warn":""}">${L(k)}</div>`:"",i=m.emmaRoom.accept,s=m.emmaRoom.arrivingNow;e.innerHTML=`<div class="pb-ra-top"><span class="pb-ra-title"><span class="pb-ra-dot" aria-hidden="true"></span>${L(m.emmaRoom.title)}</span><span class="pb-ra-badge">${L(n)}</span></div><div class="pb-ra-main"><div><div class="pb-ra-room">${L($.roomNumber)}</div><div class="pb-ra-meta">${L(r)}</div></div><div class="pb-ra-actions"><button type="button" class="pb-ra-btn pb-ra-accept" title="${Ne(i)}" aria-label="${Ne(i)}">${jn()}</button></div></div><button type="button" class="pb-ra-now">${L(s)}</button>`+a+`<div class="pb-ra-note">${L(m.emmaRoom.previewNote)}</div>`,(l=e.querySelector(".pb-ra-accept"))==null||l.addEventListener("click",c=>{if(c.preventDefault(),c.stopPropagation(),!$||R)return;const u=$;R=!0,mt(u).then(f=>{Un(f),k=We(m.emmaRoom.applied,{room:f}),A=!1,$=null,I=null}).catch(f=>{k=f instanceof Error&&f.message&&f.message!=="CSRF"?`${m.emmaRoom.assignFailed}: ${f.message}`:m.emmaRoom.assignFailed,A=!0}).finally(()=>{R=!1,te(e),U()})}),(p=e.querySelector(".pb-ra-now"))==null||p.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();const u=st();!u||R||(R=!0,G=!0,te(e),Fn(u).then(f=>{$=f,I=null,k=f?"":m.emmaRoom.noSuggestion,A=!f}).catch(f=>{k=Ie(f),A=!0}).finally(()=>{R=!1,G=!1,te(e),U()}))})}function L(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Ne(e){return L(e).replace(/'/g,"&#39;")}function On(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Gn(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((i,s)=>{const l=(i.textContent||"").replace(/\s+/g," ").trim().toLowerCase();(l==="room"||l==="zimmer"||l.startsWith("room ")||l.startsWith("zimmer"))&&(t=s),(l==="arrival"||l.startsWith("anreise")||l.startsWith("arrival"))&&(n=s)}),{room:t,arrival:n}}function je(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function Vn(e){const t=/-col0$/;let n=null;for(const o of e.querySelectorAll('[id*="-col"]'))if(t.test(o.id)){n=o;break}if(n||(n=e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")),!n)return null;for(const o of n.querySelectorAll(".sapMText, a.sapMLnk")){if(o.closest(`[${y}]`))continue;const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r}return null}function Wn(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${y}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&Mn(n))return he(n)}return null}function Yn(e){for(const t of e.querySelectorAll(".sapMText")){const n=(t.textContent||"").trim(),o=H(n);if(o)return o}return H((e.textContent||"").trim())}function Xn(e,t){if(t){const n=Yn(t);if(n)return n}for(const n of e.querySelectorAll(".sapMText")){if(n.closest(`[${y}]`))continue;const o=H((n.textContent||"").trim());if(o)return o}return null}function Kn(e,t){const n=t.reservationId,o=t.roomNumber,r=e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,a=r.querySelector(":scope > .sapMHBox")||r.querySelector(":scope > .sapMFlexItem");let i=e.querySelector(`[${y}="row"]`);if(i&&i.dataset.booking===n&&i.dataset.room===o&&i.dataset.ready===String(t.readyNow))return i.parentElement!==r&&(a&&a.parentElement===r?a.insertAdjacentElement("afterend",i):r.appendChild(i)),i;i?(i.dataset.booking=n,i.dataset.room=o,i.parentElement!==r&&(a&&a.parentElement===r?a.insertAdjacentElement("afterend",i):r.appendChild(i))):(i=document.createElement("div"),i.setAttribute(y,"row"),a&&a.parentElement===r?a.insertAdjacentElement("afterend",i):r.appendChild(i)),i.dataset.booking=n,i.dataset.room=o,i.dataset.ready=String(t.readyNow),i.innerHTML="";const s=document.createElement("button");s.type="button",s.className=`pb-ra-row-code${t.readyNow?"":" pb-ra-dirty"}`;const l=o.padStart(4,"0");s.textContent=l;const p=dt(t.reasons);s.title=[m.emmaRoom.title,l,t.readyNow?m.emmaRoom.ready:m.emmaRoom.dirty,p].filter(Boolean).join(" · "),s.setAttribute("aria-label",s.title);const c=document.createElement("button");return c.type="button",c.className="pb-ra-row-accept",c.textContent="✓",c.title=m.emmaRoom.accept,c.setAttribute("aria-label",m.emmaRoom.accept),c.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),!R&&(R=!0,mt(t).then(()=>{const f=e.querySelector(".sapMText, a.sapMLnk");f&&!f.closest(`[${y}]`)&&(f.textContent=l),i==null||i.remove()}).catch(()=>{s.title=m.emmaRoom.assignFailed}).finally(()=>{R=!1}))}),i.appendChild(s),i.appendChild(c),i}function Zn(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}async function Jn(){const e=On();if(!e){Zn()||document.querySelectorAll(`[${y}="row"]`).forEach(i=>i.remove());return}const t=Gn(e),n=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),o=new Set(n),r=new Set,a=await pt();for(const i of n){const s=Vn(i);if(!s)continue;const l=je(i,t.room),p=je(i,t.arrival);if(!l)continue;const c=Wn(l),u=l.querySelector(`[${y}="row"]`);if(c){u==null||u.remove();continue}const f=Xn(i,p);if(f&&!et(f)){u==null||u.remove();continue}if(a.error){r.add(Pe(l,a.error,!0));continue}const S=a.items.find(re=>ut(re.reservationId,s));if(!(S!=null&&S.suggestion)){S?r.add(Pe(l,m.emmaRoom.noSuggestion,!1)):u==null||u.remove();continue}r.add(Kn(l,S.suggestion))}document.querySelectorAll(`[${y}="row"]`).forEach(i=>{if(!(i instanceof HTMLElement)||r.has(i))return;const s=i.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!s||!o.has(s))&&i.remove()})}function ge(){var e;(e=document.getElementById(g))==null||e.remove(),I=null,$=null,G=!1,k="",A=!1}async function Qn(){const e=st(),t=Rn();if(!t||!e){ge();return}if(!Dn()){ge();return}const n=Nn(t),o=e;if(n.dataset.key===o||ve.has(o))return;ve.add(o);const r=I!==o;I=o,r&&(k="",A=!1),G=!0,te(n);try{const a=await pt();if(I!==o)return;a.error?($=null,k=a.error,A=!0):($=Hn(a.items,e),$||(k=m.emmaRoom.noSuggestion,A=!0)),n.dataset.key=o}catch(a){if(I!==o)return;$=null,k=Ie(a),A=!0,n.dataset.key=o}finally{G=!1,ve.delete(o)}I===o&&te(n)}async function ft(){if(!In()){ge(),document.querySelectorAll(`[${y}="row"]`).forEach(e=>e.remove());return}Pn(),await Jn(),await Qn()}function U(){ee&&window.clearTimeout(ee),ee=window.setTimeout(()=>{ft()},350)}function eo(){ne().then(t=>{m=C(t),I=null,U()}),oe(t=>{m=C(t),I=null,U()}),ft(),window.addEventListener("hashchange",()=>{var t;I=null,$=null,(t=document.getElementById(g))==null||t.removeAttribute("data-key"),U()});const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(!(o instanceof Element&&(o.id===g||o.id===be||o.closest(`[${y}]`)))){U();return}}});return e.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var t;e.disconnect(),ee&&window.clearTimeout(ee),ge(),document.querySelectorAll(`[${y}="row"]`).forEach(n=>n.remove()),(t=document.getElementById(be))==null||t.remove()}}const Ue="prize-panel-host";let q=C("de");function bt(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function ce(e,t,n){const o=`${de}px 0 0 ${de}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=bt(),t.title=q.inject.openPanel,t.setAttribute("aria-label",q.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${Ve}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=q.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function Oe(e,t,n){var i;const r=!await Te(D.panelCollapsed);await vt({[D.panelCollapsed]:r}),ce(e,t,r);const a=e.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?O.collapsed:O.expanded},"*")}function Ge(){if(document.getElementById(Ue))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${de}px 0 0 ${de}px`,r=document.createElement("div");r.id=Ue,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${ht}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:ie,border:`1px solid ${xe}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=q.inject.panelTitle,Object.assign(i.style,{width:`${Ve}px`,height:"100%",border:"none",display:"block",background:ie}),a.appendChild(i);const s=document.createElement("button");s.id="prize-panel-tab",s.type="button",Object.assign(s.style,{width:`${Le}px`,height:`${yt}px`,minWidth:`${Le}px`,border:`1px solid ${xe}`,borderRight:"none",background:`linear-gradient(180deg, ${ie} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),s.innerHTML=bt(),s.addEventListener("mouseenter",()=>{s.style.filter="brightness(1.12)"}),s.addEventListener("mouseleave",()=>{s.style.filter=""}),s.addEventListener("click",()=>{Oe(a,s)}),r.appendChild(a),r.appendChild(s),document.documentElement.appendChild(r),Te(D.panelCollapsed).then(l=>{t=l,ce(a,s,l)}),window.addEventListener("message",l=>{var p,c,u,f;((p=l.data)==null?void 0:p.type)===O.toggle&&Oe(a,s),((c=l.data)==null?void 0:c.type)===O.chatOpen&&(e=!0,n()&&((u=document.getElementById("prize-panel-chat-toast"))==null||u.remove())),((f=l.data)==null?void 0:f.type)===O.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((l,p)=>{p==="local"&&l[D.panelCollapsed]&&(t=!!l[D.panelCollapsed].newValue)}),zt(n),tn(),wn(),eo(),ne().then(l=>{q=C(l),ce(a,s,t),i.title=q.inject.panelTitle}),oe(l=>{q=C(l),ce(a,s,t),i.title=q.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Ge):Ge();
