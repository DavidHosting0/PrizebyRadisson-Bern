import{b as Ye,S as j,P as ne,c as Ce,d as Oe,A as Kt,e as Be,f as Zt,g as wt,T as nt,h as Jt,s as Qt}from"./storage-DTWcLCTt.js";import{l as ye,w as ve,i as oe,g as L,a as xt,b as en,p as tn,c as $t,d as nn,t as ot,B as on,e as rn,f as an,h as we}from"./bernticket-api-CDm5yS53.js";const rt=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function sn(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function Ct(e){if(sn(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=rt.length;n++){const[o,r]=rt[n-1];if(t>=o&&t<=r)return n}return null}function ln(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let ue=L("de");const D="prize-panel-chat-toast",at="prize-panel-chat-toast-style",cn=8e3,dn=7e3;function un(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function mn(e){return e==="/r"||e.startsWith("/r/")}function pn(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function fn(){if(document.getElementById(at))return;const e=document.createElement("style");e.id=at,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${D}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${Ce} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${Oe};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${D}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${D} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${D} .pb-ct-body{min-width:0;flex:1;}
    #${D} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${Kt};margin-bottom:2px;
    }
    #${D} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${D} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${D} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${D} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let Te=null;function J(e=!0){const t=document.getElementById(D);if(t){if(Te&&(window.clearTimeout(Te),Te=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function bn(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,i,s)=>{const l=t.createOscillator(),d=t.createGain();l.type="sine",l.frequency.setValueAtTime(a,i),d.gain.setValueAtTime(1e-4,i),d.gain.exponentialRampToValueAtTime(.9,i+.015),d.gain.exponentialRampToValueAtTime(1e-4,i+s),l.connect(d),d.connect(o),l.start(i),l.stop(i+s+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function gn(e,t){fn(),J(!1);const n=document.createElement("div");n.id=D,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),s=r.querySelector(".pb-ct-preview");a.textContent=ue.toast.eyebrow,i.textContent=oe(ue.toast.newMessageFrom,{author:e}),s.textContent=pn(t);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",ue.toast.close),l.textContent="×",l.addEventListener("click",d=>{d.stopPropagation(),J(!0)}),n.addEventListener("click",()=>J(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),bn(),Te=window.setTimeout(()=>{J(!0)},dn)}function hn(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:ne.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function yn(e){let t=!1,n=null,o=!0;ye().then(s=>{ue=L(s)});const r=ve(s=>{ue=L(s)});Ye(j.chatNotificationsEnabled,!0).then(s=>{o=s});try{chrome.storage.onChanged.addListener((s,l)=>{if(l==="local"&&s[j.chatNotificationsEnabled]){const d=s[j.chatNotificationsEnabled].newValue;o=d===void 0?!0:!!d,o||J(!1)}})}catch{}const a=async()=>{var s,l,d;if(!t)try{if(!o)return;const m=await hn();if(!m.ok)return;const f=m.msg;if(!(f!=null&&f.id))return;if(n===null){n=f.id;return}if(f.id===n||(n=f.id,(s=f.author)!=null&&s.id&&m.meId&&f.author.id===m.meId)||e()||un(window.location.pathname)||mn(window.location.pathname))return;const g=((d=(l=f.author)==null?void 0:l.name)==null?void 0:d.trim())||"Team";gn(g,f.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},cn);return()=>{t=!0,window.clearInterval(i),r(),J(!1)}}const Tt=300*1e3,X=new Map,ke=new Map;function re(e){return e.replace(/^0+/,"")||e}function Ue(e){const t=X.get(re(e));return!t||Date.now()-t.at>=Tt?null:{code:t.code}}function vn(e,t){X.set(re(e),{code:t,at:Date.now()})}function Xe(){X.clear(),ke.clear()}async function kt(e){const t=re(e),n=X.get(t);if(n&&Date.now()-n.at<Tt)return n.code;let o=ke.get(t);return o||(o=(async()=>{try{const r=await xt();if(!(r!=null&&r.access))return X.set(t,{code:null,at:Date.now()}),null;const a=await en(t),i=tn(a,t),s=$t(i);return X.set(t,{code:s,at:Date.now()}),s}catch{return X.set(t,{code:null,at:Date.now()}),null}finally{ke.delete(t)}})(),ke.set(t,o)),o}async function wn(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}const xn={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function K(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=xn[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const i=new Date(a),s=i.getFullYear(),l=String(i.getMonth()+1).padStart(2,"0"),d=String(i.getDate()).padStart(2,"0");if(s>=2e3)return`${s}-${l}-${d}`}return null}function St(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function $n(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Et(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:K(e);return!!(t&&t===St())}let h=L("de");const y="prize-bt-checkin-host",Ie="prize-bt-checkin-style",x="prize-bt-fallback-bar",w="prize-bt-create-dialog";function Cn(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Bt(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function Ae(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function Tn(){const e=Ae();if(e)return e;if(Bt())return null;for(const o of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r.replace(/^0+/,"")||r}const t=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),n=((t==null?void 0:t.textContent)||"").match(/\b(\d{6,})\b/);return n?n[1].replace(/^0+/,"")||n[1]:null}function kn(){return!!document.querySelector(['.sapUiLocalBusyIndicator:not([style*="display: none"])',".sapUiBusy",".sapMBusyDialog",".sapUiBlockLayer",".sapUiBLy",".sapUiLocalBusyIndicatorAnimation",'[class*="BusyIndicator"]:not([style*="display: none"])'].join(", "))}function it(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function Ke(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function Q(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const m=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(m&&!t.test(m))return m}a=a.parentElement}}return null}function Sn(){const e=Ke()||document.body,t=Q(e,/^Arrival\s*Date$/i)||Q(e,/^Anreise(datum)?$/i),n=Q(e,/^Departure\s*Date$/i)||Q(e,/^Abreise(datum)?$/i),o=t&&K(t)||St(),r=n&&K(n)||$n();return{from:o,to:r}}function En(){const e=Ke()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=Q(t,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function Bn(){const e=Ke()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=Q(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function In(e){const t=Sn();return{guestName:Bn(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:En()}}function An(){const e=document.getElementById(Ie);e&&e.remove();const t=document.createElement("style");t.id=Ie,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${y}),
    .sapMTBSpacerFlex:has(#${y}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${y}.sapMBarChild,
    #${y}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${y} *{box-sizing:border-box;}
    #${y} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${y} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:1.35rem;font-weight:700;
      letter-spacing:.05em;line-height:1.15;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.3rem;
      padding:0.45rem 0.85rem;
      min-width:0;text-align:center;
    }
    #${y} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${y} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${y} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${y} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${y} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${y} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${x}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.45rem;
      padding:0.35rem 0.6rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.3rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${x} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${x} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${x} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.05em;
      font-size:1.25rem;line-height:1.15;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.3rem;padding:0.35rem 0.7rem;
    }
    #${x} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${x} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${w}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${w} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${w} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${w} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${w} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${w} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${w} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${w} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${w} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${w} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${w} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${w} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${w} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${w} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${w} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${w} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function ee(){var e;(e=document.getElementById(w))==null||e.remove()}function st(e){var o,r;(o=document.getElementById(x))==null||o.remove();let t=document.getElementById(y);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=y,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",h.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function Ln(){var t;(t=document.getElementById(y))==null||t.remove();let e=document.getElementById(x);return e||(e=document.createElement("div"),e.id=x,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",h.emmaBt.brand),document.documentElement.appendChild(e),e)}function ie(e,t){e.innerHTML=t}function se(e){return`<span class="pb-bt-label">${B(h.emmaBt.brand)}</span>${e}`}async function Mn(e){try{await navigator.clipboard.writeText(e)}catch{}}function Rn(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{Mn(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=h.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function qn(e,t,n,o){ee();const r=document.createElement("div");r.id=w,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${Y(h.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${B(h.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${Y(h.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${B(h.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${Y(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${B(h.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${Y(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${B(h.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${Y(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${B(h.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${Y(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${B(h.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${B(h.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${B(h.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(l=>{l.addEventListener("click",()=>ee())});const s=l=>{l.key==="Escape"&&(ee(),window.removeEventListener("keydown",s))};window.addEventListener("keydown",s),i.addEventListener("click",()=>{(async()=>{const l=r.querySelector(".pb-bt-dlg-name"),d=r.querySelector(".pb-bt-dlg-from"),m=r.querySelector(".pb-bt-dlg-to"),f=r.querySelector(".pb-bt-dlg-amt"),g=(l==null?void 0:l.value.trim())||"";if(!g){a.hidden=!1,a.textContent=h.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=h.common.ellipsis,a.hidden=!0;try{const C=await nn({guestName:g,bookingNumber:t,validFrom:ot((d==null?void 0:d.value)||n.from),validTo:ot((m==null?void 0:m.value)||n.to),ticketsAmount:Math.max(1,parseInt((f==null?void 0:f.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});ee(),o($t(C))}catch(C){if(C instanceof on&&C.code===rn){const R=window.prompt(h.emmaBt.twoFaPrompt);if(R)try{await an(R),i.disabled=!1,i.textContent=h.emmaBt.create,i.click();return}catch(V){a.hidden=!1,a.textContent=V instanceof Error?V.message:h.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=h.emmaBt.create;return}}a.hidden=!1,a.textContent=C instanceof Error?C.message:h.emmaBt.error,i.disabled=!1,i.textContent=h.emmaBt.create}})()})}let q=null,Z=null,me=null,$e=0;async function Le(e,t,n){var l,d;const o=++$e,r=await xt();if(o!==$e)return;if(!r.access){ie(e,se(`<span class="pb-bt-muted">${B(h.emmaBt.loginHint)}</span>`)),e.dataset.fetched="1";return}const a=h.bernticket.copyCode,i=m=>{ie(e,se(`<button type="button" class="pb-bt-code" title="${Y(a)}">${B(m)}</button>`)),Rn(e,m),e.dataset.fetched="1"},s=Ue(t);if(s!=null&&s.code){i(s.code);return}if(!(e.dataset.bound===t&&e.dataset.fetched==="1"&&e.querySelector(".pb-bt-code, .pb-bt-open-create, .pb-bt-muted"))){ie(e,se(`<span class="pb-bt-muted">${B(h.emmaBt.loading)}</span>`));try{const m=await kt(t);if(o!==$e)return;if(m){i(m);return}const f=In(t);ie(e,se(`<button type="button" class="pb-bt-btn pb-bt-open-create">${B(h.emmaBt.openCreate)}</button>`)),e.dataset.fetched="1",(l=e.querySelector(".pb-bt-open-create"))==null||l.addEventListener("click",()=>{qn(e,t,f,g=>{g?(vn(t,g),i(g)):(e.dataset.fetched="",q=null,Le(e,t,!0))})})}catch(m){if(o!==$e)return;ie(e,se(`<span class="pb-bt-muted">${B(m instanceof Error?m.message:h.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${B(h.emmaBt.retry)}</button>`)),e.dataset.fetched="1",(d=e.querySelector(".pb-bt-retry"))==null||d.addEventListener("click",()=>{Xe(),e.dataset.fetched="",q=null,Le(e,t)})}}}function B(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Y(e){return B(e).replace(/'/g,"&#39;")}function le(){me&&window.clearTimeout(me),me=window.setTimeout(()=>{It()},700)}function _n(e){return document.documentElement.contains(e)}async function It(){var a,i,s,l,d,m;if(!Cn()){(a=document.getElementById(y))==null||a.remove(),(i=document.getElementById(x))==null||i.remove(),ee(),q=null,Z=null;return}An();const e=kn();let t=Tn();if(t?Z=t:e&&Z?t=Z:!e&&!Ae()&&(Z=null),!e&&Bt()&&!Ae()){(s=document.getElementById(y))==null||s.remove(),(l=document.getElementById(x))==null||l.remove(),q=null;return}if(!t){(d=document.getElementById(y))==null||d.remove(),(m=document.getElementById(x))==null||m.remove(),q=null;return}const n=document.getElementById(y)||document.getElementById(x);if(t===q&&n&&_n(n)&&n.dataset.bound===t&&n.dataset.fetched==="1"){const f=e?null:it();if(f&&n.id===x&&!e){const g=st(f);g!==n&&(g.dataset.bound=t,g.dataset.fetched="",n.remove(),q=t,await Le(g,t))}return}const o=e?null:it(),r=o?st(o):Ln();q=t,r.dataset.bound=t,await Le(r,t)}function Dn(){ye().then(t=>{h=L(t),q=null,le()}),ve(t=>{h=L(t),q=null,le()}),It(),window.addEventListener("hashchange",()=>{q=null,Ae()||(Z=null);const t=document.getElementById(y)||document.getElementById(x);t instanceof HTMLElement&&(t.dataset.fetched=""),le()});const e=new MutationObserver(t=>{let n=!1;for(const o of t){const r=o.target;if(r instanceof Element&&!(r.id===y||r.id===x||r.id===Ie||r.id===w||r.closest("[data-prize-bernticket]")||r.closest(`#${y}, #${x}, #${w}`))&&!(o.type==="childList"&&[...o.addedNodes,...o.removedNodes].length>0&&[...o.addedNodes,...o.removedNodes].every(a=>a instanceof Element&&(a.id===y||a.id===x||a.id===w||a.closest(`[data-prize-bernticket], #${y}, #${x}`))))){n=!0;break}}n&&le()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{if(n==="local"&&(t.btAccessToken||t.btRefreshToken)){q=null,Xe();const o=document.getElementById(y)||document.getElementById(x);o instanceof HTMLElement&&(o.dataset.fetched=""),le()}})}catch{}return()=>{var t,n,o;e.disconnect(),me&&window.clearTimeout(me),(t=document.getElementById(y))==null||t.remove(),(n=document.getElementById(x))==null||n.remove(),(o=document.getElementById(Ie))==null||o.remove(),ee()}}let z=L("de");const Me="prize-bt-list-style",u="data-prize-bt-chip";let pe=null;function zn(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Hn(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Fn(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function Pn(){let e=document.getElementById(Me);e||(e=document.createElement("style"),e.id=Me,document.documentElement.appendChild(e)),e.dataset.v!=="7"&&(e.dataset.v="7",e.textContent=`
    [${u}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: BELOW reservation number — do not sit in the number hbox */
    [${u}][data-surface="list"]{
      display:block !important;
      margin:0.15rem 0 0 0 !important;
      max-width:100%;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${u}]),
    .sapUiTableDataCell:has([${u}]),
    .sapMVBox:has([${u}]),
    .sapMHBox:has([${u}]){
      overflow:visible !important;
    }
    .sapUiTableCellInner:has([${u}[data-surface="list"]]){
      max-height:none !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${u}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    /* Room Status detail panel (click a room): large code */
    [${u}][data-surface="room-detail"]{
      display:flex !important;
      flex-direction:column;
      align-items:flex-start;
      gap:0.4rem;
      margin:0.65rem 0.75rem 0.35rem !important;
      padding:0.7rem 0.9rem;
      background:linear-gradient(180deg,#fff 0%,#fff8f8 100%);
      border:1px solid rgba(170,8,8,.28);
      border-radius:0.5rem;
      box-shadow:0 2px 10px rgba(15,23,42,.08);
      position:relative !important;
      left:auto !important;
      bottom:auto !important;
      max-width:min(100%, 20rem);
      z-index:10;
    }
    [${u}][data-surface="room-detail"] .pb-bt-detail-label{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.68rem;
      font-weight:700;
      letter-spacing:.07em;
      text-transform:uppercase;
      color:#6a6d70;
    }
    [${u}][data-surface="room-detail"] .pb-bt-list-code{
      font-size:1.55rem !important;
      font-weight:800;
      letter-spacing:.08em;
      padding:0.4rem 0.85rem;
      border-radius:0.35rem;
      line-height:1.15;
    }
    [${u}][data-surface="room-detail"] .pb-bt-list-muted{
      font-size:0.85rem;
    }
    [${u}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${u}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${u}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${u}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function At(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${u}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return re(n)}return null}function Nn(e){return At(e)}function On(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return At(t)}function Un(e,t){let n=e.querySelector(`:scope > [${u}]`);if(!n){const o=e.querySelector(`[${u}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(u,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function jn(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function Gn(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function Vn(e,t){let n=null;for(const i of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!i.closest(`[${u}]`)&&/^\d{6,}$/.test((i.textContent||"").trim())){n=i;break}const o=(n==null?void 0:n.closest(".sapMVBox"))||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,r=(n==null?void 0:n.closest(".sapMHBox"))||o.querySelector(":scope > .sapMHBox");let a=e.querySelector(`[${u}]`);return a?(a.dataset.booking!==t&&(a.dataset.booking=t,a.dataset.state="",a.innerHTML=""),a.dataset.surface="list",a.parentElement!==o?r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a):r&&a.previousElementSibling!==r&&r.insertAdjacentElement("afterend",a),a):(a=document.createElement("div"),a.setAttribute(u,"1"),a.dataset.booking=t,a.dataset.surface="list",r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a),a)}function Wn(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function Yn(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),wn(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",z.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||z.emmaBt.clickToCopy)},1200)})})}function Xn(e,t){if(e.setAttribute(u,"1"),e.dataset.booking=t,e.dataset.state="loading",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${je(z.emmaBt.brand)}</div><span class="pb-bt-list-muted">${je(z.emmaBt.loading)}</span>`;return}e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function lt(e,t,n){if(e.setAttribute(u,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="",e.dataset.surface==="room-detail"){const r=document.createElement("div");r.className="pb-bt-detail-label",r.textContent=z.emmaBt.brand,e.appendChild(r)}const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=z.emmaBt.clickToCopy,o.setAttribute("aria-label",`${z.emmaBt.brand}: ${n}`),Yn(o,n),e.appendChild(o)}function ct(e,t){if(e.setAttribute(u,"1"),e.dataset.booking=t,e.dataset.state="none",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${je(z.emmaBt.brand)}</div><span class="pb-bt-list-muted">—</span>`;return}e.innerHTML=""}function je(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function Ze(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=Ue(t);if(r&&r.code===null)return;e.dataset.state=""}const n=Ue(t);if(n){n.code?lt(e,t,n.code):ct(e,t);return}Xn(e,t);const o=await kt(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?lt(e,t,o):ct(e,t))}function Kn(){const e=Hn();if(!e){Wn()||document.querySelectorAll(`[${u}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=Gn(r);if(!a)continue;const i=Nn(a),s=a.querySelector(`[${u}]`);if(!i){(s==null?void 0:s.dataset.state)==="ok"&&n.add(s);continue}const l=Vn(a,i);n.add(l),Ze(l,i)}document.querySelectorAll(`[${u}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function Zn(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function Jn(){const e=Fn(),t=new Set(e);if(e.length===0){Zn()||document.querySelectorAll(`[${u}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=On(o),a=o.querySelector(`[${u}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&jn(o)){n.add(a);continue}a==null||a.remove();continue}const i=Un(o,r);n.add(i),Ze(i,r)}document.querySelectorAll(`[${u}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function Qn(){const e=document.querySelectorAll('.sapMPageEnableScrolling, section.sapMPageEnableScrolling, [id$="-cont"].sapUiScrollDelegate');for(const t of e){if(t.querySelector(".sapMGT.roomTiles, .sapMGT.roomTiles2"))continue;const n=t.querySelector('.sapMTitle, .sapMTitle-inner, [class*="sapMTitle"]'),o=((n==null?void 0:n.textContent)||"").replace(/\s+/g," ").trim();if((/^room\s+\d+/i.test(o)||/^zimmer\s+\d+/i.test(o)||[...t.querySelectorAll("bdi, .sapMBtnContent")].some(a=>/check\s*out|change\s*room\s*status/i.test((a.textContent||"").trim())))&&Lt(t))return t}return null}function Lt(e){var t;for(const n of e.querySelectorAll(".sapMLabel, .sapMLabel bdi")){const o=(n.textContent||"").replace(/\s+/g," ").trim().replace(/:$/,"");if(!/^(reservation|reservierung)$/i.test(o))continue;const r=((t=n.closest('[class*="wrapperfor"]'))==null?void 0:t.parentElement)||n.closest(".sapUiFormResGridCont")||n.closest(".sapUiRespGrid")||e;for(const a of r.querySelectorAll("a.sapMLnk")){const i=(a.textContent||"").trim();if(/^\d{6,}$/.test(i))return re(i)}}for(const n of e.querySelectorAll("a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return re(o)}return null}function eo(e,t){let n=e.querySelector(`[${u}][data-surface="room-detail"]`);if(n)return n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n;n=document.createElement("div"),n.setAttribute(u,"1"),n.dataset.booking=t,n.dataset.surface="room-detail",n.setAttribute("role","region"),n.setAttribute("aria-label",z.emmaBt.brand);const o=e.querySelector(":scope > .sapMHBox"),r=e.querySelector('.sapUiForm, [role="form"]');return(o==null?void 0:o.parentElement)===e?o.insertAdjacentElement("afterend",n):r?r.insertAdjacentElement("beforebegin",n):e.insertBefore(n,e.firstChild),n}function to(){const e=Qn();if(!e){document.querySelectorAll(`[${u}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const t=Lt(e);if(!t){document.querySelectorAll(`[${u}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const n=eo(e,t);Ze(n,t)}function Mt(){if(!zn()){document.querySelectorAll(`[${u}]`).forEach(e=>e.remove());return}Pn(),Kn(),Jn(),to()}function ce(){pe&&window.clearTimeout(pe),pe=window.setTimeout(()=>{Mt()},280)}function no(){ye().then(t=>{z=L(t),ce()}),ve(t=>{z=L(t),document.querySelectorAll(`[${u}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),ce()}),Mt(),window.addEventListener("hashchange",()=>ce());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===Me||o.closest(`[${u}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${u}]`)||r.closest(`[${u}]`))))){ce();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(Xe(),document.querySelectorAll(`[${u}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),ce())})}catch{}return()=>{var t;e.disconnect(),pe&&window.clearTimeout(pe),(t=document.getElementById(Me))==null||t.remove(),document.querySelectorAll(`[${u}]`).forEach(n=>n.remove())}}const dt="CHBRNPR",Ge="100",Rt="ZEYUI_RSRVS_SRV";function oo(e){const t=parseInt(e,10);return Number.isFinite(t)?String(t).padStart(4,"0"):e.trim()}function ro(e,t,n=new Date){const o=(a,i)=>String(a).padStart(i,"0"),r=[o(n.getFullYear(),4),o(n.getMonth()+1,2),o(n.getDate(),2),o(n.getHours(),2),o(n.getMinutes(),2),o(n.getSeconds(),2)].join("");return`${e}   ${t}${r}000`}function ao(e,t,n){const o=Math.random().toString(16).slice(2,14).padEnd(12,"0"),r=`batch_${o.slice(0,4)}-${o.slice(4,8)}-${o.slice(8,12)}`,a=`changeset_${o.slice(2,6)}-${o.slice(6,10)}-${o.slice(0,4)}`,i=`id-${Date.now()}-1000`;let s=`\r
`;return s+=`--${r}\r
`,s+=`Content-Type: multipart/mixed; boundary=${a}\r
\r
`,s+=`--${a}\r
`,s+=`Content-Type: application/http\r
`,s+=`Content-Transfer-Encoding: binary\r
\r
`,s+=`POST ${e} HTTP/1.1\r
`,s+=`tms-fioriapp: CheckIn\r
`,s+=`Request-Object-Key: ${n}\r
`,s+=`Request-Object-Type: RSRV\r
`,s+=`sap-contextid-accept: header\r
`,s+=`Accept: application/json\r
`,s+=`x-csrf-token: ${t}\r
`,s+=`Accept-Language: en\r
`,s+=`DataServiceVersion: 2.0\r
`,s+=`MaxDataServiceVersion: 2.0\r
`,s+=`X-Requested-With: XMLHttpRequest\r
`,s+=`Content-Type: application/json\r
`,s+=`Content-ID: ${i}\r
\r
`,s+=`\r
`,s+=`--${a}--\r
\r
`,s+=`--${r}--\r
`,{body:s,contentType:`multipart/mixed;boundary=${r}`}}async function io(){const e=await fetch(`${location.origin}/sap/opu/odata/sap/${Rt}/?sap-client=${Ge}`,{credentials:"include",headers:{"x-csrf-token":"Fetch",Accept:"application/json","X-Requested-With":"XMLHttpRequest"}}),t=e.headers.get("x-csrf-token");if(!e.ok||!t||t.toLowerCase()==="required")throw new Error("CSRF");return t}function so(e){const t=e.match(/HTTP\/1\.[01] ([45]\d\d)[^\n]*\n([\s\S]*?)(?:\n--|\s*$)/);if(!t)return null;const o=(t[2]??"").match(/"message"\s*:\s*\{[^}]*"value"\s*:\s*"([^"]+)"/);return(o==null?void 0:o[1])||`EMMA ${t[1]}`}async function lo(e,t){const n=await io(),o=oo(t),r=`RoomAssignment?sap-client=${Ge}&HotelId='${dt}'&ReservationId='${e}'&RoomId='${o}'`,a=ao(r,n,ro(dt,e)),i=await fetch(`${location.origin}/sap/opu/odata/sap/${Rt}/$batch?sap-client=${Ge}`,{method:"POST",credentials:"include",headers:{"Content-Type":a.contentType,"x-csrf-token":n,Accept:"multipart/mixed","X-Requested-With":"XMLHttpRequest",DataServiceVersion:"2.0",MaxDataServiceVersion:"2.0"},body:a.body}),s=await i.text(),l=so(s);if(!i.ok||l)throw new Error(l||`EMMA ${i.status}`)}let c=L("de");const p="prize-ra-host",fe="prize-ra-style",H="prize-ra-assign-all",G="prize-ra-assign-count",b="data-prize-room-assign";function co(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Ve(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${b}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o}return null}function qt(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function ae(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function _t(e){const t=ae(e);return Ct(t)!=null}function uo(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=ae(r);if(a)return a}}return null}function Re(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&qt(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Dt(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&qt(o))return o}const t=Re();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function mo(){const e=Dt();return e?e.closest(".sapUiRFLContainer")||e.closest(".sapUiFormCLContainer")||e.closest(".sapUiFormElementFields")||e.closest(".sapMFlexItem")||e.parentElement:null}function He(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const m=(l instanceof HTMLInputElement?l.value:l.textContent||"").trim();if(m&&!t.test(m))return m}a=a.parentElement}}return null}function po(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=He(n,/^Arrival\s*Date$/i)||He(n,/^Arrival$/i)||He(n,/^Anreise(datum)?$/i);if(!o)continue;const r=K(o);if(r)return r}return null}function fo(){if(uo())return!1;const e=po();return e?Et(e):!0}function zt(e,t){const n=ae(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}const bo=2e4;let A=null,de=null;const Fe=new Set;let v=null,O=!1,I=!1;function Ht(e){const t={vip:c.emmaRoom.reasonVip,premium:c.emmaRoom.reasonPremium,repeat:c.emmaRoom.reasonRepeat,one_night:c.emmaRoom.reasonOneNight,long_stay:c.emmaRoom.reasonLongStay,three_pax:c.emmaRoom.reasonThreePax,no_basement:c.emmaRoom.reasonNoBasement,not_ready:c.emmaRoom.reasonNotReady,category_not_ready:c.emmaRoom.reasonCategoryNotReady,overbook_view:c.emmaRoom.reasonOverbookView,overbook_corner:c.emmaRoom.reasonOverbookCorner,overbook_standard:c.emmaRoom.reasonOverbookStandard,wheelchair:c.emmaRoom.reasonWheelchair};return e.map(n=>t[n]).filter(n=>!!n).slice(0,3).join(" · ")}function xe(e,t){const n=o=>o.replace(/^0+/,"")||o;return e===t||n(e)===n(t)}function qe(e){const t=e instanceof Error?e.message:String(e??"");return/401|unauthorized|invalid token|jwt/i.test(t)?c.emmaRoom.signInRequired:c.emmaRoom.loadFailed}async function Je(){const e=A!=null&&A.error?5e3:bo;return A&&Date.now()-A.at<e?A:de||(de=(async()=>{let t;try{const n=await we("/reservations/room-suggestions");t={at:Date.now(),items:n.items??[],error:null}}catch(n){t={at:Date.now(),items:[],error:qe(n)}}return A=t,t})().finally(()=>{de=null}),de)}function Qe(e){return e.replace(/^0+/,"")||e}async function go(e){const t=Date.now(),n=[...new Set(e.map(Qe))].filter(o=>t-(Se.get(o)??0)>15e3);if(!n.length)return!1;for(const o of n)Se.set(o,t);try{const o=await we("/reservations/room-suggestions/unassigned",{method:"POST",body:JSON.stringify({reservationIds:n})});return A={at:Date.now(),items:o.items??[],error:null},!0}catch{for(const o of n)Se.delete(o);return!1}}function ho(e,t){var n;return((n=e.find(o=>xe(o.reservationId,t)))==null?void 0:n.suggestion)??null}function et(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!t.closest(`[${b}]`))return t;return null}function Ft(e,t){const n=et(e);if(n){n.nextElementSibling!==t&&n.insertAdjacentElement("afterend",t);return}const o=e.querySelector(".sapUiTableCellInner")||e;t.parentElement!==o&&o.appendChild(t)}function ut(e,t,n){const o=et(e);let r=e.querySelector(`[${b}="row"]`);const a=o?o.nextElementSibling===r:(r==null?void 0:r.parentElement)===(e.querySelector(".sapUiTableCellInner")||e);if(r&&a&&r.dataset.note===t&&r.dataset.error===(n?"1":"0"))return r;r||(r=document.createElement("div"),r.setAttribute(b,"row")),Ft(e,r),r.dataset.error=n?"1":"0",r.dataset.booking="",r.dataset.room="",r.dataset.note=t,r.innerHTML="";const i=document.createElement("span");return i.className=`pb-ra-row-note${n?" is-error":""}`,i.textContent=t,i.title=t,r.appendChild(i),r}async function Pt(e){return A=null,await we(`/reservations/${encodeURIComponent(e.reservationId)}/room-suggestion/accept`,{method:"POST",body:JSON.stringify({roomNumber:e.roomNumber})}),A=null,e.roomNumber}async function Nt(e){return await lo(e.reservationId,e.roomNumber),Pt(e)}async function yo(e){var o,r;const t=zt(e.roomNumber,(o=Re())==null?void 0:o.value);if(await To(t),ae(((r=Re())==null?void 0:r.value)??"")!==ae(t))throw new Error("room field");return Pt(e)}async function vo(e){A=null;const t=await we(`/reservations/${encodeURIComponent(e)}/room-suggestion/arriving-now`,{method:"POST"});return A=null,t.suggestion}async function wo(e,t){A=null;const n=await we(`/reservations/${encodeURIComponent(e)}/room-suggestion/shift`,{method:"POST",body:JSON.stringify({direction:t})});return A=null,n.suggestion}function xo(){let e=document.getElementById(fe);e||(e=document.createElement("style"),e.id=fe,document.documentElement.appendChild(e)),e.dataset.v!=="12"&&(e.dataset.v="12",e.textContent=`
    /* Detail: one SAP-like line under the Room field, in the document flow */
    #${p}{
      box-sizing:border-box;
      position:static;
      display:flex;
      flex-flow:row wrap;
      align-items:center;
      gap:0.25rem 0.5rem;
      flex:1 0 100%;
      width:100%;
      max-width:100%;
      margin:0.25rem 0 0 0;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      line-height:1.25;
      color:var(--sapTextColor,#1d2d3e);
      background:transparent;
      border:0;
      box-shadow:none;
      padding:0;
      z-index:auto;
      pointer-events:auto;
    }
    #${p} *{box-sizing:border-box;}
    #${p} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${p} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${p} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${p} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${p} .pb-ra-main{
      display:inline-flex;align-items:center;gap:0.35rem;flex-wrap:wrap;
      background:transparent;border:0;box-shadow:none;padding:0;
    }
    #${p} .pb-ra-room{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;font-weight:700;letter-spacing:0;line-height:1.2;
      color:var(--sapTextColor,#1d2d3e);
    }
    #${p} .pb-ra-meta{
      font-size:0.75rem;color:var(--sapContent_LabelColor,#556b82);margin:0;font-weight:400;
    }
    #${p} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${p} .pb-ra-btn{
      appearance:none;cursor:pointer;
      border:1px solid var(--sapButton_BorderColor,#bcc3ca);
      background:var(--sapButton_Background,#fff);
      width:1.5rem;height:1.5rem;border-radius:0.25rem;display:inline-flex;
      align-items:center;justify-content:center;color:var(--sapButton_TextColor,#1d2d3e);padding:0;
    }
    #${p} .pb-ra-btn:hover{background:var(--sapButton_Hover_Background,#f5f6f7);}
    #${p} .pb-ra-btn.pb-ra-accept{
      background:var(--sapButton_Emphasized_Background,#0070f2);
      border-color:var(--sapButton_Emphasized_BorderColor,#0070f2);
      color:var(--sapButton_Emphasized_TextColor,#fff);
    }
    #${p} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${p} .pb-ra-nudge{display:flex;flex-direction:column;gap:2px;}
    #${p} .pb-ra-nudge .pb-ra-btn{width:22px;height:16px;border-radius:5px;}
    #${p} .pb-ra-nudge .pb-ra-btn svg{width:11px;height:11px;}
    #${p} .pb-ra-actions{display:flex;align-items:center;gap:4px;}
    #${p} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${p} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${p} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${p} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${p} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${p} .pb-ra-note{
      font-size:0.75rem;font-weight:400;color:var(--sapContent_LabelColor,#556b82);line-height:1.25;
    }

    /* Check-in list Room column — one line, same height as an EMMA room number */
    .sapUiTableDataCell:has([${b}="row"]) .sapUiTableCellInner,
    .sapUiTableDataCell:has([${b}="row"]) .sapMVBox{
      overflow:visible !important;
      max-height:none !important;
    }
    [${b}="row"]{
      display:inline-flex !important;
      align-items:center;
      gap:0.3rem;
      margin:0;
      height:1.5rem;
      line-height:1;
      max-width:100%;
      flex-shrink:0;
      position:relative;
      z-index:20;
      pointer-events:auto;
      vertical-align:middle;
    }
    [${b}="row"] .pb-ra-row-code{
      display:inline-flex;
      align-items:center;
      gap:0.3rem;
      height:1.35rem;
      padding:0 0.45rem 0 0.35rem;
      border-radius:999px;
      border:1px solid #8eb4d4;
      background:#f3f8fc;
      color:#0b3a5b;
      font-family:var(--sapFontFamily,"72",system-ui,sans-serif);
      font-size:0.75rem;
      font-weight:700;
      letter-spacing:.04em;
      white-space:nowrap;
    }
    [${b}="row"] .pb-ra-row-code::before{
      content:"";
      width:0.4rem;
      height:0.4rem;
      border-radius:999px;
      background:#1b7a3a;
      flex:0 0 auto;
    }
    [${b}="row"] .pb-ra-row-code.pb-ra-dirty{
      background:#fff8f0;
      border-color:#e0b07a;
      color:#7a3e00;
    }
    [${b}="row"] .pb-ra-row-code.pb-ra-dirty::before{background:#c2410c;}
    [${b}="row"] .pb-ra-row-note{
      display:inline-block;
      max-width:8.5rem;
      font-size:0.68rem;
      font-weight:600;
      line-height:1.2;
      color:#9a3412;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
    [${b}="row"] .pb-ra-row-note.is-error{color:#9b1c1c;}
    #${p} .pb-ra-now{
      appearance:none;cursor:pointer;
      border:1px solid var(--sapButton_BorderColor,#bcc3ca);
      background:var(--sapButton_Background,#fff);
      border-radius:0.25rem;padding:0.15rem 0.4rem;
      font:inherit;font-size:0.75rem;font-weight:600;
      color:var(--sapButton_TextColor,#1d2d3e);
    }
    #${p} .pb-ra-now:hover{background:var(--sapButton_Hover_Background,#f5f6f7);}
    [${b}="row"] .pb-ra-row-accept{
      appearance:none;cursor:pointer;
      display:inline-flex;align-items:center;justify-content:center;
      width:1.35rem;height:1.35rem;padding:0;
      border:1px solid #1b7a3a;background:#1b7a3a;color:#fff;
      border-radius:999px;
    }
    [${b}="row"] .pb-ra-row-accept:hover{background:#14632f;}
    [${b}="row"] .pb-ra-row-accept svg{width:0.8rem;height:0.8rem;display:block;}
    #${H}{margin-inline-end:0.25rem;}
    #${G}{
      display:inline-flex;align-items:center;
      margin-inline-end:0.5rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;font-weight:600;
      color:var(--sapTextColor,#1d2d3e);
      white-space:nowrap;
    }
  `)}function $o(e){const t=Dt();let n=document.getElementById(p);const o=(n==null?void 0:n.parentElement)===e&&(!t||n.previousElementSibling===t||n.parentElement===e);if(n&&o&&!n.closest(".sapMInputBase"))return n;const r=n==null?void 0:n.dataset.key;return n==null||n.remove(),n=document.createElement("div"),n.id=p,n.setAttribute(b,"detail"),n.setAttribute("role","region"),n.setAttribute("aria-label",c.emmaRoom.title),r&&(n.dataset.key=r),(e.style.display.includes("flex")||e.classList.contains("sapUiRFLContainer"))&&(e.style.flexWrap="wrap"),t&&t.parentElement===e?t.insertAdjacentElement("afterend",n):e.appendChild(n),n}function te(){const e=document.getElementById(p);e&&(e.style.top="",e.style.left="")}function Co(e){return e.roomStatus==="DIRTY"||e.roomStatus==="CLEAN"||e.roomStatus==="IN_PROGRESS"?!0:e.roomStatus==="INSPECTED"||e.roomStatus==="OUT_OF_ORDER"?!1:!e.readyNow}function To(e){const t=`${Date.now()}-${Math.random().toString(16).slice(2)}`;return new Promise((n,o)=>{const r=window.setTimeout(()=>{document.removeEventListener("prize-ra-fill-room-done",a),o(new Error("room field"))},2500),a=i=>{const s=i.detail;!s||s.requestId!==t||(window.clearTimeout(r),document.removeEventListener("prize-ra-fill-room-done",a),s.error?o(new Error(s.error)):n())};document.addEventListener("prize-ra-fill-room-done",a),document.dispatchEvent(new CustomEvent("prize-ra-fill-room",{detail:{room:e,requestId:t}}))})}function Ot(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function mt(e){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="${e==="up"?"M6 14l6-6 6 6":"M6 10l6 6 6-6"}"/></svg>`}let _=null,be=null,E="",M=!1,We=!1,Pe=!1,Ne=!1,ge=!1;const Se=new Map;function ko(e){const t=Re();if(!t)return!1;const n=t.value,o=zt(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function F(e){var g,C,R,V;if(e.setAttribute("aria-label",c.emmaRoom.title),O&&!v){e.innerHTML=`<div class="pb-ra-note">${N(c.emmaRoom.loading)}</div>`,te();return}if(!v){if(ge&&!E){e.innerHTML=`<div class="pb-ra-note">${N(c.emmaRoom.loading)}</div>`,te();return}e.innerHTML=`<div class="pb-ra-note">${N(E||c.emmaRoom.noSuggestion)}</div>`,te();return}const t=ln(v.floor??Ct(v.roomNumber)),n=v.readyNow?c.emmaRoom.ready:c.emmaRoom.dirty,o=Ht(v.reasons),r=[t,n,o].filter(Boolean).join(" · "),a=E?`<div class="pb-ra-status${M?" pb-ra-warn":""}">${N(E)}</div>`:"",i=c.emmaRoom.accept,s=c.emmaRoom.higher,l=c.emmaRoom.lower,d=c.emmaRoom.arrivingNow,m=Co(v)?`<button type="button" class="pb-ra-now">${N(d)}</button>`:"";e.innerHTML=`<div class="pb-ra-main"><div><div class="pb-ra-room" title="${W(c.emmaRoom.previewNote)}">${N(v.roomNumber.padStart(4,"0"))}</div><div class="pb-ra-meta">${N(r)}</div></div><div class="pb-ra-actions"><div class="pb-ra-nudge"><button type="button" class="pb-ra-btn pb-ra-up" title="${W(s)}" aria-label="${W(s)}">${mt("up")}</button><button type="button" class="pb-ra-btn pb-ra-down" title="${W(l)}" aria-label="${W(l)}">${mt("down")}</button></div><button type="button" class="pb-ra-btn pb-ra-accept" title="${W(i)}" aria-label="${W(i)}">${Ot()}</button></div></div>`+m+a,te();const f=k=>{const T=Ve();if(!T||!v||I)return;const $=v;I=!0,O=!0,F(e),wo(T,k).then(S=>{v=S??$,_=null,E=S?"":k==="up"?c.emmaRoom.noHigher:c.emmaRoom.noLower,M=!S}).catch(S=>{v=$,E=qe(S),M=!0}).finally(()=>{I=!1,O=!1,F(e),P()})};(g=e.querySelector(".pb-ra-up"))==null||g.addEventListener("click",k=>{k.preventDefault(),k.stopPropagation(),f("up")}),(C=e.querySelector(".pb-ra-down"))==null||C.addEventListener("click",k=>{k.preventDefault(),k.stopPropagation(),f("down")}),(R=e.querySelector(".pb-ra-accept"))==null||R.addEventListener("click",k=>{if(k.preventDefault(),k.stopPropagation(),!v||I)return;const T=v;I=!0,yo(T).then($=>{ko($),E=oe(c.emmaRoom.applied,{room:$}),M=!1,v=null,_=null}).catch($=>{E=$ instanceof Error&&$.message&&$.message!=="CSRF"?`${c.emmaRoom.assignFailed}: ${$.message}`:c.emmaRoom.assignFailed,M=!0}).finally(()=>{I=!1,F(e),P()})}),(V=e.querySelector(".pb-ra-now"))==null||V.addEventListener("click",k=>{k.preventDefault(),k.stopPropagation();const T=Ve();!T||I||(I=!0,O=!0,F(e),vo(T).then($=>{v=$,_=null,E=$?"":c.emmaRoom.noSuggestion,M=!$}).catch($=>{E=qe($),M=!0}).finally(()=>{I=!1,O=!1,F(e),P()}))})}function N(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function W(e){return N(e).replace(/'/g,"&#39;")}function Ut(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function tt(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((i,s)=>{const l=(i.textContent||"").replace(/:/g,"").replace(/\s+/g," ").trim().toLowerCase();(l==="room"||l==="zimmer")&&(t=s),(l==="arrival"||l==="anreise")&&(n=s)}),{room:t,arrival:n}}function _e(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function jt(e){const t=/-col0$/;let n=null;for(const o of e.querySelectorAll('[id*="-col"]'))if(t.test(o.id)){n=o;break}if(n||(n=e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")),!n)return null;for(const o of n.querySelectorAll(".sapMText, a.sapMLnk")){if(o.closest(`[${b}]`))continue;const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r}return null}function Gt(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${b}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&_t(n))return ae(n)}return null}function So(e){for(const t of e.querySelectorAll(".sapMText")){const n=(t.textContent||"").trim(),o=K(n);if(o)return o}return K((e.textContent||"").trim())}function Eo(e,t){if(t){const n=So(t);if(n)return n}for(const n of e.querySelectorAll(".sapMText")){if(n.closest(`[${b}]`))continue;const o=K((n.textContent||"").trim());if(o)return o}return null}function Bo(e,t){const n=t.reservationId,o=t.roomNumber;let r=e.querySelector(`[${b}="row"]`);const a=et(e);if(r&&r.dataset.booking===n&&r.dataset.room===o&&r.dataset.ready===String(t.readyNow)&&(a==null?void 0:a.nextElementSibling)===r)return r;r||(r=document.createElement("div"),r.setAttribute(b,"row")),Ft(e,r),r.dataset.booking=n,r.dataset.room=o,r.dataset.ready=String(t.readyNow),r.innerHTML="";const i=document.createElement("span");i.className=`pb-ra-row-code${t.readyNow?"":" pb-ra-dirty"}`;const s=o.padStart(4,"0");i.textContent=s;const l=Ht(t.reasons);i.title=[c.emmaRoom.title,s,t.readyNow?c.emmaRoom.ready:c.emmaRoom.dirty,l].filter(Boolean).join(" · ");const d=document.createElement("button");return d.type="button",d.className="pb-ra-row-accept",d.innerHTML=Ot(),d.title=c.emmaRoom.accept,d.setAttribute("aria-label",c.emmaRoom.accept),d.addEventListener("click",m=>{m.preventDefault(),m.stopPropagation(),!I&&(I=!0,Nt(t).then(()=>{const f=e.querySelector(".sapMText, a.sapMLnk");f&&!f.closest(`[${b}]`)&&(f.textContent=s),r==null||r.remove()}).catch(()=>{i.title=c.emmaRoom.assignFailed}).finally(()=>{I=!1}))}),r.appendChild(i),r.appendChild(d),r}function Io(){const e=document.querySelector('[id*="CheckInList"][id*="stickyToolbar"]');if(!e)return null;for(const t of e.querySelectorAll("button")){if(t.id===H)continue;const n=`${t.getAttribute("aria-label")||""} ${t.getAttribute("title")||""}`.toLowerCase();if(/express\s*check/.test(n))return t}return null}function he(e){const t=document.getElementById(H);if(!t)return;t.title=e,t.setAttribute("aria-label",e);const n=t.querySelector("bdi");n&&(n.textContent=e)}function Ao(){const e=`${Date.now()}-${Math.random().toString(16).slice(2)}`;return new Promise(t=>{const n=window.setTimeout(()=>{document.removeEventListener("prize-ra-checkin-rows-done",o),t(null)},400),o=r=>{const a=r.detail;!a||a.requestId!==e||(window.clearTimeout(n),document.removeEventListener("prize-ra-checkin-rows-done",o),t(a.rows??null))};document.addEventListener("prize-ra-checkin-rows-done",o),document.dispatchEvent(new CustomEvent("prize-ra-checkin-rows",{detail:{requestId:e}}))})}function Lo(e){const t=e.trim();return!t||t==="0000"?!0:!_t(t)}function Mo(e,t){if(t!=null&&t.length){const n=new Set;let o=0;for(const r of t){const a=Qe(r.id);if(n.has(a)||!Lo(r.room))continue;n.add(a);const i=e.items.find(s=>xe(s.reservationId,r.id));i!=null&&i.suggestion&&(o+=1)}return o}return e.items.filter(n=>n.suggestion).length}function pt(e,t){let n=document.getElementById(G);(!n||n.nextElementSibling!==t)&&(n==null||n.remove(),n=document.createElement("span"),n.id=G,n.className="sapMBarChild",t.insertAdjacentElement("beforebegin",n)),n.textContent=oe(c.emmaRoom.assignAllAvailable,{count:e})}function ft(e=0){var o,r;const t=Io();if(!t){(o=document.getElementById(H))==null||o.remove(),(r=document.getElementById(G))==null||r.remove();return}let n=document.getElementById(H);if((n==null?void 0:n.nextElementSibling)===t){n.dataset.busy!=="1"&&n.dataset.hold!=="1"&&he(c.emmaRoom.assignAll),pt(e,n);return}n==null||n.remove(),n=document.createElement("button"),n.id=H,n.type="button",n.className="sapMBtnBase sapMBtn sapMBarChild",n.innerHTML='<span class="sapMBtnInner sapMBtnHoverable sapMFocusable sapMBtnEmphasized"><span class="sapMBtnContent"><bdi></bdi></span></span>',n.addEventListener("click",a=>{a.preventDefault(),a.stopPropagation(),qo()}),t.insertAdjacentElement("beforebegin",n),he(c.emmaRoom.assignAll),pt(e,n)}function Vt(e){const t=Ut();if(!t)return null;for(const n of t.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr")){const o=jt(n);if(o&&xe(o,e))return n}return null}function Ro(e){var s;const t=Vt(e.reservationId),n=t==null?void 0:t.closest("table");if(!t||!n)return;const o=tt(n),r=_e(t,o.room);if(!r)return;const a=e.roomNumber.padStart(4,"0"),i=r.querySelector(".sapMText, a.sapMLnk");i&&!i.closest(`[${b}]`)&&(i.textContent=a),(s=r.querySelector(`[${b}]`))==null||s.remove()}async function qo(){const e=document.getElementById(H);if(!e||I||e.dataset.busy==="1")return;const n=(await Je()).items.filter(a=>{if(!a.suggestion)return!1;const i=Vt(a.reservationId),s=i==null?void 0:i.closest("table");if(!i||!s)return!0;const l=tt(s),d=_e(i,l.room);return!d||!Gt(d)});if(!n.length)return;I=!0,e.dataset.busy="1",e.disabled=!0,e.classList.add("sapMBtnDisabled");let o=0,r=0;try{for(const a of n){const i=a.suggestion;if(i){he(oe(c.emmaRoom.assignAllBusy,{done:o+r,total:n.length}));try{await Nt(i),o+=1,Ro(i)}catch{r+=1}}}}finally{I=!1,e.dataset.busy="0",e.disabled=!1,e.classList.remove("sapMBtnDisabled"),e.dataset.hold="1",he(r?oe(c.emmaRoom.assignAllPartial,{done:o,failed:r}):oe(c.emmaRoom.assignAllDone,{count:o})),window.setTimeout(()=>{e.dataset.hold="0",he(c.emmaRoom.assignAll)},4e3),A=null,P()}}function _o(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}async function bt(e){var m,f;const t=Ut();if(!t){_o()?ft(0):(document.querySelectorAll(`[${b}="row"]`).forEach(g=>g.remove()),(m=document.getElementById(H))==null||m.remove(),(f=document.getElementById(G))==null||f.remove());return}const n=tt(t),o=t.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),r=new Set(o),a=new Set,i=new Set,s=await Je(),l=await Ao(),d=Mo(s,l);for(const g of o){const C=jt(g);if(!C)continue;const R=_e(g,n.room),V=_e(g,n.arrival);if(!R)continue;const k=Gt(R),T=R.querySelector(`[${b}="row"]`);if(k){Se.delete(Qe(C)),T==null||T.remove();continue}const $=Eo(g,V);if($&&!Et($)){T==null||T.remove();continue}if(s.error){a.add(ut(R,s.error,!0));continue}const S=s.items.find(Xt=>xe(Xt.reservationId,C)),ze=S!=null&&S.suggestion?S.suggestion.roomNumber.replace(/^0+/,""):"";if(!(S!=null&&S.suggestion)||ze&&i.has(ze)){S||e==null||e.add(C),S?a.add(ut(R,c.emmaRoom.noSuggestion,!1)):ge||T==null||T.remove();continue}i.add(ze),a.add(Bo(R,S.suggestion))}document.querySelectorAll(`[${b}="row"]`).forEach(g=>{if(!(g instanceof HTMLElement)||a.has(g))return;const C=g.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!C||!r.has(C))&&g.remove()}),ft(d)}function De(){var e;(e=document.getElementById(p))==null||e.remove(),_=null,v=null,O=!1,E="",M=!1}async function gt(e){var s;const t=Ve(),n=mo();if(!n||!t){De();return}if(!fo()){De();return}const o=((s=document.getElementById(p))==null?void 0:s.parentElement)===n,r=$o(n);te();const a=t;if(!o&&r.dataset.key===a&&F(r),r.dataset.key===a||Fe.has(a))return;Fe.add(a);const i=_!==a;_=a,i&&(E="",M=!1),O=!0,F(r);try{const l=await Je();if(_!==a)return;l.error?(v=null,E=l.error,M=!0):(v=ho(l.items,t),v||(l.items.some(m=>xe(m.reservationId,t))?(E=c.emmaRoom.noSuggestion,M=!0):(e==null||e.add(t),E="",M=!1))),r.dataset.key=a}catch(l){if(_!==a)return;v=null,E=qe(l),M=!0,r.dataset.key=a}finally{O=!1,Fe.delete(a)}_===a&&F(r)}async function Wt(){if(Pe){Ne=!0;return}Pe=!0,We=!0;try{if(!co()){De(),document.querySelectorAll(`[${b}="row"]`).forEach(t=>t.remove());return}xo();const e=new Set;if(ge=!1,await bt(e),await gt(e),e.size){ge=!0;const t=document.getElementById(p);t&&F(t);const n=await go([...e]);ge=!1,n?(t&&delete t.dataset.key,await bt(),await gt()):t&&F(t)}}finally{Pe=!1,window.setTimeout(()=>{We=!1,Ne&&(Ne=!1,P())},0)}}function P(){be&&window.clearTimeout(be),be=window.setTimeout(()=>{Wt()},350)}function Do(){ye().then(n=>{c=L(n),_=null,P()}),ve(n=>{c=L(n),_=null,P()}),Wt();const e=()=>te();window.addEventListener("scroll",e,!0),window.addEventListener("resize",e),window.addEventListener("hashchange",()=>{var n;_=null,v=null,(n=document.getElementById(p))==null||n.removeAttribute("data-key"),P()});const t=new MutationObserver(n=>{if(!We)for(const o of n){const r=o.target;if(r instanceof Element&&(r.id===p||r.id===fe||r.id===H||r.id===G||r.closest(`[${b}]`)||r.closest(`#${H}`)||r.closest(`#${G}`)))continue;const a=[...o.addedNodes];if(!(a.length>0&&a.every(i=>i instanceof Element&&(i.id===p||i.id===fe||i.id===H||i.id===G||i.hasAttribute(b))))){P();return}}});return t.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var n;t.disconnect(),be&&window.clearTimeout(be),De(),document.querySelectorAll(`[${b}="row"]`).forEach(o=>o.remove()),(n=document.getElementById(fe))==null||n.remove()}}const ht="prize-panel-host";let U=L("de");function Yt(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function Ee(e,t,n){const o=`${Be}px 0 0 ${Be}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=Yt(),t.title=U.inject.openPanel,t.setAttribute("aria-label",U.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${wt}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=U.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function yt(e,t,n){var i;const r=!await Ye(j.panelCollapsed);await Qt({[j.panelCollapsed]:r}),Ee(e,t,r);const a=e.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?ne.collapsed:ne.expanded},"*")}function vt(){if(document.getElementById(ht))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${Be}px 0 0 ${Be}px`,r=document.createElement("div");r.id=ht,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${Zt}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:Ce,border:`1px solid ${Oe}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=U.inject.panelTitle,Object.assign(i.style,{width:`${wt}px`,height:"100%",border:"none",display:"block",background:Ce}),a.appendChild(i);const s=document.createElement("button");s.id="prize-panel-tab",s.type="button",Object.assign(s.style,{width:`${nt}px`,height:`${Jt}px`,minWidth:`${nt}px`,border:`1px solid ${Oe}`,borderRight:"none",background:`linear-gradient(180deg, ${Ce} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),s.innerHTML=Yt(),s.addEventListener("mouseenter",()=>{s.style.filter="brightness(1.12)"}),s.addEventListener("mouseleave",()=>{s.style.filter=""}),s.addEventListener("click",()=>{yt(a,s)}),r.appendChild(a),r.appendChild(s),document.documentElement.appendChild(r),Ye(j.panelCollapsed).then(l=>{t=l,Ee(a,s,l)}),window.addEventListener("message",l=>{var d,m,f,g;((d=l.data)==null?void 0:d.type)===ne.toggle&&yt(a,s),((m=l.data)==null?void 0:m.type)===ne.chatOpen&&(e=!0,n()&&((f=document.getElementById("prize-panel-chat-toast"))==null||f.remove())),((g=l.data)==null?void 0:g.type)===ne.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((l,d)=>{d==="local"&&l[j.panelCollapsed]&&(t=!!l[j.panelCollapsed].newValue)}),yn(n),Dn(),no(),Do(),ye().then(l=>{U=L(l),Ee(a,s,t),i.title=U.inject.panelTitle}),ve(l=>{U=L(l),Ee(a,s,t),i.title=U.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",vt):vt();
