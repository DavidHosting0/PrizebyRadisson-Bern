import{b as ue,S as A,P as D,c as X,d as ce,A as Fe,e as ee,f as Ne,g as Ce,T as xe,h as De,s as Oe}from"./storage-DTWcLCTt.js";import{l as oe,w as re,i as L,g as w,a as qe,b as He,p as _e,c as ye,d as je,t as ve,B as Ge,e as Ue,f as We}from"./bernticket-api-C8un-PY9.js";const de=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function Ve(t){const e=parseInt(t,10);return Number.isFinite(e)?e%100===13:!0}function Ye(t){if(Ve(t))return null;const e=parseInt(t,10);if(!Number.isFinite(e))return null;if(e>=1&&e<=17)return-1;if(e>=21&&e<=37)return 0;for(let n=1;n<=de.length;n++){const[o,r]=de[n-1];if(e>=o&&e<=r)return n}return null}function Xe(){const t=[];for(let e=1;e<=17;e++)e%100!==13&&t.push(String(e));for(let e=21;e<=37;e++)t.push(String(e));for(const[e,n]of de)for(let o=e;o<=n;o++)o%100!==13&&t.push(String(o));return t}function Ke(t,e){const n=parseInt(t,10),o=parseInt(e,10),r=Number.isFinite(n),a=Number.isFinite(o);return r&&a?n-o:r&&!a?-1:!r&&a?1:t.localeCompare(e)}function Ze(t){return t==null?"—":t===-2?"Lobby":t===-1?"Floor -1":t===8?"Rooftop Bar":`Floor ${t}`}let j=w("de");const T="prize-panel-chat-toast",$e="prize-panel-chat-toast-style",Qe=8e3,Je=7e3;function et(t){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(t)}function tt(t){return t==="/r"||t.startsWith("/r/")}function nt(t,e=72){const n=t.replace(/\s+/g," ").trim();return n.length<=e?n:`${n.slice(0,e-1)}…`}function ot(){if(document.getElementById($e))return;const t=document.createElement("style");t.id=$e,t.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${T}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${X} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${ce};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${T}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${T} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${T} .pb-ct-body{min-width:0;flex:1;}
    #${T} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${Fe};margin-bottom:2px;
    }
    #${T} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${T} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${T} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${T} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(t)}let K=null;function F(t=!0){const e=document.getElementById(T);if(e){if(K&&(window.clearTimeout(K),K=null),!t){e.remove();return}e.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>e.remove(),220)}}function rt(){try{const t=window.AudioContext||window.webkitAudioContext;if(!t)return;const e=new t,n=e.currentTime,o=e.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(e.destination);const r=(a,i,s)=>{const l=e.createOscillator(),u=e.createGain();l.type="sine",l.frequency.setValueAtTime(a,i),u.gain.setValueAtTime(1e-4,i),u.gain.exponentialRampToValueAtTime(.9,i+.015),u.gain.exponentialRampToValueAtTime(1e-4,i+s),l.connect(u),u.connect(o),l.start(i),l.stop(i+s+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{e.close()},600)}catch{}}function at(t,e){ot(),F(!1);const n=document.createElement("div");n.id=T,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),s=r.querySelector(".pb-ct-preview");a.textContent=j.toast.eyebrow,i.textContent=L(j.toast.newMessageFrom,{author:t}),s.textContent=nt(e);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",j.toast.close),l.textContent="×",l.addEventListener("click",u=>{u.stopPropagation(),F(!0)}),n.addEventListener("click",()=>F(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),rt(),K=window.setTimeout(()=>{F(!0)},Je)}function it(){return new Promise(t=>{try{chrome.runtime.sendMessage({type:D.latestChat},e=>{if(chrome.runtime.lastError){t({ok:!1});return}t(e??{ok:!1})})}catch{t({ok:!1})}})}function st(t){let e=!1,n=null,o=!0;oe().then(s=>{j=w(s)});const r=re(s=>{j=w(s)});ue(A.chatNotificationsEnabled,!0).then(s=>{o=s});try{chrome.storage.onChanged.addListener((s,l)=>{if(l==="local"&&s[A.chatNotificationsEnabled]){const u=s[A.chatNotificationsEnabled].newValue;o=u===void 0?!0:!!u,o||F(!1)}})}catch{}const a=async()=>{var s,l,u;if(!e)try{if(!o)return;const g=await it();if(!g.ok)return;const f=g.msg;if(!(f!=null&&f.id))return;if(n===null){n=f.id;return}if(f.id===n||(n=f.id,(s=f.author)!=null&&s.id&&g.meId&&f.author.id===g.meId)||t()||et(window.location.pathname)||tt(window.location.pathname))return;const v=((u=(l=f.author)==null?void 0:l.name)==null?void 0:u.trim())||"Team";at(v,f.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},Qe);return()=>{e=!0,window.clearInterval(i),r(),F(!1)}}let d=w("de");const p="prize-bt-checkin-host",te="prize-bt-checkin-style",m="prize-bt-fallback-bar";function lt(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function ct(){const t=window.location.hash||"",e=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const r of e){const a=t.match(r);if(a)return a[1].replace(/^0+/,"")||a[1]}for(const r of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const a=(r.textContent||"").trim();if(/^\d{6,}$/.test(a))return a.replace(/^0+/,"")||a}const n=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),o=((n==null?void 0:n.textContent)||"").match(/\b(\d{6,})\b/);return o?o[1].replace(/^0+/,"")||o[1]:null}function Se(){const t=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="Toolbar"]','[id*="checkinToolbar"]',".sapUxAPObjectPageFloatingFooter.sapMTB",".sapUxAPObjectPageFloatingFooter",".sapFDynamicPageFooter .sapMTB"];for(const e of t){const n=document.querySelector(e);if(n)return n}return null}function be(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}const dt={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function we(t){const e=t.trim().replace(/\s+/g," ");if(!e)return null;const n=e.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=e.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=e.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=dt[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(e);if(!Number.isNaN(a)){const i=new Date(a),s=i.getFullYear(),l=String(i.getMonth()+1).padStart(2,"0"),u=String(i.getDate()).padStart(2,"0");if(s>=2e3)return`${s}-${l}-${u}`}return null}function N(t,e){const n=t.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!e.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const g=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(g&&!e.test(g))return g}a=a.parentElement}}return null}function pt(){return new Date().toISOString().slice(0,10)}function ut(){const t=new Date;return t.setDate(t.getDate()+1),t.toISOString().slice(0,10)}function bt(){const t=be()||document.body,e=N(t,/^Arrival\s*Date$/i)||N(t,/^Anreise(datum)?$/i),n=N(t,/^Departure\s*Date$/i)||N(t,/^Abreise(datum)?$/i),o=e&&we(e)||pt(),r=n&&we(n)||ut();return{from:o,to:r}}function mt(){const t=be()||document.body,e=document.querySelector('[id*="FolioPaxTypes"]')||t;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=N(e,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of e.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function ft(){const t=be()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=N(t,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const e=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of e){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function gt(t){const e=bt();return{guestName:ft(),bookingNumber:t,from:e.from,to:e.to,ticketsAmount:mt()}}function ht(){const t=document.getElementById(te);t&&t.remove();const e=document.createElement("style");e.id=te,e.textContent=`
    /* Center BernTicket inside the flex spacer of the SAP overflow toolbar */
    .sapMTBSpacer:has(#${p}),
    .sapMTBSpacerFlex:has(#${p}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    #${p}, #${m}{
      box-sizing:border-box;
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      pointer-events:auto;
      z-index:5;
    }
    #${p} *, #${m} *{box-sizing:border-box;}

    /* Compact chip in the check-in toolbar spacer */
    #${p}{
      position:relative !important;
      margin:0 !important;
      max-width:min(420px,100%);
      display:inline-flex !important;
      flex-direction:row !important;
      align-items:center !important;
      justify-content:center !important;
      gap:8px !important;
      flex-wrap:nowrap !important;
      flex:0 1 auto !important;
      padding:4px 10px !important;
      background:rgba(255,255,255,.96) !important;
      border:1px solid rgba(45,58,79,.16) !important;
      border-radius:999px !important;
      box-shadow:0 2px 10px rgba(15,23,42,.1) !important;
      white-space:nowrap;
    }

    /* Fallback floating bar (no toolbar) */
    #${m}{
      position:fixed;left:50%;bottom:72px;transform:translateX(-50%);
      width:max-content;max-width:min(560px,calc(100vw - 28px));
      background:linear-gradient(180deg,#ffffff 0%,#f8fafc 100%);
      border:1px solid rgba(45,58,79,.14);
      border-radius:16px;
      box-shadow:0 10px 36px rgba(15,23,42,.16);
      padding:10px 14px;
      display:flex;flex-direction:column;align-items:center;gap:8px;
    }

    #${p} .pb-bt-row, #${m} .pb-bt-row{
      display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;
    }
    #${p} .pb-bt-brand, #${m} .pb-bt-brand{
      display:inline-flex;align-items:center;gap:6px;
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:#1a2332;
    }
    #${p} .pb-bt-dot, #${m} .pb-bt-dot{
      width:7px;height:7px;border-radius:999px;background:#3b6fa0;
      box-shadow:0 0 0 3px rgba(59,111,160,.18);flex-shrink:0;
    }
    #${p} .pb-bt-code, #${m} .pb-bt-code{
      appearance:none;border:0;cursor:pointer;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-weight:800;letter-spacing:.1em;line-height:1;color:#991b1b;
      background:linear-gradient(180deg,#fff5f5,#fee2e2);
      border:1px solid #fecaca;border-radius:999px;
      transition:background .12s ease,box-shadow .12s ease,transform .12s ease;
    }
    #${p} .pb-bt-code{
      font-size:14px;padding:6px 12px;min-width:7.5rem;text-align:center;
    }
    #${m} .pb-bt-code{
      font-size:18px;padding:10px 18px;min-width:9.5rem;text-align:center;border-radius:12px;
    }
    #${p} .pb-bt-code:hover, #${m} .pb-bt-code:hover{
      background:linear-gradient(180deg,#fff1f1,#fecaca);
      box-shadow:0 3px 10px rgba(153,27,27,.12);
    }
    #${p} .pb-bt-hint{display:none}
    #${m} .pb-bt-hint{
      font-size:10px;color:#64748b;text-align:center;line-height:1.3;
    }
    #${p} .pb-bt-meta, #${m} .pb-bt-meta{
      font-size:10px;color:#64748b;font-variant-numeric:tabular-nums;
    }
    #${p} .pb-bt-muted, #${m} .pb-bt-muted{
      font-size:11px;color:#475569;
    }
    #${p} .pb-bt-btn, #${m} .pb-bt-btn{
      appearance:none;cursor:pointer;
      border:1px solid #3b6fa0;background:#3b6fa0;color:#fff;
      border-radius:999px;padding:5px 10px;font-size:11px;font-weight:600;
    }
    #${p} .pb-bt-btn:hover, #${m} .pb-bt-btn:hover{background:#345f89}
    #${p} .pb-bt-btn:disabled, #${m} .pb-bt-btn:disabled{opacity:.55;cursor:not-allowed}
    #${p} .pb-bt-btn.pb-bt-ghost, #${m} .pb-bt-btn.pb-bt-ghost{
      background:#fff;color:#1a2332;border-color:#cbd5e1;
    }
    #${p} .pb-bt-form, #${m} .pb-bt-form{
      display:flex;flex-wrap:wrap;gap:4px;align-items:center;justify-content:center;
    }
    #${p} .pb-bt-form input, #${m} .pb-bt-form input{
      height:26px;border-radius:6px;border:1px solid #cbd5e1;
      background:#fff;color:#1a2332;padding:0 6px;font-size:11px;min-width:72px;
    }
    #${p} .pb-bt-form input.pb-bt-name, #${m} .pb-bt-form input.pb-bt-name{min-width:110px}
    #${p} .pb-bt-copied, #${m} .pb-bt-copied{
      font-size:10px;font-weight:600;color:#15803d;
    }
  `,document.documentElement.appendChild(e)}function xt(t){var o,r;(o=document.getElementById(m))==null||o.remove();let e=document.getElementById(p);if(e&&t.contains(e))return e;e==null||e.remove(),e=document.createElement("div"),e.id=p,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label","BernTicket Aktivierungscode");const n=t.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||t.querySelector(".sapMTBSpacer");if(n)n.appendChild(e);else{e.className="sapMBarChild";const a=((r=t.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...t.querySelectorAll("button, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));(a==null?void 0:a.parentElement)===t?t.insertBefore(e,a):t.appendChild(e)}return e}function yt(){var e;(e=document.getElementById(p))==null||e.remove();let t=document.getElementById(m);return t||(t=document.createElement("div"),t.id=m,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label","BernTicket Aktivierungscode"),document.documentElement.appendChild(t),t)}function k(t,e){t.innerHTML=e}function E(t,e=!1){const n=`<span class="pb-bt-brand"><span class="pb-bt-dot" aria-hidden="true"></span>${c(d.emmaBt.brand)}</span>`;return e?n+t:`<div class="pb-bt-row">${n}</div>`+t}async function vt(t){try{await navigator.clipboard.writeText(t)}catch{}}function ke(t,e){const n=t.querySelector(".pb-bt-code"),o=t.querySelector(".pb-bt-hint"),r=t.querySelector(".pb-bt-brand");n==null||n.addEventListener("click",()=>{vt(e).then(()=>{if(o)o.innerHTML=`<span class="pb-bt-copied">${c(d.emmaBt.copied)}</span>`,window.setTimeout(()=>{o.isConnected&&(o.textContent=d.emmaBt.clickToCopy)},1200);else if(r){const a=r.innerHTML;r.innerHTML=`<span class="pb-bt-copied">${c(d.emmaBt.copied)}</span>`,window.setTimeout(()=>{r.isConnected&&(r.innerHTML=a)},1e3)}})})}let y=null,G=null,V=0;async function P(t,e,n){var a;const o=++V,r=await qe();if(o===V){if(!r.access){k(t,E(n?`<span class="pb-bt-muted">${c(d.emmaBt.loginHint)}</span>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(d.emmaBt.loginHint)}</span></div><div class="pb-bt-hint">${c(L(d.emmaBt.booking,{number:e}))}</div>`,n));return}k(t,E(n?`<span class="pb-bt-muted">${c(d.emmaBt.loading)}</span>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(d.emmaBt.loading)}</span></div>`,n));try{const i=await He(e);if(o!==V)return;const s=_e(i,e),l=ye(s),u=d.bernticket.copyCode,g=d.emmaBt.clickToCopy;if(s&&l){k(t,E(n?`<button type="button" class="pb-bt-code" title="${S(u)}">${c(l)}</button>`:`<div class="pb-bt-row"><button type="button" class="pb-bt-code" title="${S(u)}">${c(l)}</button></div><div class="pb-bt-hint">${c(g)} · <span class="pb-bt-meta">${c(L(d.emmaBt.booking,{number:e}))}</span></div>`,n)),ke(t,l);return}if(s&&!l){const z=L(d.emmaBt.noCode,{status:s.status});k(t,E(n?`<span class="pb-bt-muted">${c(z)}</span>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(z)}</span></div>`,n));return}const f=gt(e);k(t,E((n?"":`<div class="pb-bt-row"><span class="pb-bt-muted">${c(d.emmaBt.noTicketCreate)}</span></div>`)+`<div class="pb-bt-form"><span class="pb-bt-meta" title="Reservierungsnummer">#${c(f.bookingNumber)}</span><input class="pb-bt-name" placeholder="${S(d.emmaBt.guestNamePlaceholder)}" value="${S(f.guestName)}" /><input class="pb-bt-from" type="date" value="${S(f.from)}" title="Anreise" /><input class="pb-bt-to" type="date" value="${S(f.to)}" title="Abreise" /><input class="pb-bt-amt" type="number" min="1" value="${f.ticketsAmount}" style="width:52px" title="Personen (Pax)" /><button type="button" class="pb-bt-btn pb-bt-create">${c(d.emmaBt.create)}</button></div>`,n));const v=t.querySelector(".pb-bt-create");v==null||v.addEventListener("click",()=>{(async()=>{var fe,ge,he;const z=t.querySelector(".pb-bt-name"),ie=t.querySelector(".pb-bt-from"),se=t.querySelector(".pb-bt-to"),le=t.querySelector(".pb-bt-amt"),me=(z==null?void 0:z.value.trim())||f.guestName;if(!me){k(t,E(n?`<span class="pb-bt-muted">${c(d.emmaBt.guestNameMissing)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(d.emmaBt.guestNameMissing)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button></div>`,n)),(fe=t.querySelector(".pb-bt-retry"))==null||fe.addEventListener("click",()=>{P(t,e,n)});return}v.disabled=!0,v.textContent="…";try{const C=await je({guestName:me,bookingNumber:f.bookingNumber,validFrom:ve((ie==null?void 0:ie.value)||f.from),validTo:ve((se==null?void 0:se.value)||f.to),ticketsAmount:Math.max(1,parseInt((le==null?void 0:le.value)||String(f.ticketsAmount),10)||f.ticketsAmount)}),M=ye(C);M?(k(t,E(n?`<button type="button" class="pb-bt-code" title="${S(u)}">${c(M)}</button>`:`<div class="pb-bt-row"><button type="button" class="pb-bt-code" title="${S(u)}">${c(M)}</button></div><div class="pb-bt-hint">${c(g)} · <span class="pb-bt-meta">${c(L(d.emmaBt.booking,{number:e}))}</span></div>`,n)),ke(t,M)):(y=null,await P(t,e,n))}catch(C){if(C instanceof Ge&&C.code===Ue){const M=window.prompt(d.emmaBt.twoFaPrompt);if(M)try{await We(M),v.disabled=!1,v.textContent=d.emmaBt.create,v.click();return}catch(W){k(t,E(n?`<span class="pb-bt-muted">${c(W instanceof Error?W.message:d.emmaBt.twoFaFailed)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(W instanceof Error?W.message:d.emmaBt.twoFaFailed)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button></div>`,n)),(ge=t.querySelector(".pb-bt-retry"))==null||ge.addEventListener("click",()=>{P(t,e,n)});return}}k(t,E(n?`<span class="pb-bt-muted">${c(C instanceof Error?C.message:d.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(C instanceof Error?C.message:d.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button></div>`,n)),(he=t.querySelector(".pb-bt-retry"))==null||he.addEventListener("click",()=>{P(t,e,n)})}})()})}catch(i){if(o!==V)return;k(t,E(n?`<span class="pb-bt-muted">${c(i instanceof Error?i.message:d.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(i instanceof Error?i.message:d.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-ghost pb-bt-retry">${c(d.emmaBt.retry)}</button></div>`,n)),(a=t.querySelector(".pb-bt-retry"))==null||a.addEventListener("click",()=>{y=null,P(t,e,n)})}}}function c(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function S(t){return c(t).replace(/'/g,"&#39;")}function O(){G&&window.clearTimeout(G),G=window.setTimeout(()=>{Ae()},350)}function Ie(t){return document.documentElement.contains(t)}async function Ae(){var r,a,i,s;if(!lt()){(r=document.getElementById(p))==null||r.remove(),(a=document.getElementById(m))==null||a.remove(),y=null;return}ht();const t=ct(),e=Se();if(!t&&!e){(i=document.getElementById(p))==null||i.remove(),(s=document.getElementById(m))==null||s.remove(),y=null;return}const n=!!e,o=e?xt(e):yt();if(!t){k(o,E(n?`<span class="pb-bt-muted">${c(d.emmaBt.noBooking)}</span>`:`<div class="pb-bt-row"><span class="pb-bt-muted">${c(d.emmaBt.noBooking)}</span></div>`,n)),y=null,o.dataset.bound="";return}if(t===y&&o.dataset.bound===t&&Ie(o))if(e&&!e.contains(o))y=null;else return;y=t,o.dataset.bound=t,await P(o,t,n)}function $t(){oe().then(e=>{d=w(e),y=null,O()}),re(e=>{d=w(e),y=null,O()}),Ae(),window.addEventListener("hashchange",()=>{y=null,O()});const t=new MutationObserver(e=>{let n=!1;for(const a of e){const i=a.target;if(!(i instanceof Element&&(i.id===p||i.id===m||i.id===te||i.closest("[data-prize-bernticket]")))){n=!0;break}}if(!n)return;const o=Se(),r=document.getElementById(p)||document.getElementById(m);r&&!Ie(r)&&(y=null),o&&(r==null?void 0:r.id)===p&&!o.contains(r)&&(y=null),o&&!r&&(y=null),O()});t.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((e,n)=>{n==="local"&&(e.btAccessToken||e.btRefreshToken)&&(y=null,O())})}catch{}return()=>{var e,n,o;t.disconnect(),G&&window.clearTimeout(G),(e=document.getElementById(p))==null||e.remove(),(n=document.getElementById(m))==null||n.remove(),(o=document.getElementById(te))==null||o.remove()}}let x=w("de");const b="prize-ra-host",ne="prize-ra-style",q=Xe().sort(Ke);function wt(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Me(){const t=window.location.hash||"",e=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of e){const o=t.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function Re(){const t=['[id$="tms.checkinheaderContent"]','[id*="tms.checkinheaderContent"]','[id*="checkinheaderContent"]','[id$="tms.reservationheaderContent"]','[id*="reservationheaderContent"]','[id*="HeaderContent"][id*="tms."]','[id*="CheckInDetail"][id*="headerContent"]','[id*="ReservationDetail"][id*="headerContent"]'];for(const e of t){const n=document.querySelector(e);if(n&&n.offsetParent!==null)return n}return null}function ae(t){const e=t.replace(/[^\d]/g,"");return e?String(parseInt(e,10)):""}function pe(){var e;const t=['[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of t){const o=document.querySelector(n),r=(e=o==null?void 0:o.value)==null?void 0:e.trim();if(r){const a=ae(r);if(a)return a}}return null}function kt(){const t=['[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const e of t){const n=document.querySelector(e);if(n)return n}return null}function Et(t,e){const n=ae(t);if(!n)return t;const o=e&&/^\d+$/.test(e.trim())?e.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}function Tt(t){const e=ae(t);return q.findIndex(n=>n===e)}function Le(t,e,n){const o=n?ae(n):null;let r=0;if(o){const l=Tt(o);l>=0&&(r=l)}else t&&(r=[...t].reduce((u,g)=>u+g.charCodeAt(0),0)%q.length);e==="higher"?r=Math.min(q.length-1,r+1):e==="lower"?r=Math.max(0,r-1):e==="extra_bed"&&(r=Math.min(q.length-1,r+2));const a=q[r]||"101",i=Ye(a),s={default:x.emmaRoom.labelDefault,higher:x.emmaRoom.labelHigher,lower:x.emmaRoom.labelLower,extra_bed:x.emmaRoom.labelExtraBed};return{roomNumber:a,floor:i,kind:e,label:s[e]}}function Bt(){const t=document.getElementById(ne);t&&t.remove();const e=document.createElement("style");e.id=ne,e.textContent=`
    #${b}{
      box-sizing:border-box;
      flex:0 0 auto;
      order:-1;
      margin:0 10px 8px 0;
      width:min(220px,100%);
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:linear-gradient(180deg,#ffffff,#f8fafc);
      border:1px solid rgba(45,58,79,.14);
      border-radius:14px;
      box-shadow:0 6px 20px rgba(15,23,42,.1);
      padding:8px 10px;
      z-index:5;
      pointer-events:auto;
      align-self:flex-start;
    }
    #${b} *{box-sizing:border-box;}
    #${b} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:6px;
      margin-bottom:6px;
    }
    #${b} .pb-ra-title{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:6px;
    }
    #${b} .pb-ra-dot{
      width:7px;height:7px;border-radius:999px;background:#3b6fa0;
      box-shadow:0 0 0 3px rgba(59,111,160,.16);
    }
    #${b} .pb-ra-badge{
      font-size:9px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:2px 7px;white-space:nowrap;
    }
    #${b} .pb-ra-main{
      display:flex;align-items:center;gap:8px;
    }
    #${b} .pb-ra-room{
      flex:1;min-width:0;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:20px;font-weight:800;letter-spacing:.04em;line-height:1.1;
      color:#1a2332;
    }
    #${b} .pb-ra-meta{
      font-size:10px;color:#64748b;margin-top:2px;font-weight:500;
      font-family:var(--sapFontFamily,"72",system-ui,sans-serif);
      letter-spacing:0;
    }
    #${b} .pb-ra-actions{
      display:flex;align-items:center;gap:4px;flex-shrink:0;
    }
    #${b} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:30px;height:30px;border-radius:9px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
      transition:background .12s ease,border-color .12s ease,transform .12s ease;
    }
    #${b} .pb-ra-btn:hover{background:#f1f5f9;border-color:#94a3b8;}
    #${b} .pb-ra-btn:active{transform:scale(.96);}
    #${b} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${b} .pb-ra-btn.pb-ra-accept:hover{background:#166534;border-color:#166534;}
    #${b} .pb-ra-btn svg{width:15px;height:15px;display:block;}
    #${b} .pb-ra-menu{
      margin-top:8px;padding-top:8px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:4px;
    }
    #${b} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${b} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:8px;padding:6px 8px;text-align:left;font-size:11px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${b} .pb-ra-opt:hover{background:#f8fafc;border-color:#cbd5e1;}
    #${b} .pb-ra-status{
      margin-top:6px;font-size:10px;font-weight:600;color:#15803d;
    }
    #${b} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${b} .pb-ra-note{
      margin-top:4px;font-size:9px;color:#94a3b8;line-height:1.3;
    }
  `,document.documentElement.appendChild(e)}function Ct(t){let e=document.getElementById(b);return e&&t.contains(e)||(e==null||e.remove(),e=document.createElement("div"),e.id=b,e.setAttribute("data-prize-room-assign","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",x.emmaRoom.title),t.classList.contains("sapMFlexBox")||t.querySelector(":scope > .sapMFlexItem")?t.insertBefore(e,t.firstChild):t.prepend(e)),e}function St(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function It(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>'}let $=null,U=null,h=null,R=!1,H="",Z=!1;function At(t){const e=kt();if(!e)return!1;const n=e.value,o=Et(t,n);return e.focus(),e.value=o,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),e.blur(),!0}function Q(t){var a,i;if(!h)return;t.setAttribute("aria-label",x.emmaRoom.title);const e=Ze(h.floor),n=H?`<div class="pb-ra-status${Z?" pb-ra-warn":""}">${B(H)}</div>`:"",o=x.emmaRoom.accept,r=x.emmaRoom.edit;t.innerHTML=`<div class="pb-ra-top"><span class="pb-ra-title"><span class="pb-ra-dot" aria-hidden="true"></span>${B(x.emmaRoom.title)}</span><span class="pb-ra-badge">${B(h.label)}</span></div><div class="pb-ra-main"><div><div class="pb-ra-room">${B(h.roomNumber)}</div><div class="pb-ra-meta">${B(e)}</div></div><div class="pb-ra-actions"><button type="button" class="pb-ra-btn pb-ra-accept" title="${Y(o)}" aria-label="${Y(o)}">${St()}</button><button type="button" class="pb-ra-btn pb-ra-edit" title="${Y(r)}" aria-label="${Y(r)}" aria-expanded="${R}">${It()}</button></div></div><div class="pb-ra-menu${R?"":" pb-ra-hidden"}"><button type="button" class="pb-ra-opt" data-kind="higher">${B(x.emmaRoom.higher)}</button><button type="button" class="pb-ra-opt" data-kind="lower">${B(x.emmaRoom.lower)}</button><button type="button" class="pb-ra-opt" data-kind="extra_bed">${B(x.emmaRoom.extraBed)}</button></div>`+n+`<div class="pb-ra-note">${B(x.emmaRoom.previewNote)}</div>`,(a=t.querySelector(".pb-ra-accept"))==null||a.addEventListener("click",()=>{if(!h)return;const s=At(h.roomNumber);H=s?L(x.emmaRoom.applied,{room:h.roomNumber}):L(x.emmaRoom.appliedNoField,{room:h.roomNumber}),Z=!s,R=!1,Q(t)}),(i=t.querySelector(".pb-ra-edit"))==null||i.addEventListener("click",()=>{R=!R,Q(t)}),t.querySelectorAll(".pb-ra-opt").forEach(s=>{s.addEventListener("click",()=>{const l=s.dataset.kind||"default",u=Me(),g=pe();h=Le(u,l,(h==null?void 0:h.roomNumber)||g),H="",Z=!1,R=!1,Q(t)})})}function B(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Y(t){return B(t).replace(/'/g,"&#39;")}function _(){U&&window.clearTimeout(U),U=window.setTimeout(()=>{ze()},350)}async function ze(){var r,a;if(!wt()){(r=document.getElementById(b))==null||r.remove(),$=null;return}const t=Re(),e=Me();if(!t||!e){(a=document.getElementById(b))==null||a.remove(),$=null,h=null;return}Bt();const n=Ct(t);if(!t.contains(n)){$=null,_();return}const o=`${e}:${pe()||""}`;if(o!==$||!h||!n.querySelector(".pb-ra-room")){const i=!$||!$.startsWith(`${e}:`);$=o,(i||!h)&&(R=!1,H="",Z=!1,h=Le(e,"default",pe())),Q(n)}}function Mt(){oe().then(e=>{x=w(e),$=null,_()}),re(e=>{x=w(e),$=null,_()}),ze(),window.addEventListener("hashchange",()=>{$=null,h=null,_()});const t=new MutationObserver(e=>{let n=!1;for(const a of e){const i=a.target;if(!(i instanceof Element&&(i.id===b||i.id===ne||i.closest("[data-prize-room-assign]")))){n=!0;break}}if(!n)return;const o=Re(),r=document.getElementById(b);r&&o&&!o.contains(r)&&($=null),o&&!r&&($=null),_()});return t.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var e,n;t.disconnect(),U&&window.clearTimeout(U),(e=document.getElementById(b))==null||e.remove(),(n=document.getElementById(ne))==null||n.remove()}}const Ee="prize-panel-host";let I=w("de");function Pe(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function J(t,e,n){const o=`${ee}px 0 0 ${ee}px`;n?(t.style.width="0",t.style.opacity="0",t.style.pointerEvents="none",e.style.display="flex",e.innerHTML=Pe(),e.title=I.inject.openPanel,e.setAttribute("aria-label",I.inject.openPanel),e.setAttribute("aria-expanded","false")):(t.style.width=`${Ce}px`,t.style.opacity="1",t.style.pointerEvents="auto",e.style.display="none",e.title=I.inject.panelTitle,e.setAttribute("aria-expanded","true")),t.style.borderRadius=o,e.style.borderRadius=o}async function Te(t,e,n){var i;const r=!await ue(A.panelCollapsed);await Oe({[A.panelCollapsed]:r}),J(t,e,r);const a=t.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?D.collapsed:D.expanded},"*")}function Be(){if(document.getElementById(Ee))return;let t=!1,e=!0;const n=()=>t&&!e,o=`${ee}px 0 0 ${ee}px`,r=document.createElement("div");r.id=Ee,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${Ne}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:X,border:`1px solid ${ce}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=I.inject.panelTitle,Object.assign(i.style,{width:`${Ce}px`,height:"100%",border:"none",display:"block",background:X}),a.appendChild(i);const s=document.createElement("button");s.id="prize-panel-tab",s.type="button",Object.assign(s.style,{width:`${xe}px`,height:`${De}px`,minWidth:`${xe}px`,border:`1px solid ${ce}`,borderRight:"none",background:`linear-gradient(180deg, ${X} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),s.innerHTML=Pe(),s.addEventListener("mouseenter",()=>{s.style.filter="brightness(1.12)"}),s.addEventListener("mouseleave",()=>{s.style.filter=""}),s.addEventListener("click",()=>{Te(a,s)}),r.appendChild(a),r.appendChild(s),document.documentElement.appendChild(r),ue(A.panelCollapsed).then(l=>{e=l,J(a,s,l)}),window.addEventListener("message",l=>{var u,g,f,v;((u=l.data)==null?void 0:u.type)===D.toggle&&Te(a,s),((g=l.data)==null?void 0:g.type)===D.chatOpen&&(t=!0,n()&&((f=document.getElementById("prize-panel-chat-toast"))==null||f.remove())),((v=l.data)==null?void 0:v.type)===D.chatClosed&&(t=!1)}),chrome.storage.onChanged.addListener((l,u)=>{u==="local"&&l[A.panelCollapsed]&&(e=!!l[A.panelCollapsed].newValue)}),st(n),$t(),Mt(),oe().then(l=>{I=w(l),J(a,s,e),i.title=I.inject.panelTitle}),re(l=>{I=w(l),J(a,s,e),i.title=I.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Be):Be();
