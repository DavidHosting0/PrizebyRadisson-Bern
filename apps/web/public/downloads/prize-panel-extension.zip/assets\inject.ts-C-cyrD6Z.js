import{b as Ke,S as G,P as te,c as Ce,d as Oe,A as Zt,e as Be,f as Jt,g as Ct,T as at,h as Qt,s as en}from"./storage-DTWcLCTt.js";import{l as ye,w as ve,i as ne,g as I,a as Tt,b as tn,p as nn,c as kt,d as on,t as it,B as rn,e as an,f as sn,h as we}from"./bernticket-api-pqOIfREo.js";const st=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function ln(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function St(e){if(ln(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=st.length;n++){const[o,r]=st[n-1];if(t>=o&&t<=r)return n}return null}function cn(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let ue=I("de");const _="prize-panel-chat-toast",lt="prize-panel-chat-toast-style",dn=8e3,un=7e3;function mn(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function pn(e){return e==="/r"||e.startsWith("/r/")}function fn(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function bn(){if(document.getElementById(lt))return;const e=document.createElement("style");e.id=lt,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${_}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${Ce} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${Oe};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${_}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${_} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${_} .pb-ct-body{min-width:0;flex:1;}
    #${_} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${Zt};margin-bottom:2px;
    }
    #${_} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${_} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${_} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${_} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let Te=null;function Z(e=!0){const t=document.getElementById(_);if(t){if(Te&&(window.clearTimeout(Te),Te=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function gn(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,i,s)=>{const l=t.createOscillator(),c=t.createGain();l.type="sine",l.frequency.setValueAtTime(a,i),c.gain.setValueAtTime(1e-4,i),c.gain.exponentialRampToValueAtTime(.9,i+.015),c.gain.exponentialRampToValueAtTime(1e-4,i+s),l.connect(c),c.connect(o),l.start(i),l.stop(i+s+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function hn(e,t){bn(),Z(!1);const n=document.createElement("div");n.id=_,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),s=r.querySelector(".pb-ct-preview");a.textContent=ue.toast.eyebrow,i.textContent=ne(ue.toast.newMessageFrom,{author:e}),s.textContent=fn(t);const l=document.createElement("button");l.type="button",l.className="pb-ct-close",l.setAttribute("aria-label",ue.toast.close),l.textContent="×",l.addEventListener("click",c=>{c.stopPropagation(),Z(!0)}),n.addEventListener("click",()=>Z(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(l),document.documentElement.appendChild(n),gn(),Te=window.setTimeout(()=>{Z(!0)},un)}function yn(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:te.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function vn(e){let t=!1,n=null,o=!0;ye().then(s=>{ue=I(s)});const r=ve(s=>{ue=I(s)});Ke(G.chatNotificationsEnabled,!0).then(s=>{o=s});try{chrome.storage.onChanged.addListener((s,l)=>{if(l==="local"&&s[G.chatNotificationsEnabled]){const c=s[G.chatNotificationsEnabled].newValue;o=c===void 0?!0:!!c,o||Z(!1)}})}catch{}const a=async()=>{var s,l,c;if(!t)try{if(!o)return;const d=await yn();if(!d.ok)return;const f=d.msg;if(!(f!=null&&f.id))return;if(n===null){n=f.id;return}if(f.id===n||(n=f.id,(s=f.author)!=null&&s.id&&d.meId&&f.author.id===d.meId)||e()||mn(window.location.pathname)||pn(window.location.pathname))return;const w=((c=(l=f.author)==null?void 0:l.name)==null?void 0:c.trim())||"Team";hn(w,f.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},dn);return()=>{t=!0,window.clearInterval(i),r(),Z(!1)}}const Et=300*1e3,Y=new Map,ke=new Map;function oe(e){return e.replace(/^0+/,"")||e}function Ue(e){const t=Y.get(oe(e));return!t||Date.now()-t.at>=Et?null:{code:t.code}}function wn(e,t){Y.set(oe(e),{code:t,at:Date.now()})}function Ze(){Y.clear(),ke.clear()}async function Bt(e){const t=oe(e),n=Y.get(t);if(n&&Date.now()-n.at<Et)return n.code;let o=ke.get(t);return o||(o=(async()=>{try{const r=await Tt();if(!(r!=null&&r.access))return Y.set(t,{code:null,at:Date.now()}),null;const a=await tn(t),i=nn(a,t),s=kt(i);return Y.set(t,{code:s,at:Date.now()}),s}catch{return Y.set(t,{code:null,at:Date.now()}),null}finally{ke.delete(t)}})(),ke.set(t,o)),o}async function xn(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}const $n={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function X(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=$n[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const i=new Date(a),s=i.getFullYear(),l=String(i.getMonth()+1).padStart(2,"0"),c=String(i.getDate()).padStart(2,"0");if(s>=2e3)return`${s}-${l}-${c}`}return null}function It(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Cn(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Lt(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:X(e);return!!(t&&t===It())}let g=I("de");const h="prize-bt-checkin-host",Ie="prize-bt-checkin-style",$="prize-bt-fallback-bar",x="prize-bt-create-dialog";function Tn(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function At(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function Le(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function kn(){const e=Le();if(e)return e;if(At())return null;for(const o of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r.replace(/^0+/,"")||r}const t=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),n=((t==null?void 0:t.textContent)||"").match(/\b(\d{6,})\b/);return n?n[1].replace(/^0+/,"")||n[1]:null}function Sn(){return!!document.querySelector(['.sapUiLocalBusyIndicator:not([style*="display: none"])',".sapUiBusy",".sapMBusyDialog",".sapUiBlockLayer",".sapUiBLy",".sapUiLocalBusyIndicatorAnimation",'[class*="BusyIndicator"]:not([style*="display: none"])'].join(", "))}function ct(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function Je(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function J(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const d=(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement?l.value:l.textContent||"").trim();if(d&&!t.test(d))return d}a=a.parentElement}}return null}function En(){const e=Je()||document.body,t=J(e,/^Arrival\s*Date$/i)||J(e,/^Anreise(datum)?$/i),n=J(e,/^Departure\s*Date$/i)||J(e,/^Abreise(datum)?$/i),o=t&&X(t)||It(),r=n&&X(n)||Cn();return{from:o,to:r}}function Bn(){const e=Je()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=J(t,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function In(){const e=Je()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=J(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function Ln(e){const t=En();return{guestName:In(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:Bn()}}function An(){const e=document.getElementById(Ie);e&&e.remove();const t=document.createElement("style");t.id=Ie,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${h}),
    .sapMTBSpacerFlex:has(#${h}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${h}.sapMBarChild,
    #${h}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${h} *{box-sizing:border-box;}
    #${h} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${h} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:1.35rem;font-weight:700;
      letter-spacing:.05em;line-height:1.15;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.3rem;
      padding:0.45rem 0.85rem;
      min-width:0;text-align:center;
    }
    #${h} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${h} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${h} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${h} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${h} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${h} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${$}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.45rem;
      padding:0.35rem 0.6rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.3rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${$} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${$} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${$} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.05em;
      font-size:1.25rem;line-height:1.15;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.3rem;padding:0.35rem 0.7rem;
    }
    #${$} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${$} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${x}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${x} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${x} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${x} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${x} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${x} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${x} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${x} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${x} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${x} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${x} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${x} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${x} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${x} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${x} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${x} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function Q(){var e;(e=document.getElementById(x))==null||e.remove()}function dt(e){var o,r;(o=document.getElementById($))==null||o.remove();let t=document.getElementById(h);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=h,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",g.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function Mn(){var t;(t=document.getElementById(h))==null||t.remove();let e=document.getElementById($);return e||(e=document.createElement("div"),e.id=$,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",g.emmaBt.brand),document.documentElement.appendChild(e),e)}function ie(e,t){e.innerHTML=t}function se(e){return`<span class="pb-bt-label">${S(g.emmaBt.brand)}</span>${e}`}async function Rn(e){try{await navigator.clipboard.writeText(e)}catch{}}function qn(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{Rn(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=g.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function _n(e,t,n,o){Q();const r=document.createElement("div");r.id=x,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${W(g.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${S(g.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${W(g.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${S(g.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${W(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${S(g.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${W(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${S(g.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${W(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${S(g.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${W(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${S(g.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${S(g.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${S(g.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(l=>{l.addEventListener("click",()=>Q())});const s=l=>{l.key==="Escape"&&(Q(),window.removeEventListener("keydown",s))};window.addEventListener("keydown",s),i.addEventListener("click",()=>{(async()=>{const l=r.querySelector(".pb-bt-dlg-name"),c=r.querySelector(".pb-bt-dlg-from"),d=r.querySelector(".pb-bt-dlg-to"),f=r.querySelector(".pb-bt-dlg-amt"),w=(l==null?void 0:l.value.trim())||"";if(!w){a.hidden=!1,a.textContent=g.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=g.common.ellipsis,a.hidden=!0;try{const R=await on({guestName:w,bookingNumber:t,validFrom:it((c==null?void 0:c.value)||n.from),validTo:it((d==null?void 0:d.value)||n.to),ticketsAmount:Math.max(1,parseInt((f==null?void 0:f.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});Q(),o(kt(R))}catch(R){if(R instanceof rn&&R.code===an){const E=window.prompt(g.emmaBt.twoFaPrompt);if(E)try{await sn(E),i.disabled=!1,i.textContent=g.emmaBt.create,i.click();return}catch(P){a.hidden=!1,a.textContent=P instanceof Error?P.message:g.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=g.emmaBt.create;return}}a.hidden=!1,a.textContent=R instanceof Error?R.message:g.emmaBt.error,i.disabled=!1,i.textContent=g.emmaBt.create}})()})}let A=null,K=null,me=null,$e=0;async function Ae(e,t,n){var l,c;const o=++$e,r=await Tt();if(o!==$e)return;if(!r.access){ie(e,se(`<span class="pb-bt-muted">${S(g.emmaBt.loginHint)}</span>`)),e.dataset.fetched="1";return}const a=g.bernticket.copyCode,i=d=>{ie(e,se(`<button type="button" class="pb-bt-code" title="${W(a)}">${S(d)}</button>`)),qn(e,d),e.dataset.fetched="1"},s=Ue(t);if(s!=null&&s.code){i(s.code);return}if(!(e.dataset.bound===t&&e.dataset.fetched==="1"&&e.querySelector(".pb-bt-code, .pb-bt-open-create, .pb-bt-muted"))){ie(e,se(`<span class="pb-bt-muted">${S(g.emmaBt.loading)}</span>`));try{const d=await Bt(t);if(o!==$e)return;if(d){i(d);return}const f=Ln(t);ie(e,se(`<button type="button" class="pb-bt-btn pb-bt-open-create">${S(g.emmaBt.openCreate)}</button>`)),e.dataset.fetched="1",(l=e.querySelector(".pb-bt-open-create"))==null||l.addEventListener("click",()=>{_n(e,t,f,w=>{w?(wn(t,w),i(w)):(e.dataset.fetched="",A=null,Ae(e,t,!0))})})}catch(d){if(o!==$e)return;ie(e,se(`<span class="pb-bt-muted">${S(d instanceof Error?d.message:g.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${S(g.emmaBt.retry)}</button>`)),e.dataset.fetched="1",(c=e.querySelector(".pb-bt-retry"))==null||c.addEventListener("click",()=>{Ze(),e.dataset.fetched="",A=null,Ae(e,t)})}}}function S(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function W(e){return S(e).replace(/'/g,"&#39;")}function le(){me&&window.clearTimeout(me),me=window.setTimeout(()=>{Mt()},700)}function Dn(e){return document.documentElement.contains(e)}async function Mt(){var a,i,s,l,c,d;if(!Tn()){(a=document.getElementById(h))==null||a.remove(),(i=document.getElementById($))==null||i.remove(),Q(),A=null,K=null;return}An();const e=Sn();let t=kn();if(t?K=t:e&&K?t=K:!e&&!Le()&&(K=null),!e&&At()&&!Le()){(s=document.getElementById(h))==null||s.remove(),(l=document.getElementById($))==null||l.remove(),A=null;return}if(!t){(c=document.getElementById(h))==null||c.remove(),(d=document.getElementById($))==null||d.remove(),A=null;return}const n=document.getElementById(h)||document.getElementById($);if(t===A&&n&&Dn(n)&&n.dataset.bound===t&&n.dataset.fetched==="1"){const f=e?null:ct();if(f&&n.id===$&&!e){const w=dt(f);w!==n&&(w.dataset.bound=t,w.dataset.fetched="",n.remove(),A=t,await Ae(w,t))}return}const o=e?null:ct(),r=o?dt(o):Mn();A=t,r.dataset.bound=t,await Ae(r,t)}function zn(){ye().then(t=>{g=I(t),A=null,le()}),ve(t=>{g=I(t),A=null,le()}),Mt(),window.addEventListener("hashchange",()=>{A=null,Le()||(K=null);const t=document.getElementById(h)||document.getElementById($);t instanceof HTMLElement&&(t.dataset.fetched=""),le()});const e=new MutationObserver(t=>{let n=!1;for(const o of t){const r=o.target;if(r instanceof Element&&!(r.id===h||r.id===$||r.id===Ie||r.id===x||r.closest("[data-prize-bernticket]")||r.closest(`#${h}, #${$}, #${x}`))&&!(o.type==="childList"&&[...o.addedNodes,...o.removedNodes].length>0&&[...o.addedNodes,...o.removedNodes].every(a=>a instanceof Element&&(a.id===h||a.id===$||a.id===x||a.closest(`[data-prize-bernticket], #${h}, #${$}`))))){n=!0;break}}n&&le()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{if(n==="local"&&(t.btAccessToken||t.btRefreshToken)){A=null,Ze();const o=document.getElementById(h)||document.getElementById($);o instanceof HTMLElement&&(o.dataset.fetched=""),le()}})}catch{}return()=>{var t,n,o;e.disconnect(),me&&window.clearTimeout(me),(t=document.getElementById(h))==null||t.remove(),(n=document.getElementById($))==null||n.remove(),(o=document.getElementById(Ie))==null||o.remove(),Q()}}let D=I("de");const Me="prize-bt-list-style",m="data-prize-bt-chip";let pe=null;function Hn(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Fn(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Nn(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function Pn(){let e=document.getElementById(Me);e||(e=document.createElement("style"),e.id=Me,document.documentElement.appendChild(e)),e.dataset.v!=="7"&&(e.dataset.v="7",e.textContent=`
    [${m}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: BELOW reservation number — do not sit in the number hbox */
    [${m}][data-surface="list"]{
      display:block !important;
      margin:0.15rem 0 0 0 !important;
      max-width:100%;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${m}]),
    .sapUiTableDataCell:has([${m}]),
    .sapMVBox:has([${m}]),
    .sapMHBox:has([${m}]){
      overflow:visible !important;
    }
    .sapUiTableCellInner:has([${m}[data-surface="list"]]){
      max-height:none !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${m}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    /* Room Status detail panel (click a room): large code */
    [${m}][data-surface="room-detail"]{
      display:flex !important;
      flex-direction:column;
      align-items:flex-start;
      gap:0.4rem;
      margin:0.65rem 0.75rem 0.35rem !important;
      padding:0.7rem 0.9rem;
      background:linear-gradient(180deg,#fff 0%,#fff8f8 100%);
      border:1px solid rgba(170,8,8,.28);
      border-radius:0.5rem;
      box-shadow:0 2px 10px rgba(15,23,42,.08);
      position:relative !important;
      left:auto !important;
      bottom:auto !important;
      max-width:min(100%, 20rem);
      z-index:10;
    }
    [${m}][data-surface="room-detail"] .pb-bt-detail-label{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.68rem;
      font-weight:700;
      letter-spacing:.07em;
      text-transform:uppercase;
      color:#6a6d70;
    }
    [${m}][data-surface="room-detail"] .pb-bt-list-code{
      font-size:1.55rem !important;
      font-weight:800;
      letter-spacing:.08em;
      padding:0.4rem 0.85rem;
      border-radius:0.35rem;
      line-height:1.15;
    }
    [${m}][data-surface="room-detail"] .pb-bt-list-muted{
      font-size:0.85rem;
    }
    [${m}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${m}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${m}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${m}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function Rt(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${m}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return oe(n)}return null}function On(e){return Rt(e)}function Un(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return Rt(t)}function jn(e,t){let n=e.querySelector(`:scope > [${m}]`);if(!n){const o=e.querySelector(`[${m}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(m,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function Gn(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function Vn(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function Wn(e,t){let n=null;for(const i of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!i.closest(`[${m}]`)&&/^\d{6,}$/.test((i.textContent||"").trim())){n=i;break}const o=(n==null?void 0:n.closest(".sapMVBox"))||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,r=(n==null?void 0:n.closest(".sapMHBox"))||o.querySelector(":scope > .sapMHBox");let a=e.querySelector(`[${m}]`);return a?(a.dataset.booking!==t&&(a.dataset.booking=t,a.dataset.state="",a.innerHTML=""),a.dataset.surface="list",a.parentElement!==o?r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a):r&&a.previousElementSibling!==r&&r.insertAdjacentElement("afterend",a),a):(a=document.createElement("div"),a.setAttribute(m,"1"),a.dataset.booking=t,a.dataset.surface="list",r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a),a)}function Yn(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function Xn(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),xn(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",D.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||D.emmaBt.clickToCopy)},1200)})})}function Kn(e,t){if(e.setAttribute(m,"1"),e.dataset.booking=t,e.dataset.state="loading",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${je(D.emmaBt.brand)}</div><span class="pb-bt-list-muted">${je(D.emmaBt.loading)}</span>`;return}e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function ut(e,t,n){if(e.setAttribute(m,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="",e.dataset.surface==="room-detail"){const r=document.createElement("div");r.className="pb-bt-detail-label",r.textContent=D.emmaBt.brand,e.appendChild(r)}const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=D.emmaBt.clickToCopy,o.setAttribute("aria-label",`${D.emmaBt.brand}: ${n}`),Xn(o,n),e.appendChild(o)}function mt(e,t){if(e.setAttribute(m,"1"),e.dataset.booking=t,e.dataset.state="none",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${je(D.emmaBt.brand)}</div><span class="pb-bt-list-muted">—</span>`;return}e.innerHTML=""}function je(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function Qe(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=Ue(t);if(r&&r.code===null)return;e.dataset.state=""}const n=Ue(t);if(n){n.code?ut(e,t,n.code):mt(e,t);return}Kn(e,t);const o=await Bt(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?ut(e,t,o):mt(e,t))}function Zn(){const e=Fn();if(!e){Yn()||document.querySelectorAll(`[${m}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=Vn(r);if(!a)continue;const i=On(a),s=a.querySelector(`[${m}]`);if(!i){(s==null?void 0:s.dataset.state)==="ok"&&n.add(s);continue}const l=Wn(a,i);n.add(l),Qe(l,i)}document.querySelectorAll(`[${m}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function Jn(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function Qn(){const e=Nn(),t=new Set(e);if(e.length===0){Jn()||document.querySelectorAll(`[${m}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=Un(o),a=o.querySelector(`[${m}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&Gn(o)){n.add(a);continue}a==null||a.remove();continue}const i=jn(o,r);n.add(i),Qe(i,r)}document.querySelectorAll(`[${m}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function eo(){const e=document.querySelectorAll('.sapMPageEnableScrolling, section.sapMPageEnableScrolling, [id$="-cont"].sapUiScrollDelegate');for(const t of e){if(t.querySelector(".sapMGT.roomTiles, .sapMGT.roomTiles2"))continue;const n=t.querySelector('.sapMTitle, .sapMTitle-inner, [class*="sapMTitle"]'),o=((n==null?void 0:n.textContent)||"").replace(/\s+/g," ").trim();if((/^room\s+\d+/i.test(o)||/^zimmer\s+\d+/i.test(o)||[...t.querySelectorAll("bdi, .sapMBtnContent")].some(a=>/check\s*out|change\s*room\s*status/i.test((a.textContent||"").trim())))&&qt(t))return t}return null}function qt(e){var t;for(const n of e.querySelectorAll(".sapMLabel, .sapMLabel bdi")){const o=(n.textContent||"").replace(/\s+/g," ").trim().replace(/:$/,"");if(!/^(reservation|reservierung)$/i.test(o))continue;const r=((t=n.closest('[class*="wrapperfor"]'))==null?void 0:t.parentElement)||n.closest(".sapUiFormResGridCont")||n.closest(".sapUiRespGrid")||e;for(const a of r.querySelectorAll("a.sapMLnk")){const i=(a.textContent||"").trim();if(/^\d{6,}$/.test(i))return oe(i)}}for(const n of e.querySelectorAll("a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return oe(o)}return null}function to(e,t){let n=e.querySelector(`[${m}][data-surface="room-detail"]`);if(n)return n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n;n=document.createElement("div"),n.setAttribute(m,"1"),n.dataset.booking=t,n.dataset.surface="room-detail",n.setAttribute("role","region"),n.setAttribute("aria-label",D.emmaBt.brand);const o=e.querySelector(":scope > .sapMHBox"),r=e.querySelector('.sapUiForm, [role="form"]');return(o==null?void 0:o.parentElement)===e?o.insertAdjacentElement("afterend",n):r?r.insertAdjacentElement("beforebegin",n):e.insertBefore(n,e.firstChild),n}function no(){const e=eo();if(!e){document.querySelectorAll(`[${m}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const t=qt(e);if(!t){document.querySelectorAll(`[${m}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const n=to(e,t);Qe(n,t)}function _t(){if(!Hn()){document.querySelectorAll(`[${m}]`).forEach(e=>e.remove());return}Pn(),Zn(),Qn(),no()}function ce(){pe&&window.clearTimeout(pe),pe=window.setTimeout(()=>{_t()},280)}function oo(){ye().then(t=>{D=I(t),ce()}),ve(t=>{D=I(t),document.querySelectorAll(`[${m}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),ce()}),_t(),window.addEventListener("hashchange",()=>ce());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===Me||o.closest(`[${m}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${m}]`)||r.closest(`[${m}]`))))){ce();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(Ze(),document.querySelectorAll(`[${m}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),ce())})}catch{}return()=>{var t;e.disconnect(),pe&&window.clearTimeout(pe),(t=document.getElementById(Me))==null||t.remove(),document.querySelectorAll(`[${m}]`).forEach(n=>n.remove())}}const pt="CHBRNPR",Ge="100",Dt="ZEYUI_RSRVS_SRV";function ro(e){const t=parseInt(e,10);return Number.isFinite(t)?String(t).padStart(4,"0"):e.trim()}function ao(e,t,n=new Date){const o=(a,i)=>String(a).padStart(i,"0"),r=[o(n.getFullYear(),4),o(n.getMonth()+1,2),o(n.getDate(),2),o(n.getHours(),2),o(n.getMinutes(),2),o(n.getSeconds(),2)].join("");return`${e}   ${t}${r}000`}function io(e,t,n){const o=Math.random().toString(16).slice(2,14).padEnd(12,"0"),r=`batch_${o.slice(0,4)}-${o.slice(4,8)}-${o.slice(8,12)}`,a=`changeset_${o.slice(2,6)}-${o.slice(6,10)}-${o.slice(0,4)}`,i=`id-${Date.now()}-1000`;let s=`\r
`;return s+=`--${r}\r
`,s+=`Content-Type: multipart/mixed; boundary=${a}\r
\r
`,s+=`--${a}\r
`,s+=`Content-Type: application/http\r
`,s+=`Content-Transfer-Encoding: binary\r
\r
`,s+=`POST ${e} HTTP/1.1\r
`,s+=`tms-fioriapp: CheckIn\r
`,s+=`Request-Object-Key: ${n}\r
`,s+=`Request-Object-Type: RSRV\r
`,s+=`sap-contextid-accept: header\r
`,s+=`Accept: application/json\r
`,s+=`x-csrf-token: ${t}\r
`,s+=`Accept-Language: en\r
`,s+=`DataServiceVersion: 2.0\r
`,s+=`MaxDataServiceVersion: 2.0\r
`,s+=`X-Requested-With: XMLHttpRequest\r
`,s+=`Content-Type: application/json\r
`,s+=`Content-ID: ${i}\r
\r
`,s+=`\r
`,s+=`--${a}--\r
\r
`,s+=`--${r}--\r
`,{body:s,contentType:`multipart/mixed;boundary=${r}`}}async function so(){const e=await fetch(`${location.origin}/sap/opu/odata/sap/${Dt}/?sap-client=${Ge}`,{credentials:"include",headers:{"x-csrf-token":"Fetch",Accept:"application/json","X-Requested-With":"XMLHttpRequest"}}),t=e.headers.get("x-csrf-token");if(!e.ok||!t||t.toLowerCase()==="required")throw new Error("CSRF");return t}function lo(e){const t=e.match(/HTTP\/1\.[01] ([45]\d\d)[^\n]*\n([\s\S]*?)(?:\n--|\s*$)/);if(!t)return null;const o=(t[2]??"").match(/"message"\s*:\s*\{[^}]*"value"\s*:\s*"([^"]+)"/);return(o==null?void 0:o[1])||`EMMA ${t[1]}`}async function co(e,t){const n=await so(),o=ro(t),r=`RoomAssignment?sap-client=${Ge}&HotelId='${pt}'&ReservationId='${e}'&RoomId='${o}'`,a=io(r,n,ao(pt,e)),i=await fetch(`${location.origin}/sap/opu/odata/sap/${Dt}/$batch?sap-client=${Ge}`,{method:"POST",credentials:"include",headers:{"Content-Type":a.contentType,"x-csrf-token":n,Accept:"multipart/mixed","X-Requested-With":"XMLHttpRequest",DataServiceVersion:"2.0",MaxDataServiceVersion:"2.0"},body:a.body}),s=await i.text(),l=lo(s);if(!i.ok||l)throw new Error(l||`EMMA ${i.status}`)}let u=I("de");const p="prize-ra-host",fe="prize-ra-style",z="prize-ra-assign-all",N="prize-ra-assign-count",b="data-prize-room-assign";function uo(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Ve(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${b}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o}return null}function zt(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function re(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function mo(e){const t=re(e);return St(t)!=null}function po(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=re(r);if(a)return a}}return null}function Re(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&zt(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Ht(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&zt(o))return o}const t=Re();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function fo(){const e=Ht();return e?e.closest(".sapUiRFLContainer")||e.closest(".sapUiFormCLContainer")||e.closest(".sapUiFormElementFields")||e.closest(".sapMFlexItem")||e.parentElement:null}function ze(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const s=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const l of s)if(o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING){const d=(l instanceof HTMLInputElement?l.value:l.textContent||"").trim();if(d&&!t.test(d))return d}a=a.parentElement}}return null}function bo(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=ze(n,/^Arrival\s*Date$/i)||ze(n,/^Arrival$/i)||ze(n,/^Anreise(datum)?$/i);if(!o)continue;const r=X(o);if(r)return r}return null}function go(){if(po())return!1;const e=bo();return e?Lt(e):!0}function Ft(e,t){const n=re(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}const ho=2e4;let T=null,de=null,He=0,We=!1;const Fe=new Set;let v=null,U=!1,B=!1;function Nt(e){const t={vip:u.emmaRoom.reasonVip,premium:u.emmaRoom.reasonPremium,repeat:u.emmaRoom.reasonRepeat,one_night:u.emmaRoom.reasonOneNight,long_stay:u.emmaRoom.reasonLongStay,three_pax:u.emmaRoom.reasonThreePax,no_basement:u.emmaRoom.reasonNoBasement,not_ready:u.emmaRoom.reasonNotReady,category_not_ready:u.emmaRoom.reasonCategoryNotReady,overbook_view:u.emmaRoom.reasonOverbookView,overbook_corner:u.emmaRoom.reasonOverbookCorner,overbook_standard:u.emmaRoom.reasonOverbookStandard,wheelchair:u.emmaRoom.reasonWheelchair};return e.map(n=>t[n]).filter(n=>!!n).slice(0,3).join(" · ")}function xe(e,t){const n=o=>o.replace(/^0+/,"")||o;return e===t||n(e)===n(t)}function qe(e){const t=e instanceof Error?e.message:String(e??"");return/401|unauthorized|invalid token|jwt/i.test(t)?u.emmaRoom.signInRequired:u.emmaRoom.loadFailed}async function et(){const e=T!=null&&T.error?5e3:ho;return T&&Date.now()-T.at<e?T:de||(de=(async()=>{let t;try{const n=await we("/reservations/room-suggestions");t={at:Date.now(),items:n.items??[],error:null}}catch(n){t={at:Date.now(),items:[],error:qe(n)}}return T=t,t})().finally(()=>{de=null}),de)}function tt(e){return e.replace(/^0+/,"")||e}async function yo(e){const t=Date.now(),n=[...new Set(e.map(tt))].filter(o=>t-(Se.get(o)??0)>15e3);if(!n.length)return!1;for(const o of n)Se.set(o,t);try{const o=await we("/reservations/room-suggestions/unassigned",{method:"POST",body:JSON.stringify({reservationIds:n})});return T={at:Date.now(),items:o.items??[],error:null},!0}catch{for(const o of n)Se.delete(o);return!1}}function vo(e,t){var n;return((n=e.find(o=>xe(o.reservationId,t)))==null?void 0:n.suggestion)??null}function nt(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!t.closest(`[${b}]`))return t;return null}function Pt(e,t){const n=nt(e);if(n){n.nextElementSibling!==t&&n.insertAdjacentElement("afterend",t);return}const o=e.querySelector(".sapUiTableCellInner")||e;t.parentElement!==o&&o.appendChild(t)}function ft(e,t,n){const o=nt(e);let r=e.querySelector(`[${b}="row"]`);const a=o?o.nextElementSibling===r:(r==null?void 0:r.parentElement)===(e.querySelector(".sapUiTableCellInner")||e);if(r&&a&&r.dataset.note===t&&r.dataset.error===(n?"1":"0"))return r;r||(r=document.createElement("div"),r.setAttribute(b,"row")),Pt(e,r),r.dataset.error=n?"1":"0",r.dataset.booking="",r.dataset.room="",r.dataset.note=t,r.innerHTML="";const i=document.createElement("span");return i.className=`pb-ra-row-note${n?" is-error":""}`,i.textContent=t,i.title=t,r.appendChild(i),r}async function Ot(e){return T=null,await we(`/reservations/${encodeURIComponent(e.reservationId)}/room-suggestion/accept`,{method:"POST",body:JSON.stringify({roomNumber:e.roomNumber})}),T=null,e.roomNumber}async function Ut(e){return await co(e.reservationId,e.roomNumber),Ot(e)}async function wo(e){var o,r;const t=Ft(e.roomNumber,(o=Re())==null?void 0:o.value);if(await So(t),re(((r=Re())==null?void 0:r.value)??"")!==re(t))throw new Error("room field");return Ot(e)}async function xo(e){T=null;const t=await we(`/reservations/${encodeURIComponent(e)}/room-suggestion/arriving-now`,{method:"POST"});return T=null,t.suggestion}async function $o(e,t){T=null;const n=await we(`/reservations/${encodeURIComponent(e)}/room-suggestion/shift`,{method:"POST",body:JSON.stringify({direction:t})});return T=null,n.suggestion}function Co(){let e=document.getElementById(fe);e||(e=document.createElement("style"),e.id=fe,document.documentElement.appendChild(e)),e.dataset.v!=="12"&&(e.dataset.v="12",e.textContent=`
    /* Detail: one SAP-like line under the Room field, in the document flow */
    #${p}{
      box-sizing:border-box;
      position:static;
      display:flex;
      flex-flow:row wrap;
      align-items:center;
      gap:0.25rem 0.5rem;
      flex:1 0 100%;
      width:100%;
      max-width:100%;
      margin:0.25rem 0 0 0;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;
      line-height:1.25;
      color:var(--sapTextColor,#1d2d3e);
      background:transparent;
      border:0;
      box-shadow:none;
      padding:0;
      z-index:auto;
      pointer-events:auto;
    }
    #${p} *{box-sizing:border-box;}
    #${p} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${p} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${p} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${p} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${p} .pb-ra-main{
      display:inline-flex;align-items:center;gap:0.35rem;flex-wrap:wrap;
      background:transparent;border:0;box-shadow:none;padding:0;
    }
    #${p} .pb-ra-room{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;font-weight:700;letter-spacing:0;line-height:1.2;
      color:var(--sapTextColor,#1d2d3e);
    }
    #${p} .pb-ra-meta{
      font-size:0.75rem;color:var(--sapContent_LabelColor,#556b82);margin:0;font-weight:400;
    }
    #${p} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${p} .pb-ra-btn{
      appearance:none;cursor:pointer;
      border:1px solid var(--sapButton_BorderColor,#bcc3ca);
      background:var(--sapButton_Background,#fff);
      width:1.5rem;height:1.5rem;border-radius:0.25rem;display:inline-flex;
      align-items:center;justify-content:center;color:var(--sapButton_TextColor,#1d2d3e);padding:0;
    }
    #${p} .pb-ra-btn:hover{background:var(--sapButton_Hover_Background,#f5f6f7);}
    #${p} .pb-ra-btn.pb-ra-accept{
      background:var(--sapButton_Emphasized_Background,#0070f2);
      border-color:var(--sapButton_Emphasized_BorderColor,#0070f2);
      color:var(--sapButton_Emphasized_TextColor,#fff);
    }
    #${p} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${p} .pb-ra-nudge{display:flex;flex-direction:column;gap:2px;}
    #${p} .pb-ra-nudge .pb-ra-btn{width:22px;height:16px;border-radius:5px;}
    #${p} .pb-ra-nudge .pb-ra-btn svg{width:11px;height:11px;}
    #${p} .pb-ra-actions{display:flex;align-items:center;gap:4px;}
    #${p} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${p} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${p} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${p} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${p} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${p} .pb-ra-note{
      font-size:0.75rem;font-weight:400;color:var(--sapContent_LabelColor,#556b82);line-height:1.25;
    }

    /* Check-in list Room column — one line, same height as an EMMA room number */
    .sapUiTableDataCell:has([${b}="row"]) .sapUiTableCellInner,
    .sapUiTableDataCell:has([${b}="row"]) .sapMVBox{
      overflow:visible !important;
      max-height:none !important;
    }
    [${b}="row"]{
      display:inline-flex !important;
      align-items:center;
      gap:0.3rem;
      margin:0;
      height:1.5rem;
      line-height:1;
      max-width:100%;
      flex-shrink:0;
      position:relative;
      z-index:20;
      pointer-events:auto;
      vertical-align:middle;
    }
    [${b}="row"] .pb-ra-row-code{
      display:inline-flex;
      align-items:center;
      gap:0.3rem;
      height:1.35rem;
      padding:0 0.45rem 0 0.35rem;
      border-radius:999px;
      border:1px solid #8eb4d4;
      background:#f3f8fc;
      color:#0b3a5b;
      font-family:var(--sapFontFamily,"72",system-ui,sans-serif);
      font-size:0.75rem;
      font-weight:700;
      letter-spacing:.04em;
      white-space:nowrap;
    }
    [${b}="row"] .pb-ra-row-code::before{
      content:"";
      width:0.4rem;
      height:0.4rem;
      border-radius:999px;
      background:#1b7a3a;
      flex:0 0 auto;
    }
    [${b}="row"] .pb-ra-row-code.pb-ra-dirty{
      background:#fff8f0;
      border-color:#e0b07a;
      color:#7a3e00;
    }
    [${b}="row"] .pb-ra-row-code.pb-ra-dirty::before{background:#c2410c;}
    [${b}="row"] .pb-ra-row-note{
      display:inline-block;
      max-width:8.5rem;
      font-size:0.68rem;
      font-weight:600;
      line-height:1.2;
      color:#9a3412;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }
    [${b}="row"] .pb-ra-row-note.is-error{color:#9b1c1c;}
    #${p} .pb-ra-now{
      appearance:none;cursor:pointer;
      border:1px solid var(--sapButton_BorderColor,#bcc3ca);
      background:var(--sapButton_Background,#fff);
      border-radius:0.25rem;padding:0.15rem 0.4rem;
      font:inherit;font-size:0.75rem;font-weight:600;
      color:var(--sapButton_TextColor,#1d2d3e);
    }
    #${p} .pb-ra-now:hover{background:var(--sapButton_Hover_Background,#f5f6f7);}
    [${b}="row"] .pb-ra-row-accept{
      appearance:none;cursor:pointer;
      display:inline-flex;align-items:center;justify-content:center;
      width:1.35rem;height:1.35rem;padding:0;
      border:1px solid #1b7a3a;background:#1b7a3a;color:#fff;
      border-radius:999px;
    }
    [${b}="row"] .pb-ra-row-accept:hover{background:#14632f;}
    [${b}="row"] .pb-ra-row-accept svg{width:0.8rem;height:0.8rem;display:block;}
    #${z}{margin-inline-end:0.25rem;}
    #${N}{
      display:inline-flex;align-items:center;
      margin-inline-end:0.5rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.875rem;font-weight:600;
      color:var(--sapTextColor,#1d2d3e);
      white-space:nowrap;
    }
  `)}function To(e){const t=Ht();let n=document.getElementById(p);const o=(n==null?void 0:n.parentElement)===e&&(!t||n.previousElementSibling===t||n.parentElement===e);if(n&&o&&!n.closest(".sapMInputBase"))return n;const r=n==null?void 0:n.dataset.key;return n==null||n.remove(),n=document.createElement("div"),n.id=p,n.setAttribute(b,"detail"),n.setAttribute("role","region"),n.setAttribute("aria-label",u.emmaRoom.title),r&&(n.dataset.key=r),(e.style.display.includes("flex")||e.classList.contains("sapUiRFLContainer"))&&(e.style.flexWrap="wrap"),t&&t.parentElement===e?t.insertAdjacentElement("afterend",n):e.appendChild(n),n}function ee(){const e=document.getElementById(p);e&&(e.style.top="",e.style.left="")}function ko(e){return e.roomStatus==="DIRTY"||e.roomStatus==="CLEAN"||e.roomStatus==="IN_PROGRESS"?!0:e.roomStatus==="INSPECTED"||e.roomStatus==="OUT_OF_ORDER"?!1:!e.readyNow}function So(e){const t=`${Date.now()}-${Math.random().toString(16).slice(2)}`;return new Promise((n,o)=>{const r=window.setTimeout(()=>{document.removeEventListener("prize-ra-fill-room-done",a),o(new Error("room field"))},2500),a=i=>{const s=i.detail;!s||s.requestId!==t||(window.clearTimeout(r),document.removeEventListener("prize-ra-fill-room-done",a),s.error?o(new Error(s.error)):n())};document.addEventListener("prize-ra-fill-room-done",a),document.dispatchEvent(new CustomEvent("prize-ra-fill-room",{detail:{room:e,requestId:t}}))})}function jt(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function bt(e){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="${e==="up"?"M6 14l6-6 6 6":"M6 10l6 6 6-6"}"/></svg>`}let M=null,be=null,k="",L=!1,Ye=!1,Ne=!1,Pe=!1,ge=!1;const Se=new Map;function Eo(e){const t=Re();if(!t)return!1;const n=t.value,o=Ft(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function H(e){var w,R,E,P;if(e.setAttribute("aria-label",u.emmaRoom.title),U&&!v){e.innerHTML=`<div class="pb-ra-note">${O(u.emmaRoom.loading)}</div>`,ee();return}if(!v){if(ge&&!k){e.innerHTML=`<div class="pb-ra-note">${O(u.emmaRoom.loading)}</div>`,ee();return}e.innerHTML=`<div class="pb-ra-note">${O(k||u.emmaRoom.noSuggestion)}</div>`,ee();return}const t=cn(v.floor??St(v.roomNumber)),n=v.readyNow?u.emmaRoom.ready:u.emmaRoom.dirty,o=Nt(v.reasons),r=[t,n,o].filter(Boolean).join(" · "),a=k?`<div class="pb-ra-status${L?" pb-ra-warn":""}">${O(k)}</div>`:"",i=u.emmaRoom.accept,s=u.emmaRoom.higher,l=u.emmaRoom.lower,c=u.emmaRoom.arrivingNow,d=ko(v)?`<button type="button" class="pb-ra-now">${O(c)}</button>`:"";e.innerHTML=`<div class="pb-ra-main"><div><div class="pb-ra-room" title="${V(u.emmaRoom.previewNote)}">${O(v.roomNumber.padStart(4,"0"))}</div><div class="pb-ra-meta">${O(r)}</div></div><div class="pb-ra-actions"><div class="pb-ra-nudge"><button type="button" class="pb-ra-btn pb-ra-up" title="${V(s)}" aria-label="${V(s)}">${bt("up")}</button><button type="button" class="pb-ra-btn pb-ra-down" title="${V(l)}" aria-label="${V(l)}">${bt("down")}</button></div><button type="button" class="pb-ra-btn pb-ra-accept" title="${V(i)}" aria-label="${V(i)}">${jt()}</button></div></div>`+d+a,ee();const f=y=>{const q=Ve();if(!q||!v||B)return;const C=v;B=!0,U=!0,H(e),$o(q,y).then(ae=>{v=ae??C,M=null,k=ae?"":y==="up"?u.emmaRoom.noHigher:u.emmaRoom.noLower,L=!ae}).catch(ae=>{v=C,k=qe(ae),L=!0}).finally(()=>{B=!1,U=!1,H(e),F()})};(w=e.querySelector(".pb-ra-up"))==null||w.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation(),f("up")}),(R=e.querySelector(".pb-ra-down"))==null||R.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation(),f("down")}),(E=e.querySelector(".pb-ra-accept"))==null||E.addEventListener("click",y=>{if(y.preventDefault(),y.stopPropagation(),!v||B)return;const q=v;B=!0,wo(q).then(C=>{Eo(C),k=ne(u.emmaRoom.applied,{room:C}),L=!1,v=null,M=null}).catch(C=>{k=C instanceof Error&&C.message&&C.message!=="CSRF"?`${u.emmaRoom.assignFailed}: ${C.message}`:u.emmaRoom.assignFailed,L=!0}).finally(()=>{B=!1,H(e),F()})}),(P=e.querySelector(".pb-ra-now"))==null||P.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation();const q=Ve();!q||B||(B=!0,U=!0,H(e),xo(q).then(C=>{v=C,M=null,k=C?"":u.emmaRoom.noSuggestion,L=!C}).catch(C=>{k=qe(C),L=!0}).finally(()=>{B=!1,U=!1,H(e),F()}))})}function O(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function V(e){return O(e).replace(/'/g,"&#39;")}function ot(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function rt(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((i,s)=>{const l=(i.textContent||"").replace(/:/g,"").replace(/\s+/g," ").trim().toLowerCase();(l==="room"||l==="zimmer")&&(t=s),(l==="arrival"||l==="anreise")&&(n=s)}),{room:t,arrival:n}}function _e(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function Gt(e){const t=/-col0$/;let n=null;for(const o of e.querySelectorAll('[id*="-col"]'))if(t.test(o.id)){n=o;break}if(n||(n=e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")),!n)return null;for(const o of n.querySelectorAll(".sapMText, a.sapMLnk")){if(o.closest(`[${b}]`))continue;const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r}return null}function Vt(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${b}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&mo(n))return re(n)}return null}function Bo(e){for(const t of e.querySelectorAll(".sapMText")){const n=(t.textContent||"").trim(),o=X(n);if(o)return o}return X((e.textContent||"").trim())}function Io(e,t){if(t){const n=Bo(t);if(n)return n}for(const n of e.querySelectorAll(".sapMText")){if(n.closest(`[${b}]`))continue;const o=X((n.textContent||"").trim());if(o)return o}return null}function Lo(e,t){const n=t.reservationId,o=t.roomNumber;let r=e.querySelector(`[${b}="row"]`);const a=nt(e);if(r&&r.dataset.booking===n&&r.dataset.room===o&&r.dataset.ready===String(t.readyNow)&&(a==null?void 0:a.nextElementSibling)===r)return r;r||(r=document.createElement("div"),r.setAttribute(b,"row")),Pt(e,r),r.dataset.booking=n,r.dataset.room=o,r.dataset.ready=String(t.readyNow),r.innerHTML="";const i=document.createElement("span");i.className=`pb-ra-row-code${t.readyNow?"":" pb-ra-dirty"}`;const s=o.padStart(4,"0");i.textContent=s;const l=Nt(t.reasons);i.title=[u.emmaRoom.title,s,t.readyNow?u.emmaRoom.ready:u.emmaRoom.dirty,l].filter(Boolean).join(" · ");const c=document.createElement("button");return c.type="button",c.className="pb-ra-row-accept",c.innerHTML=jt(),c.title=u.emmaRoom.accept,c.setAttribute("aria-label",u.emmaRoom.accept),c.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),!B&&(B=!0,Ut(t).then(()=>{const f=e.querySelector(".sapMText, a.sapMLnk");f&&!f.closest(`[${b}]`)&&(f.textContent=s),r==null||r.remove()}).catch(()=>{i.title=u.emmaRoom.assignFailed}).finally(()=>{B=!1}))}),r.appendChild(i),r.appendChild(c),r}function Ao(){const e=document.querySelector('[id*="CheckInList"][id*="stickyToolbar"]');if(!e)return null;for(const t of e.querySelectorAll("button")){if(t.id===z)continue;const n=`${t.getAttribute("aria-label")||""} ${t.getAttribute("title")||""}`.toLowerCase();if(/express\s*check/.test(n))return t}return null}function he(e){const t=document.getElementById(z);if(!t)return;t.title=e,t.setAttribute("aria-label",e);const n=t.querySelector("bdi");n&&(n.textContent=e)}function Mo(){const e=`${Date.now()}-${Math.random().toString(16).slice(2)}`;return new Promise(t=>{const n=window.setTimeout(()=>{document.removeEventListener("prize-ra-checkin-rows-done",o),t(null)},400),o=r=>{const a=r.detail;!a||a.requestId!==e||(window.clearTimeout(n),document.removeEventListener("prize-ra-checkin-rows-done",o),t(a.rows??null))};document.addEventListener("prize-ra-checkin-rows-done",o),document.dispatchEvent(new CustomEvent("prize-ra-checkin-rows",{detail:{requestId:e}}))})}function Ro(e,t){const n=o=>e.items.some(r=>{var a;return xe(r.reservationId,o)&&((a=r.suggestion)==null?void 0:a.readyNow)===!0});if(t!=null&&t.length){const o=new Set;let r=0,a=0;for(const i of t){const s=tt(i.id);o.has(s)||(o.add(s),r+=1,n(i.id)&&(a+=1))}return{ready:a,total:r}}return{total:e.items.length,ready:e.items.filter(o=>{var r;return(r=o.suggestion)==null?void 0:r.readyNow}).length}}function gt(e,t,n){var r;if(t<=0){(r=document.getElementById(N))==null||r.remove();return}let o=document.getElementById(N);(!o||o.nextElementSibling!==n)&&(o==null||o.remove(),o=document.createElement("span"),o.id=N,o.className="sapMBarChild",n.insertAdjacentElement("beforebegin",o)),o.textContent=ne(u.emmaRoom.assignAllAvailable,{ready:e,total:t})}function ht(e=0,t=0){var r,a;const n=Ao();if(!n){(r=document.getElementById(z))==null||r.remove(),(a=document.getElementById(N))==null||a.remove();return}let o=document.getElementById(z);if((o==null?void 0:o.nextElementSibling)===n){o.dataset.busy!=="1"&&o.dataset.hold!=="1"&&he(u.emmaRoom.assignAll),gt(e,t,o);return}o==null||o.remove(),o=document.createElement("button"),o.id=z,o.type="button",o.className="sapMBtnBase sapMBtn sapMBarChild",o.innerHTML='<span class="sapMBtnInner sapMBtnHoverable sapMFocusable sapMBtnEmphasized"><span class="sapMBtnContent"><bdi></bdi></span></span>',o.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),_o()}),n.insertAdjacentElement("beforebegin",o),he(u.emmaRoom.assignAll),gt(e,t,o)}function Wt(e){const t=ot();if(!t)return null;for(const n of t.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr")){const o=Gt(n);if(o&&xe(o,e))return n}return null}function qo(e){var s;const t=Wt(e.reservationId),n=t==null?void 0:t.closest("table");if(!t||!n)return;const o=rt(n),r=_e(t,o.room);if(!r)return;const a=e.roomNumber.padStart(4,"0"),i=r.querySelector(".sapMText, a.sapMLnk");i&&!i.closest(`[${b}]`)&&(i.textContent=a),(s=r.querySelector(`[${b}]`))==null||s.remove()}async function _o(){const e=document.getElementById(z);if(!e||B||e.dataset.busy==="1")return;const n=(await et()).items.filter(a=>{if(!a.suggestion)return!1;const i=Wt(a.reservationId),s=i==null?void 0:i.closest("table");if(!i||!s)return!0;const l=rt(s),c=_e(i,l.room);return!c||!Vt(c)});if(!n.length)return;B=!0,e.dataset.busy="1",e.disabled=!0,e.classList.add("sapMBtnDisabled");let o=0,r=0;try{for(const a of n){const i=a.suggestion;if(i){he(ne(u.emmaRoom.assignAllBusy,{done:o+r,total:n.length}));try{await Ut(i),o+=1,qo(i)}catch{r+=1}}}}finally{B=!1,e.dataset.busy="0",e.disabled=!1,e.classList.remove("sapMBtnDisabled"),e.dataset.hold="1",he(r?ne(u.emmaRoom.assignAllPartial,{done:o,failed:r}):ne(u.emmaRoom.assignAllDone,{count:o})),window.setTimeout(()=>{e.dataset.hold="0",he(u.emmaRoom.assignAll)},4e3),T=null,F()}}function Do(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function Yt(e,t){var o;const n=ot();if(n){Ye=!0;try{const r=rt(n),a=n.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),i=new Set(a),s=new Set,l=new Set;for(const c of a){const d=_e(c,r.room),f=Gt(c);if(!f){(o=d==null?void 0:d.querySelector(`[${b}="row"]`))==null||o.remove();continue}const w=_e(c,r.arrival);if(!d)continue;const R=Vt(d),E=d.querySelector(`[${b}="row"]`);if(R){Se.delete(tt(f)),E==null||E.remove();continue}const P=Io(c,w);if(P&&!Lt(P)){E==null||E.remove();continue}if(e.error){s.add(ft(d,e.error,!0));continue}const y=e.items.find(C=>xe(C.reservationId,f)),q=y!=null&&y.suggestion?y.suggestion.roomNumber.replace(/^0+/,""):"";if(!(y!=null&&y.suggestion)||q&&l.has(q)){y||t==null||t.add(f),y?s.add(ft(d,u.emmaRoom.noSuggestion,!1)):ge||E==null||E.remove();continue}l.add(q),s.add(Lo(d,y.suggestion))}document.querySelectorAll(`[${b}="row"]`).forEach(c=>{if(!(c instanceof HTMLElement)||s.has(c))return;const d=c.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!d||!i.has(d))&&c.remove()})}finally{queueMicrotask(()=>{Ye=!1,We&&(We=!1,Xe())})}}}function Xe(){He||(He=window.requestAnimationFrame(()=>{if(He=0,!T){F();return}Yt(T)}))}function zo(e){return[e.target,...e.addedNodes,...e.removedNodes].some(n=>{const o=n instanceof Element?n:n.parentElement;return!!(o!=null&&o.closest('table[id*="checkInList"], [id*="CheckInList"][id*="table"]'))})}async function yt(e){var a,i;if(!ot()){Do()?ht(0,0):(document.querySelectorAll(`[${b}="row"]`).forEach(s=>s.remove()),(a=document.getElementById(z))==null||a.remove(),(i=document.getElementById(N))==null||i.remove());return}const n=await et();Yt(n,e);const o=await Mo(),r=Ro(n,o);ht(r.ready,r.total)}function De(){var e;(e=document.getElementById(p))==null||e.remove(),M=null,v=null,U=!1,k="",L=!1}async function vt(e){var s;const t=Ve(),n=fo();if(!n||!t){De();return}if(!go()){De();return}const o=((s=document.getElementById(p))==null?void 0:s.parentElement)===n,r=To(n);ee();const a=t;if(!o&&r.dataset.key===a&&H(r),r.dataset.key===a||Fe.has(a))return;Fe.add(a);const i=M!==a;M=a,i&&(k="",L=!1),U=!0,H(r);try{const l=await et();if(M!==a)return;l.error?(v=null,k=l.error,L=!0):(v=vo(l.items,t),v||(l.items.some(d=>xe(d.reservationId,t))?(k=u.emmaRoom.noSuggestion,L=!0):(e==null||e.add(t),k="",L=!1))),r.dataset.key=a}catch(l){if(M!==a)return;v=null,k=qe(l),L=!0,r.dataset.key=a}finally{U=!1,Fe.delete(a)}M===a&&H(r)}async function Xt(){if(Ne){Pe=!0;return}Ne=!0;try{if(!uo()){De(),document.querySelectorAll(`[${b}="row"]`).forEach(t=>t.remove());return}Co();const e=new Set;if(ge=!1,await yt(e),await vt(e),e.size){ge=!0;const t=document.getElementById(p);t&&H(t);const n=await yo([...e]);ge=!1,n?(t&&delete t.dataset.key,await yt(),await vt()):t&&H(t)}}finally{Ne=!1,Pe&&(Pe=!1,F())}}function F(){be&&window.clearTimeout(be),be=window.setTimeout(()=>{Xt()},350)}function Ho(){ye().then(n=>{u=I(n),M=null,F()}),ve(n=>{u=I(n),M=null,F()}),Xt();const e=()=>{ee(),Xe()};window.addEventListener("scroll",e,!0),window.addEventListener("resize",e),window.addEventListener("hashchange",()=>{var n;M=null,v=null,(n=document.getElementById(p))==null||n.removeAttribute("data-key"),F()});const t=new MutationObserver(n=>{if(Ye){We=!0;return}let o=!1;for(const r of n){const a=r.target;if(a instanceof Element&&(a.id===p||a.id===fe||a.id===z||a.id===N||a.closest(`[${b}]`)||a.closest(`#${z}`)||a.closest(`#${N}`)))continue;const i=[...r.addedNodes];if(!(i.length>0&&i.every(s=>s instanceof Element&&(s.id===p||s.id===fe||s.id===z||s.id===N||s.hasAttribute(b))))){if(zo(r)){o=!0;continue}F();return}}o&&Xe()});return t.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var n;t.disconnect(),be&&window.clearTimeout(be),De(),document.querySelectorAll(`[${b}="row"]`).forEach(o=>o.remove()),(n=document.getElementById(fe))==null||n.remove()}}const wt="prize-panel-host";let j=I("de");function Kt(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function Ee(e,t,n){const o=`${Be}px 0 0 ${Be}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=Kt(),t.title=j.inject.openPanel,t.setAttribute("aria-label",j.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${Ct}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=j.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function xt(e,t,n){var i;const r=!await Ke(G.panelCollapsed);await en({[G.panelCollapsed]:r}),Ee(e,t,r);const a=e.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?te.collapsed:te.expanded},"*")}function $t(){if(document.getElementById(wt))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${Be}px 0 0 ${Be}px`,r=document.createElement("div");r.id=wt,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${Jt}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:Ce,border:`1px solid ${Oe}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=j.inject.panelTitle,Object.assign(i.style,{width:`${Ct}px`,height:"100%",border:"none",display:"block",background:Ce}),a.appendChild(i);const s=document.createElement("button");s.id="prize-panel-tab",s.type="button",Object.assign(s.style,{width:`${at}px`,height:`${Qt}px`,minWidth:`${at}px`,border:`1px solid ${Oe}`,borderRight:"none",background:`linear-gradient(180deg, ${Ce} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),s.innerHTML=Kt(),s.addEventListener("mouseenter",()=>{s.style.filter="brightness(1.12)"}),s.addEventListener("mouseleave",()=>{s.style.filter=""}),s.addEventListener("click",()=>{xt(a,s)}),r.appendChild(a),r.appendChild(s),document.documentElement.appendChild(r),Ke(G.panelCollapsed).then(l=>{t=l,Ee(a,s,l)}),window.addEventListener("message",l=>{var c,d,f,w;((c=l.data)==null?void 0:c.type)===te.toggle&&xt(a,s),((d=l.data)==null?void 0:d.type)===te.chatOpen&&(e=!0,n()&&((f=document.getElementById("prize-panel-chat-toast"))==null||f.remove())),((w=l.data)==null?void 0:w.type)===te.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((l,c)=>{c==="local"&&l[G.panelCollapsed]&&(t=!!l[G.panelCollapsed].newValue)}),vn(n),zn(),oo(),Ho(),ye().then(l=>{j=I(l),Ee(a,s,t),i.title=j.inject.panelTitle}),ve(l=>{j=I(l),Ee(a,s,t),i.title=j.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",$t):$t();
