import{b as we,S as I,P as U,c as re,d as ye,A as at,e as ce,f as it,g as Pe,T as Me,h as st,s as lt}from"./storage-DTWcLCTt.js";import{l as ee,w as te,i as de,g as T,a as Ne,b as Oe,p as Ue,c as Ce,d as ct,t as Ae,B as dt,e as ut,f as pt}from"./bernticket-api-DAinuR-j.js";const ve=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function mt(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function ft(e){if(mt(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=ve.length;n++){const[o,r]=ve[n-1];if(t>=o&&t<=r)return n}return null}function bt(){const e=[];for(let t=1;t<=17;t++)t%100!==13&&e.push(String(t));for(let t=21;t<=37;t++)e.push(String(t));for(const[t,n]of ve)for(let o=t;o<=n;o++)o%100!==13&&e.push(String(o));return e}function gt(e,t){const n=parseInt(e,10),o=parseInt(t,10),r=Number.isFinite(n),a=Number.isFinite(o);return r&&a?n-o:r&&!a?-1:!r&&a?1:e.localeCompare(t)}function ht(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let K=T("de");const S="prize-panel-chat-toast",Le="prize-panel-chat-toast-style",yt=8e3,vt=7e3;function xt(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function $t(e){return e==="/r"||e.startsWith("/r/")}function wt(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function Ct(){if(document.getElementById(Le))return;const e=document.createElement("style");e.id=Le,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${S}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${re} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${ye};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${S}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${S} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${S} .pb-ct-body{min-width:0;flex:1;}
    #${S} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${at};margin-bottom:2px;
    }
    #${S} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${S} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${S} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${S} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let ae=null;function D(e=!0){const t=document.getElementById(S);if(t){if(ae&&(window.clearTimeout(ae),ae=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function Tt(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,i,l)=>{const s=t.createOscillator(),d=t.createGain();s.type="sine",s.frequency.setValueAtTime(a,i),d.gain.setValueAtTime(1e-4,i),d.gain.exponentialRampToValueAtTime(.9,i+.015),d.gain.exponentialRampToValueAtTime(1e-4,i+l),s.connect(d),d.connect(o),s.start(i),s.stop(i+l+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function St(e,t){Ct(),D(!1);const n=document.createElement("div");n.id=S,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),l=r.querySelector(".pb-ct-preview");a.textContent=K.toast.eyebrow,i.textContent=de(K.toast.newMessageFrom,{author:e}),l.textContent=wt(t);const s=document.createElement("button");s.type="button",s.className="pb-ct-close",s.setAttribute("aria-label",K.toast.close),s.textContent="×",s.addEventListener("click",d=>{d.stopPropagation(),D(!0)}),n.addEventListener("click",()=>D(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(s),document.documentElement.appendChild(n),Tt(),ae=window.setTimeout(()=>{D(!0)},vt)}function kt(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:U.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function Et(e){let t=!1,n=null,o=!0;ee().then(l=>{K=T(l)});const r=te(l=>{K=T(l)});we(I.chatNotificationsEnabled,!0).then(l=>{o=l});try{chrome.storage.onChanged.addListener((l,s)=>{if(s==="local"&&l[I.chatNotificationsEnabled]){const d=l[I.chatNotificationsEnabled].newValue;o=d===void 0?!0:!!d,o||D(!1)}})}catch{}const a=async()=>{var l,s,d;if(!t)try{if(!o)return;const u=await kt();if(!u.ok)return;const b=u.msg;if(!(b!=null&&b.id))return;if(n===null){n=b.id;return}if(b.id===n||(n=b.id,(l=b.author)!=null&&l.id&&u.meId&&b.author.id===u.meId)||e()||xt(window.location.pathname)||$t(window.location.pathname))return;const C=((d=(s=b.author)==null?void 0:s.name)==null?void 0:d.trim())||"Team";St(C,b.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},yt);return()=>{t=!0,window.clearInterval(i),r(),D(!1)}}const Bt={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function j(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=Bt[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const i=new Date(a),l=i.getFullYear(),s=String(i.getMonth()+1).padStart(2,"0"),d=String(i.getDate()).padStart(2,"0");if(l>=2e3)return`${l}-${s}-${d}`}return null}function je(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Mt(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Ge(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:j(e);return!!(t&&t===je())}let p=T("de");const m="prize-bt-checkin-host",ue="prize-bt-checkin-style",$="prize-bt-fallback-bar",g="prize-bt-create-dialog";function At(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function We(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function pe(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}return null}function Lt(){const e=pe();if(e)return e;if(We())return null;for(const o of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const r=(o.textContent||"").trim();if(/^\d{6,}$/.test(r))return r.replace(/^0+/,"")||r}const t=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),n=((t==null?void 0:t.textContent)||"").match(/\b(\d{6,})\b/);return n?n[1].replace(/^0+/,"")||n[1]:null}function It(){return!!document.querySelector(['.sapUiLocalBusyIndicator:not([style*="display: none"])',".sapUiBusy",".sapMBusyDialog",".sapUiBlockLayer",".sapUiBLy",".sapUiLocalBusyIndicatorAnimation",'[class*="BusyIndicator"]:not([style*="display: none"])'].join(", "))}function Ve(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function Te(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function H(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const l=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const s of l)if(o.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING){const u=(s instanceof HTMLInputElement||s instanceof HTMLTextAreaElement?s.value:s.textContent||"").trim();if(u&&!t.test(u))return u}a=a.parentElement}}return null}function qt(){const e=Te()||document.body,t=H(e,/^Arrival\s*Date$/i)||H(e,/^Anreise(datum)?$/i),n=H(e,/^Departure\s*Date$/i)||H(e,/^Abreise(datum)?$/i),o=t&&j(t)||je(),r=n&&j(n)||Mt();return{from:o,to:r}}function Rt(){const e=Te()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=H(t,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function zt(){const e=Te()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=H(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function _t(e){const t=qt();return{guestName:zt(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:Rt()}}function Dt(){const e=document.getElementById(ue);e&&e.remove();const t=document.createElement("style");t.id=ue,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${m}),
    .sapMTBSpacerFlex:has(#${m}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${m}.sapMBarChild,
    #${m}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${m} *{box-sizing:border-box;}
    #${m} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${m} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);font-weight:700;
      letter-spacing:.04em;line-height:1.2;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.25rem;
      padding:0.35rem 0.6rem;
      min-width:0;text-align:center;
    }
    #${m} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${m} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${m} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${m} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${m} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${m} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${$}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.35rem;
      padding:0.2rem 0.45rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.75rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.25rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${$} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${$} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${$} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.04em;
      font-size:0.75rem;line-height:1.2;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.2rem;padding:0.15rem 0.4rem;
    }
    #${$} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${$} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${g}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${g} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${g} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${g} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${g} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${g} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${g} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${g} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${g} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${g} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${g} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${g} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${g} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${g} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${g} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${g} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function F(){var e;(e=document.getElementById(g))==null||e.remove()}function Ht(e){var o,r;(o=document.getElementById($))==null||o.remove();let t=document.getElementById(m);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=m,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",p.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function Ft(){var t;(t=document.getElementById(m))==null||t.remove();let e=document.getElementById($);return e||(e=document.createElement("div"),e.id=$,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",p.emmaBt.brand),document.documentElement.appendChild(e),e)}function q(e,t){e.innerHTML=t}function R(e){return`<span class="pb-bt-label">${y(p.emmaBt.brand)}</span>${e}`}async function Pt(e){try{await navigator.clipboard.writeText(e)}catch{}}function Ie(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{Pt(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=p.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function Nt(e,t,n,o){F();const r=document.createElement("div");r.id=g,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${B(p.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${y(p.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${B(p.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${y(p.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${B(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${y(p.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${B(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${y(p.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${B(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${y(p.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${B(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${y(p.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${y(p.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${y(p.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(s=>{s.addEventListener("click",()=>F())});const l=s=>{s.key==="Escape"&&(F(),window.removeEventListener("keydown",l))};window.addEventListener("keydown",l),i.addEventListener("click",()=>{(async()=>{const s=r.querySelector(".pb-bt-dlg-name"),d=r.querySelector(".pb-bt-dlg-from"),u=r.querySelector(".pb-bt-dlg-to"),b=r.querySelector(".pb-bt-dlg-amt"),C=(s==null?void 0:s.value.trim())||"";if(!C){a.hidden=!1,a.textContent=p.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=p.common.ellipsis,a.hidden=!0;try{const z=await ct({guestName:C,bookingNumber:t,validFrom:Ae((d==null?void 0:d.value)||n.from),validTo:Ae((u==null?void 0:u.value)||n.to),ticketsAmount:Math.max(1,parseInt((b==null?void 0:b.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});F(),o(Ce(z))}catch(z){if(z instanceof dt&&z.code===ut){const Ee=window.prompt(p.emmaBt.twoFaPrompt);if(Ee)try{await pt(Ee),i.disabled=!1,i.textContent=p.emmaBt.create,i.click();return}catch(Be){a.hidden=!1,a.textContent=Be instanceof Error?Be.message:p.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=p.emmaBt.create;return}}a.hidden=!1,a.textContent=z instanceof Error?z.message:p.emmaBt.error,i.disabled=!1,i.textContent=p.emmaBt.create}})()})}let x=null,_=null,X=null,ne=0;async function xe(e,t,n){var a,i;const o=++ne,r=await Ne();if(o===ne){if(!r.access){q(e,R(`<span class="pb-bt-muted">${y(p.emmaBt.loginHint)}</span>`));return}q(e,R(`<span class="pb-bt-muted">${y(p.emmaBt.loading)}</span>`));try{const l=await Oe(t);if(o!==ne)return;const s=Ue(l,t),d=Ce(s),u=p.bernticket.copyCode;if(s&&d){q(e,R(`<button type="button" class="pb-bt-code" title="${B(u)}">${y(d)}</button>`)),Ie(e,d);return}if(s&&!d){const C=de(p.emmaBt.noCode,{status:s.status});q(e,R(`<span class="pb-bt-muted">${y(C)}</span>`));return}const b=_t(t);q(e,R(`<button type="button" class="pb-bt-btn pb-bt-open-create">${y(p.emmaBt.openCreate)}</button>`)),(a=e.querySelector(".pb-bt-open-create"))==null||a.addEventListener("click",()=>{Nt(e,t,b,C=>{C?(q(e,R(`<button type="button" class="pb-bt-code" title="${B(u)}">${y(C)}</button>`)),Ie(e,C)):(x=null,xe(e,t,!0))})})}catch(l){if(o!==ne)return;q(e,R(`<span class="pb-bt-muted">${y(l instanceof Error?l.message:p.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${y(p.emmaBt.retry)}</button>`)),(i=e.querySelector(".pb-bt-retry"))==null||i.addEventListener("click",()=>{x=null,xe(e,t)})}}}function y(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function B(e){return y(e).replace(/'/g,"&#39;")}function W(){X&&window.clearTimeout(X),X=window.setTimeout(()=>{Ke()},350)}function Ye(e){return document.documentElement.contains(e)}async function Ke(){var a,i,l,s,d,u;if(!At()){(a=document.getElementById(m))==null||a.remove(),(i=document.getElementById($))==null||i.remove(),F(),x=null,_=null;return}Dt();const e=It();let t=Lt();if(t?_=t:e&&_?t=_:!e&&!pe()&&(_=null),!e&&We()&&!pe()){(l=document.getElementById(m))==null||l.remove(),(s=document.getElementById($))==null||s.remove(),x=null;return}if(!t){(d=document.getElementById(m))==null||d.remove(),(u=document.getElementById($))==null||u.remove(),x=null;return}const n=e?null:Ve(),o=n?m:$,r=n?Ht(n):Ft();if(t===x&&r.dataset.bound===t&&r.id===o&&Ye(r))if(n&&!n.contains(r))x=null;else return;x=t,r.dataset.bound=t,await xe(r,t)}function Ot(){ee().then(t=>{p=T(t),x=null,W()}),te(t=>{p=T(t),x=null,W()}),Ke(),window.addEventListener("hashchange",()=>{x=null,pe()||(_=null),W()});const e=new MutationObserver(t=>{let n=!1;for(const a of t){const i=a.target;if(!(i instanceof Element&&(i.id===m||i.id===$||i.id===ue||i.id===g||i.closest("[data-prize-bernticket]")))){n=!0;break}}if(!n)return;const o=Ve(),r=document.getElementById(m)||document.getElementById($);r&&!Ye(r)&&(x=null),o&&(r==null?void 0:r.id)===m&&!o.contains(r)&&(x=null),o&&(r==null?void 0:r.id)===$&&(x=null),!o&&(r==null?void 0:r.id)===m&&(x=null),o&&!r&&(x=null),W()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(x=null,W())})}catch{}return()=>{var t,n,o;e.disconnect(),X&&window.clearTimeout(X),(t=document.getElementById(m))==null||t.remove(),(n=document.getElementById($))==null||n.remove(),(o=document.getElementById(ue))==null||o.remove(),F()}}const Xe=300*1e3,P=new Map,ie=new Map;function me(e){return e.replace(/^0+/,"")||e}function qe(e){const t=P.get(e);return!t||Date.now()-t.at>=Xe?null:{code:t.code}}function Ut(){P.clear(),ie.clear()}async function jt(e){const t=me(e),n=P.get(t);if(n&&Date.now()-n.at<Xe)return n.code;let o=ie.get(t);return o||(o=(async()=>{try{const r=await Ne();if(!(r!=null&&r.access))return P.set(t,{code:null,at:Date.now()}),null;const a=await Oe(t),i=Ue(a,t),l=Ce(i);return P.set(t,{code:l,at:Date.now()}),l}catch{return P.set(t,{code:null,at:Date.now()}),null}finally{ie.delete(t)}})(),ie.set(t,o)),o}async function Gt(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}let k=T("de");const fe="prize-bt-list-style",c="data-prize-bt-chip";let Z=null;function Wt(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Vt(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Yt(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function Kt(){let e=document.getElementById(fe);e||(e=document.createElement("style"),e.id=fe,document.documentElement.appendChild(e)),e.dataset.v!=="7"&&(e.dataset.v="7",e.textContent=`
    [${c}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: BELOW reservation number — do not sit in the number hbox */
    [${c}][data-surface="list"]{
      display:block !important;
      margin:0.15rem 0 0 0 !important;
      max-width:100%;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${c}]),
    .sapUiTableDataCell:has([${c}]),
    .sapMVBox:has([${c}]),
    .sapMHBox:has([${c}]){
      overflow:visible !important;
    }
    .sapUiTableCellInner:has([${c}[data-surface="list"]]){
      max-height:none !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${c}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    /* Room Status detail panel (click a room): large code */
    [${c}][data-surface="room-detail"]{
      display:flex !important;
      flex-direction:column;
      align-items:flex-start;
      gap:0.4rem;
      margin:0.65rem 0.75rem 0.35rem !important;
      padding:0.7rem 0.9rem;
      background:linear-gradient(180deg,#fff 0%,#fff8f8 100%);
      border:1px solid rgba(170,8,8,.28);
      border-radius:0.5rem;
      box-shadow:0 2px 10px rgba(15,23,42,.08);
      position:relative !important;
      left:auto !important;
      bottom:auto !important;
      max-width:min(100%, 20rem);
      z-index:10;
    }
    [${c}][data-surface="room-detail"] .pb-bt-detail-label{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.68rem;
      font-weight:700;
      letter-spacing:.07em;
      text-transform:uppercase;
      color:#6a6d70;
    }
    [${c}][data-surface="room-detail"] .pb-bt-list-code{
      font-size:1.55rem !important;
      font-weight:800;
      letter-spacing:.08em;
      padding:0.4rem 0.85rem;
      border-radius:0.35rem;
      line-height:1.15;
    }
    [${c}][data-surface="room-detail"] .pb-bt-list-muted{
      font-size:0.85rem;
    }
    [${c}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${c}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${c}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${c}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function Ze(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${c}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return me(n)}return null}function Xt(e){return Ze(e)}function Zt(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return Ze(t)}function Qt(e,t){let n=e.querySelector(`:scope > [${c}]`);if(!n){const o=e.querySelector(`[${c}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(c,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function Jt(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function en(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function tn(e,t){let n=null;for(const i of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!i.closest(`[${c}]`)&&/^\d{6,}$/.test((i.textContent||"").trim())){n=i;break}const o=(n==null?void 0:n.closest(".sapMVBox"))||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e,r=(n==null?void 0:n.closest(".sapMHBox"))||o.querySelector(":scope > .sapMHBox");let a=e.querySelector(`[${c}]`);return a?(a.dataset.booking!==t&&(a.dataset.booking=t,a.dataset.state="",a.innerHTML=""),a.dataset.surface="list",a.parentElement!==o?r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a):r&&a.previousElementSibling!==r&&r.insertAdjacentElement("afterend",a),a):(a=document.createElement("div"),a.setAttribute(c,"1"),a.dataset.booking=t,a.dataset.surface="list",r&&r.parentElement===o?r.insertAdjacentElement("afterend",a):o.appendChild(a),a)}function nn(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function on(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Gt(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",k.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||k.emmaBt.clickToCopy)},1200)})})}function rn(e,t){if(e.setAttribute(c,"1"),e.dataset.booking=t,e.dataset.state="loading",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${$e(k.emmaBt.brand)}</div><span class="pb-bt-list-muted">${$e(k.emmaBt.loading)}</span>`;return}e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function Re(e,t,n){if(e.setAttribute(c,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="",e.dataset.surface==="room-detail"){const r=document.createElement("div");r.className="pb-bt-detail-label",r.textContent=k.emmaBt.brand,e.appendChild(r)}const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=k.emmaBt.clickToCopy,o.setAttribute("aria-label",`${k.emmaBt.brand}: ${n}`),on(o,n),e.appendChild(o)}function ze(e,t){if(e.setAttribute(c,"1"),e.dataset.booking=t,e.dataset.state="none",e.dataset.surface==="room-detail"){e.innerHTML=`<div class="pb-bt-detail-label">${$e(k.emmaBt.brand)}</div><span class="pb-bt-list-muted">—</span>`;return}e.innerHTML=""}function $e(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function Se(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=qe(t);if(r&&r.code===null)return;e.dataset.state=""}const n=qe(t);if(n){n.code?Re(e,t,n.code):ze(e,t);return}rn(e,t);const o=await jt(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?Re(e,t,o):ze(e,t))}function an(){const e=Vt();if(!e){nn()||document.querySelectorAll(`[${c}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=en(r);if(!a)continue;const i=Xt(a),l=a.querySelector(`[${c}]`);if(!i){(l==null?void 0:l.dataset.state)==="ok"&&n.add(l);continue}const s=tn(a,i);n.add(s),Se(s,i)}document.querySelectorAll(`[${c}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function sn(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function ln(){const e=Yt(),t=new Set(e);if(e.length===0){sn()||document.querySelectorAll(`[${c}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=Zt(o),a=o.querySelector(`[${c}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&Jt(o)){n.add(a);continue}a==null||a.remove();continue}const i=Qt(o,r);n.add(i),Se(i,r)}document.querySelectorAll(`[${c}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function cn(){const e=document.querySelectorAll('.sapMPageEnableScrolling, section.sapMPageEnableScrolling, [id$="-cont"].sapUiScrollDelegate');for(const t of e){if(t.querySelector(".sapMGT.roomTiles, .sapMGT.roomTiles2"))continue;const n=t.querySelector('.sapMTitle, .sapMTitle-inner, [class*="sapMTitle"]'),o=((n==null?void 0:n.textContent)||"").replace(/\s+/g," ").trim();if((/^room\s+\d+/i.test(o)||/^zimmer\s+\d+/i.test(o)||[...t.querySelectorAll("bdi, .sapMBtnContent")].some(a=>/check\s*out|change\s*room\s*status/i.test((a.textContent||"").trim())))&&Qe(t))return t}return null}function Qe(e){var t;for(const n of e.querySelectorAll(".sapMLabel, .sapMLabel bdi")){const o=(n.textContent||"").replace(/\s+/g," ").trim().replace(/:$/,"");if(!/^(reservation|reservierung)$/i.test(o))continue;const r=((t=n.closest('[class*="wrapperfor"]'))==null?void 0:t.parentElement)||n.closest(".sapUiFormResGridCont")||n.closest(".sapUiRespGrid")||e;for(const a of r.querySelectorAll("a.sapMLnk")){const i=(a.textContent||"").trim();if(/^\d{6,}$/.test(i))return me(i)}}for(const n of e.querySelectorAll("a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return me(o)}return null}function dn(e,t){let n=e.querySelector(`[${c}][data-surface="room-detail"]`);if(n)return n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n;n=document.createElement("div"),n.setAttribute(c,"1"),n.dataset.booking=t,n.dataset.surface="room-detail",n.setAttribute("role","region"),n.setAttribute("aria-label",k.emmaBt.brand);const o=e.querySelector(":scope > .sapMHBox"),r=e.querySelector('.sapUiForm, [role="form"]');return(o==null?void 0:o.parentElement)===e?o.insertAdjacentElement("afterend",n):r?r.insertAdjacentElement("beforebegin",n):e.insertBefore(n,e.firstChild),n}function un(){const e=cn();if(!e){document.querySelectorAll(`[${c}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const t=Qe(e);if(!t){document.querySelectorAll(`[${c}][data-surface="room-detail"]`).forEach(o=>o.remove());return}const n=dn(e,t);Se(n,t)}function Je(){if(!Wt()){document.querySelectorAll(`[${c}]`).forEach(e=>e.remove());return}Kt(),an(),ln(),un()}function V(){Z&&window.clearTimeout(Z),Z=window.setTimeout(()=>{Je()},280)}function pn(){ee().then(t=>{k=T(t),V()}),te(t=>{k=T(t),document.querySelectorAll(`[${c}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),V()}),Je(),window.addEventListener("hashchange",()=>V());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===fe||o.closest(`[${c}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${c}]`)||r.closest(`[${c}]`))))){V();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(Ut(),document.querySelectorAll(`[${c}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),V())})}catch{}return()=>{var t;e.disconnect(),Z&&window.clearTimeout(Z),(t=document.getElementById(fe))==null||t.remove(),document.querySelectorAll(`[${c}]`).forEach(n=>n.remove())}}let h=T("de");const f="prize-ra-host",be="prize-ra-style",w="data-prize-room-assign",N=bt().sort(gt),mn=new Set(N);function fn(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function et(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${w}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o.replace(/^0+/,"")||o}return null}function tt(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function G(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function bn(e){const t=G(e);return!!(t&&mn.has(t))}function gn(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=G(r);if(a)return a}}return null}function nt(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&tt(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function hn(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&tt(o))return o}const t=nt();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function yn(){const e=hn();if(!e)return null;const t=e.querySelector(".sapUiCompSmartFieldValue")||e.querySelector(".sapMInputBaseContentWrapper")||e.querySelector(".sapMInput")||e;let n=t;for(let o=0;o<6&&n;o++){if(n.classList.contains("sapUiVltCell")||n.classList.contains("sapMVBox")||n.classList.contains("sapMHBox"))return n;n=n.parentElement}return t}function he(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const l=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const s of l)if(o.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING){const u=(s instanceof HTMLInputElement?s.value:s.textContent||"").trim();if(u&&!t.test(u))return u}a=a.parentElement}}return null}function vn(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=he(n,/^Arrival\s*Date$/i)||he(n,/^Arrival$/i)||he(n,/^Anreise(datum)?$/i);if(!o)continue;const r=j(o);if(r)return r}return null}function xn(){if(gn())return!1;const e=vn();return Ge(e)}function $n(e,t){const n=G(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}function wn(e){const t=G(e);return N.findIndex(n=>n===t)}function ke(e,t,n){const o=n?G(n):null;let r=0;if(o){const s=wn(o);s>=0&&(r=s)}else e&&(r=[...e].reduce((d,u)=>d+u.charCodeAt(0),0)%N.length);t==="higher"?r=Math.min(N.length-1,r+1):t==="lower"?r=Math.max(0,r-1):t==="extra_bed"&&(r=Math.min(N.length-1,r+2));const a=N[r]||"101",i=ft(a),l={default:h.emmaRoom.labelDefault,higher:h.emmaRoom.labelHigher,lower:h.emmaRoom.labelLower,extra_bed:h.emmaRoom.labelExtraBed};return{roomNumber:a,floor:i,kind:t,label:l[t]}}function Cn(){let e=document.getElementById(be);e||(e=document.createElement("style"),e.id=be,document.documentElement.appendChild(e)),e.dataset.v!=="3"&&(e.dataset.v="3",e.textContent=`
    /* Detail: compact chip inline at the Room field */
    #${f}{
      box-sizing:border-box;
      display:inline-flex;
      flex-direction:column;
      gap:4px;
      margin:2px 0 0 0;
      max-width:min(200px,100%);
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:#fff;
      border:1px solid rgba(45,58,79,.16);
      border-radius:8px;
      box-shadow:0 1px 4px rgba(15,23,42,.08);
      padding:6px 8px;
      z-index:5;
      pointer-events:auto;
      vertical-align:middle;
    }
    #${f} *{box-sizing:border-box;}
    #${f} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${f} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${f} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${f} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${f} .pb-ra-main{
      display:flex;align-items:center;gap:6px;
    }
    #${f} .pb-ra-room{
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:16px;font-weight:800;letter-spacing:.03em;line-height:1.1;
      color:#1a2332;
    }
    #${f} .pb-ra-meta{
      font-size:9px;color:#64748b;margin-top:1px;font-weight:500;
    }
    #${f} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${f} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:26px;height:26px;border-radius:7px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
    }
    #${f} .pb-ra-btn:hover{background:#f1f5f9;}
    #${f} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${f} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${f} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${f} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${f} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${f} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${f} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${f} .pb-ra-note{
      font-size:8px;color:#94a3b8;line-height:1.25;
    }

    /* Check-in list Room column — inline next to room number (cell max-height clips siblings) */
    [${w}="row"]{
      display:inline-flex;
      align-items:center;
      gap:0.2rem;
      margin:0;
      line-height:1.15;
      max-width:100%;
      vertical-align:middle;
      flex-shrink:0;
    }
    [${w}="row"] .pb-ra-row-code{
      appearance:none;cursor:pointer;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:0.75rem;font-weight:700;letter-spacing:.03em;
      color:#0f172a;
      background:#dbeafe;
      border:1px solid #3b82f6;
      border-radius:0.25rem;
      padding:0.12rem 0.4rem;
      white-space:nowrap;
    }
    [${w}="row"] .pb-ra-row-code:hover{filter:brightness(0.97);}
    [${w}="row"] .pb-ra-row-hint{
      font-size:0.6rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;
      color:#3b82f6;
    }
  `)}function Tn(e){var o;let t=document.getElementById(f);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=f,t.setAttribute(w,"detail"),t.setAttribute("role","region"),t.setAttribute("aria-label",h.emmaRoom.title);const n=e.querySelector(".sapMInputBaseContentWrapper")||e.querySelector(".sapUiCompSmartFieldValue")||((o=e.querySelector("input.sapMInputBaseInner"))==null?void 0:o.parentElement);return(n==null?void 0:n.parentElement)===e||n?n.insertAdjacentElement("afterend",t):e.appendChild(t),t}function Sn(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function kn(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>'}let L=null,Q=null,v=null,M=!1,O="",J=!1;function En(e){const t=nt();if(!t)return!1;const n=t.value,o=$n(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function se(e){var a,i;if(!v)return;e.setAttribute("aria-label",h.emmaRoom.title);const t=ht(v.floor),n=O?`<div class="pb-ra-status${J?" pb-ra-warn":""}">${E(O)}</div>`:"",o=h.emmaRoom.accept,r=h.emmaRoom.edit;e.innerHTML=`<div class="pb-ra-top"><span class="pb-ra-title"><span class="pb-ra-dot" aria-hidden="true"></span>${E(h.emmaRoom.title)}</span><span class="pb-ra-badge">${E(v.label)}</span></div><div class="pb-ra-main"><div><div class="pb-ra-room">${E(v.roomNumber)}</div><div class="pb-ra-meta">${E(t)}</div></div><div class="pb-ra-actions"><button type="button" class="pb-ra-btn pb-ra-accept" title="${oe(o)}" aria-label="${oe(o)}">${Sn()}</button><button type="button" class="pb-ra-btn pb-ra-edit" title="${oe(r)}" aria-label="${oe(r)}" aria-expanded="${M}">${kn()}</button></div></div><div class="pb-ra-menu${M?"":" pb-ra-hidden"}"><button type="button" class="pb-ra-opt" data-kind="higher">${E(h.emmaRoom.higher)}</button><button type="button" class="pb-ra-opt" data-kind="lower">${E(h.emmaRoom.lower)}</button><button type="button" class="pb-ra-opt" data-kind="extra_bed">${E(h.emmaRoom.extraBed)}</button></div>`+n+`<div class="pb-ra-note">${E(h.emmaRoom.previewNote)}</div>`,(a=e.querySelector(".pb-ra-accept"))==null||a.addEventListener("click",l=>{if(l.preventDefault(),l.stopPropagation(),!v)return;const s=En(v.roomNumber);O=s?de(h.emmaRoom.applied,{room:v.roomNumber}):de(h.emmaRoom.appliedNoField,{room:v.roomNumber}),J=!s,M=!1,se(e),Y()}),(i=e.querySelector(".pb-ra-edit"))==null||i.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),M=!M,se(e)}),e.querySelectorAll(".pb-ra-opt").forEach(l=>{l.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation();const d=l.dataset.kind||"default",u=et();v=ke(u,d,(v==null?void 0:v.roomNumber)||null),O="",J=!1,M=!1,se(e)})})}function E(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function oe(e){return E(e).replace(/'/g,"&#39;")}function Bn(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function Mn(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((i,l)=>{const s=(i.textContent||"").replace(/\s+/g," ").trim().toLowerCase();(s==="room"||s==="zimmer"||s.startsWith("room ")||s.startsWith("zimmer"))&&(t=l),(s==="arrival"||s.startsWith("anreise")||s.startsWith("arrival"))&&(n=l)}),{room:t,arrival:n}}function _e(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function An(e){const t=e.querySelector('[id$="-col0"]')||e.querySelector("td.sapUiTableCellFirst");if(!t)return null;for(const n of t.querySelectorAll(".sapMText, a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o.replace(/^0+/,"")||o}return null}function Ln(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${w}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&bn(n))return G(n)}return null}function In(e){for(const o of e.querySelectorAll(".sapMText"))if(!o.closest(`[${w}]`)&&o.parentElement)return o.parentElement;const t=e.querySelector(".sapMHBox");if(t)return t;const n=e.querySelector(".sapMVBox");return n||e.querySelector(".sapUiTableCellInner")||e}function qn(e){for(const n of e.querySelectorAll(".sapMText")){const o=(n.textContent||"").trim(),r=j(o);if(r)return r}return j((e.textContent||"").trim())}async function Rn(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}function zn(e,t,n){const o=In(e);let r=e.querySelector(`[${w}="row"]`);if(r&&r.dataset.booking===t&&r.dataset.room===n)return r.parentElement!==o&&o.appendChild(r),r;r?(r.dataset.booking=t,r.dataset.room=n,r.parentElement!==o&&o.appendChild(r)):(r=document.createElement("span"),r.setAttribute(w,"row"),r.dataset.booking=t,r.dataset.room=n,o.appendChild(r)),r.innerHTML="";const a=document.createElement("span");a.className="pb-ra-row-hint",a.textContent="→",a.setAttribute("aria-hidden","true");const i=document.createElement("button");i.type="button",i.className="pb-ra-row-code";const l=n.padStart(4,"0");return i.textContent=l,i.title=`${h.emmaRoom.title}: ${l}`,i.setAttribute("aria-label",`${h.emmaRoom.title} ${l}`),i.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),Rn(l)}),r.appendChild(a),r.appendChild(i),r}function _n(){var r;const e=Bn();if(!e){document.querySelectorAll(`[${w}="row"]`).forEach(a=>a.remove());return}const t=Mn(e),n=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),o=new Set;for(const a of n){const i=An(a);if(!i)continue;const l=_e(a,t.room),s=_e(a,t.arrival);if(!l)continue;const d=Ln(l),u=s?qn(s):null;if(d||!Ge(u)){(r=l.querySelector(`[${w}="row"]`))==null||r.remove();continue}const b=ke(i,"default",null),C=zn(l,i,b.roomNumber);o.add(C)}e.querySelectorAll(`[${w}="row"]`).forEach(a=>{a instanceof HTMLElement&&!o.has(a)&&a.remove()})}function ge(){var e;(e=document.getElementById(f))==null||e.remove(),L=null,v=null,M=!1,O="",J=!1}async function Dn(){const e=et(),t=yn();if(!t||!e){ge();return}if(!xn()){ge();return}const n=Tn(t),o=`${e}:empty`;if(o!==L||!v||!n.querySelector(".pb-ra-room")){const r=!L||!L.startsWith(`${e}:`);L=o,(r||!v)&&(M=!1,O="",J=!1,v=ke(e,"default",null)),se(n)}}async function ot(){if(!fn()){ge(),document.querySelectorAll(`[${w}="row"]`).forEach(e=>e.remove());return}Cn(),_n(),await Dn()}function Y(){Q&&window.clearTimeout(Q),Q=window.setTimeout(()=>{ot()},350)}function Hn(){ee().then(t=>{h=T(t),L=null,Y()}),te(t=>{h=T(t),L=null,Y()}),ot(),window.addEventListener("hashchange",()=>{L=null,v=null,Y()});const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(!(o instanceof Element&&(o.id===f||o.id===be||o.closest(`[${w}]`)))){Y();return}}});return e.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var t;e.disconnect(),Q&&window.clearTimeout(Q),ge(),document.querySelectorAll(`[${w}="row"]`).forEach(n=>n.remove()),(t=document.getElementById(be))==null||t.remove()}}const De="prize-panel-host";let A=T("de");function rt(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function le(e,t,n){const o=`${ce}px 0 0 ${ce}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=rt(),t.title=A.inject.openPanel,t.setAttribute("aria-label",A.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${Pe}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=A.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function He(e,t,n){var i;const r=!await we(I.panelCollapsed);await lt({[I.panelCollapsed]:r}),le(e,t,r);const a=e.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?U.collapsed:U.expanded},"*")}function Fe(){if(document.getElementById(De))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${ce}px 0 0 ${ce}px`,r=document.createElement("div");r.id=De,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${it}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:re,border:`1px solid ${ye}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=A.inject.panelTitle,Object.assign(i.style,{width:`${Pe}px`,height:"100%",border:"none",display:"block",background:re}),a.appendChild(i);const l=document.createElement("button");l.id="prize-panel-tab",l.type="button",Object.assign(l.style,{width:`${Me}px`,height:`${st}px`,minWidth:`${Me}px`,border:`1px solid ${ye}`,borderRight:"none",background:`linear-gradient(180deg, ${re} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),l.innerHTML=rt(),l.addEventListener("mouseenter",()=>{l.style.filter="brightness(1.12)"}),l.addEventListener("mouseleave",()=>{l.style.filter=""}),l.addEventListener("click",()=>{He(a,l)}),r.appendChild(a),r.appendChild(l),document.documentElement.appendChild(r),we(I.panelCollapsed).then(s=>{t=s,le(a,l,s)}),window.addEventListener("message",s=>{var d,u,b,C;((d=s.data)==null?void 0:d.type)===U.toggle&&He(a,l),((u=s.data)==null?void 0:u.type)===U.chatOpen&&(e=!0,n()&&((b=document.getElementById("prize-panel-chat-toast"))==null||b.remove())),((C=s.data)==null?void 0:C.type)===U.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((s,d)=>{d==="local"&&s[I.panelCollapsed]&&(t=!!s[I.panelCollapsed].newValue)}),Et(n),Ot(),pn(),Hn(),ee().then(s=>{A=T(s),le(a,l,t),i.title=A.inject.panelTitle}),te(s=>{A=T(s),le(a,l,t),i.title=A.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Fe):Fe();
