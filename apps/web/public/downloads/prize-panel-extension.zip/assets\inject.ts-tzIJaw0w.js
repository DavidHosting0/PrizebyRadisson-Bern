import{b as ye,S as L,P as N,c as oe,d as be,A as et,e as le,f as tt,g as _e,T as Te,h as nt,s as ot}from"./storage-DTWcLCTt.js";import{l as J,w as ee,i as ce,g as T,a as ze,b as De,p as He,c as ve,d as rt,t as Se,B as at,e as it,f as st}from"./bernticket-api-DAinuR-j.js";const he=[[101,124],[201,224],[301,324],[401,424],[501,524],[601,624],[701,718]];function lt(e){const t=parseInt(e,10);return Number.isFinite(t)?t%100===13:!0}function ct(e){if(lt(e))return null;const t=parseInt(e,10);if(!Number.isFinite(t))return null;if(t>=1&&t<=17)return-1;if(t>=21&&t<=37)return 0;for(let n=1;n<=he.length;n++){const[o,r]=he[n-1];if(t>=o&&t<=r)return n}return null}function dt(){const e=[];for(let t=1;t<=17;t++)t%100!==13&&e.push(String(t));for(let t=21;t<=37;t++)e.push(String(t));for(const[t,n]of he)for(let o=t;o<=n;o++)o%100!==13&&e.push(String(o));return e}function ut(e,t){const n=parseInt(e,10),o=parseInt(t,10),r=Number.isFinite(n),a=Number.isFinite(o);return r&&a?n-o:r&&!a?-1:!r&&a?1:e.localeCompare(t)}function pt(e){return e==null?"—":e===-2?"Lobby":e===-1?"Floor -1":e===8?"Rooftop Bar":`Floor ${e}`}let Y=T("de");const S="prize-panel-chat-toast",ke="prize-panel-chat-toast-style",mt=8e3,ft=7e3;function bt(e){return/\/(?:r|s|h|t)(?:\/m)?\/chat(?:\/|$)/.test(e)}function ht(e){return e==="/r"||e.startsWith("/r/")}function gt(e,t=72){const n=e.replace(/\s+/g," ").trim();return n.length<=t?n:`${n.slice(0,t-1)}…`}function yt(){if(document.getElementById(ke))return;const e=document.createElement("style");e.id=ke,e.textContent=`
    @keyframes prize-chat-toast-in {
      from { opacity: 0; transform: translateY(14px) scale(.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes prize-chat-toast-out {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(10px) scale(.96); }
    }
    #${S}{
      position:fixed;left:16px;bottom:16px;z-index:2147483647;
      width:min(320px,calc(100vw - 32px));
      display:flex;align-items:flex-start;gap:10px;
      padding:12px 12px 12px 10px;
      border-radius:16px;
      background:linear-gradient(180deg, ${oe} 0%, #141c28 100%);
      color:#f8fafc;
      border:1px solid ${be};
      box-shadow:0 12px 32px rgba(15,23,42,.38), 0 0 0 1px rgba(255,255,255,.04) inset;
      font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
      font-size:13px;line-height:1.35;
      pointer-events:auto;
      animation:prize-chat-toast-in .28s cubic-bezier(.22,1,.36,1) both;
    }
    #${S}.prize-chat-toast-leave{
      animation:prize-chat-toast-out .22s ease forwards;
    }
    #${S} .pb-ct-logo{
      width:28px;height:28px;flex-shrink:0;object-fit:contain;
      filter:brightness(0) invert(1);margin-top:1px;
    }
    #${S} .pb-ct-body{min-width:0;flex:1;}
    #${S} .pb-ct-eyebrow{
      font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
      color:${et};margin-bottom:2px;
    }
    #${S} .pb-ct-title{
      font-weight:600;color:#fff;margin-bottom:2px;
    }
    #${S} .pb-ct-preview{
      color:#94a3b8;word-break:break-word;font-size:12px;
    }
    #${S} .pb-ct-close{
      appearance:none;border:none;background:transparent;color:#94a3b8;
      cursor:pointer;font-size:18px;line-height:1;padding:0 2px;flex-shrink:0;
      border-radius:6px;
    }
    #${S} .pb-ct-close:hover{color:#fff;background:rgba(255,255,255,.08);}
  `,document.documentElement.appendChild(e)}let re=null;function _(e=!0){const t=document.getElementById(S);if(t){if(re&&(window.clearTimeout(re),re=null),!e){t.remove();return}t.classList.add("prize-chat-toast-leave"),window.setTimeout(()=>t.remove(),220)}}function vt(){try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;const t=new e,n=t.currentTime,o=t.createGain();o.gain.setValueAtTime(1e-4,n),o.gain.exponentialRampToValueAtTime(.1,n+.02),o.gain.exponentialRampToValueAtTime(1e-4,n+.42),o.connect(t.destination);const r=(a,i,l)=>{const s=t.createOscillator(),c=t.createGain();s.type="sine",s.frequency.setValueAtTime(a,i),c.gain.setValueAtTime(1e-4,i),c.gain.exponentialRampToValueAtTime(.9,i+.015),c.gain.exponentialRampToValueAtTime(1e-4,i+l),s.connect(c),c.connect(o),s.start(i),s.stop(i+l+.02)};r(784,n,.14),r(1046.5,n+.12,.22),window.setTimeout(()=>{t.close()},600)}catch{}}function xt(e,t){yt(),_(!1);const n=document.createElement("div");n.id=S,n.setAttribute("role","status"),n.setAttribute("aria-live","polite");const o=document.createElement("img");o.className="pb-ct-logo",o.alt="",o.src=chrome.runtime.getURL("PrizeByRadisson.png");const r=document.createElement("div");r.className="pb-ct-body",r.innerHTML='<div class="pb-ct-eyebrow"></div><div class="pb-ct-title"></div><div class="pb-ct-preview"></div>';const a=r.querySelector(".pb-ct-eyebrow"),i=r.querySelector(".pb-ct-title"),l=r.querySelector(".pb-ct-preview");a.textContent=Y.toast.eyebrow,i.textContent=ce(Y.toast.newMessageFrom,{author:e}),l.textContent=gt(t);const s=document.createElement("button");s.type="button",s.className="pb-ct-close",s.setAttribute("aria-label",Y.toast.close),s.textContent="×",s.addEventListener("click",c=>{c.stopPropagation(),_(!0)}),n.addEventListener("click",()=>_(!0)),n.appendChild(o),n.appendChild(r),n.appendChild(s),document.documentElement.appendChild(n),vt(),re=window.setTimeout(()=>{_(!0)},ft)}function wt(){return new Promise(e=>{try{chrome.runtime.sendMessage({type:N.latestChat},t=>{if(chrome.runtime.lastError){e({ok:!1});return}e(t??{ok:!1})})}catch{e({ok:!1})}})}function $t(e){let t=!1,n=null,o=!0;J().then(l=>{Y=T(l)});const r=ee(l=>{Y=T(l)});ye(L.chatNotificationsEnabled,!0).then(l=>{o=l});try{chrome.storage.onChanged.addListener((l,s)=>{if(s==="local"&&l[L.chatNotificationsEnabled]){const c=l[L.chatNotificationsEnabled].newValue;o=c===void 0?!0:!!c,o||_(!1)}})}catch{}const a=async()=>{var l,s,c;if(!t)try{if(!o)return;const p=await wt();if(!p.ok)return;const b=p.msg;if(!(b!=null&&b.id))return;if(n===null){n=b.id;return}if(b.id===n||(n=b.id,(l=b.author)!=null&&l.id&&p.meId&&b.author.id===p.meId)||e()||bt(window.location.pathname)||ht(window.location.pathname))return;const C=((c=(s=b.author)==null?void 0:s.name)==null?void 0:c.trim())||"Team";xt(C,b.body??"")}catch{}};a();const i=window.setInterval(()=>{a()},mt);return()=>{t=!0,window.clearInterval(i),r(),_(!1)}}const Ct={jan:"01",january:"01",feb:"02",february:"02",mar:"03",march:"03",apr:"04",april:"04",may:"05",jun:"06",june:"06",jul:"07",july:"07",aug:"08",august:"08",sep:"09",sept:"09",september:"09",oct:"10",october:"10",nov:"11",november:"11",dec:"12",december:"12"};function O(e){const t=e.trim().replace(/\s+/g," ");if(!t)return null;const n=t.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);if(n)return`${n[1]}-${n[2]}-${n[3]}`;const o=t.match(/\b(\d{1,2})\.(\d{1,2})\.(20\d{2})\b/);if(o)return`${o[3]}-${o[2].padStart(2,"0")}-${o[1].padStart(2,"0")}`;const r=t.match(/(?:[A-Za-z]{3,9},?\s+)?([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(20\d{2})\b/);if(r){const i=Ct[r[1].toLowerCase()];if(i)return`${r[3]}-${i}-${r[2].padStart(2,"0")}`}const a=Date.parse(t);if(!Number.isNaN(a)){const i=new Date(a),l=i.getFullYear(),s=String(i.getMonth()+1).padStart(2,"0"),c=String(i.getDate()).padStart(2,"0");if(l>=2e3)return`${l}-${s}-${c}`}return null}function Fe(){const e=new Date,t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Tt(){const e=new Date;e.setDate(e.getDate()+1);const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),o=String(e.getDate()).padStart(2,"0");return`${t}-${n}-${o}`}function Pe(e){if(!e)return!1;const t=/^\d{4}-\d{2}-\d{2}$/.test(e)?e:O(e);return!!(t&&t===Fe())}let u=T("de");const f="prize-bt-checkin-host",de="prize-bt-checkin-style",w="prize-bt-fallback-bar",h="prize-bt-create-dialog";function St(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function kt(){return!!document.querySelector(['[id*="CheckInList"][id*="checkInList.table"]','[id*="tms.checkInList.table"]','[id*="RoomStatus"]','[id*="room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2",'[id*="zey_rs_room_status"]'].join(", "))}function Et(){const e=`${window.location.hash}
${window.location.href}
${document.title}`,t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const r of t){const a=e.match(r);if(a)return a[1].replace(/^0+/,"")||a[1]}if(kt())return null;for(const r of document.querySelectorAll("a.sapMLnk, span.sapMText, span.sapMObjStatusText, .sapMTitle, .sapMObjStatusTitle")){const a=(r.textContent||"").trim();if(/^\d{6,}$/.test(a))return a.replace(/^0+/,"")||a}const n=document.querySelector(".sapUxAPObjectPageHeaderContent .sapMTitle, .sapFDynamicPageTitleMain .sapMTitle, .sapFDynamicPageTitleMainHeading .sapMTitle"),o=((n==null?void 0:n.textContent)||"").match(/\b(\d{6,})\b/);return o?o[1].replace(/^0+/,"")||o[1]:null}function Ne(){const e=['[id$="tms.checkinToolbar"]','[id*="tms.checkinToolbar"]','[id*="CheckInDetail"][id*="checkinToolbar" i]','[id*="CheckInDetail"][id*="CheckinToolbar" i]','[id*="checkinToolbar"]'];for(const t of e)try{const n=document.querySelector(t);if(n)return n}catch{}return null}function xe(){return document.querySelector('[id$="tms.checkinheaderContent"]')||document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="CheckInDetail"][id*="headerContent"]')}function z(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const l=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"], textarea');for(const s of l)if(o.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING){const p=(s instanceof HTMLInputElement||s instanceof HTMLTextAreaElement?s.value:s.textContent||"").trim();if(p&&!t.test(p))return p}a=a.parentElement}}return null}function Bt(){const e=xe()||document.body,t=z(e,/^Arrival\s*Date$/i)||z(e,/^Anreise(datum)?$/i),n=z(e,/^Departure\s*Date$/i)||z(e,/^Abreise(datum)?$/i),o=t&&O(t)||Fe(),r=n&&O(n)||Tt();return{from:o,to:r}}function Mt(){const e=xe()||document.body,t=document.querySelector('[id*="FolioPaxTypes"]')||e;let n=0,o=!1;for(const r of[/^AD$/i,/^CH$/i,/^IN$/i,/^Adults?$/i,/^Children$/i,/^Infants?$/i]){const a=z(t,r);if(a==null)continue;const i=parseInt(a.replace(/[^\d]/g,""),10);Number.isNaN(i)||(n+=i,o=!0)}if(!o)for(const r of t.querySelectorAll('.numPax input, [class*="numPax"] input')){const a=parseInt((r.value||"").trim(),10);Number.isNaN(a)||(n+=a,o=!0)}return Math.max(1,o?n:1)}function It(){const e=xe()||document.body;for(const n of[/^Guest\s*Name$/i,/^Guest$/i,/^Name$/i,/^Primary\s*Guest$/i,/^Gast(name)?$/i]){const o=z(e,n);if(o&&o.length>=2&&/[A-Za-zÄÖÜäöü]/.test(o))return o.replace(/\s+/g," ").trim()}for(const n of['[id*="guestName" i] input','[id*="GuestName" i] input','[id*="guest.name" i] input','[id*="profile.name" i] .sapMText','[id*="GuestProfile"] .sapMTitle','[id*="guest"] .sapMTitle'])try{const o=document.querySelector(n);if(!o)continue;const r=o instanceof HTMLInputElement?o.value.trim():(o.textContent||"").trim();if(r.length>=3&&/[A-Za-zÄÖÜäöü]/.test(r)&&!/^\d+$/.test(r))return r.replace(/\s+/g," ")}catch{}const t=[...document.querySelectorAll([".sapUxAPObjectPageHeaderContent .sapMTitle",".sapFDynamicPageTitleMainHeading .sapMTitle",".sapFDynamicPageTitleMain .sapMTitle",'[id*="CheckInDetail"] .sapMTitle',".sapMObjStatusTitle","a.sapMLnk"].join(", "))];for(const n of t){const o=(n.textContent||"").trim().replace(/\s+/g," ");if(o.length>=3&&o.length<90&&/[A-Za-zÄÖÜäöü]/.test(o)&&!/check.?in|please|complete|reservation|zimmer|room|folio|arrival|departure|pax|nights/i.test(o)&&!/^\d+$/.test(o)&&(/,/.test(o)||/\s/.test(o)))return o}return""}function Lt(e){const t=Bt();return{guestName:It(),bookingNumber:e,from:t.from,to:t.to,ticketsAmount:Mt()}}function At(){const e=document.getElementById(de);e&&e.remove();const t=document.createElement("style");t.id=de,t.textContent=`
    /* Center BernTicket in the toolbar flex spacer */
    .sapMTBSpacer:has(#${f}),
    .sapMTBSpacerFlex:has(#${f}){
      display:flex !important;
      align-items:center !important;
      justify-content:center !important;
      min-width:0 !important;
    }

    /* Native-looking toolbar child — no extension “card” chrome */
    #${f}.sapMBarChild,
    #${f}{
      box-sizing:border-box;
      display:inline-flex !important;
      align-items:center !important;
      justify-content:center !important;
      gap:0.5rem !important;
      margin:0 !important;
      padding:0 !important;
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
      border-radius:0 !important;
      max-width:none !important;
      flex:0 0 auto !important;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);
      color:var(--sapContent_LabelColor,#6a6d70);
      vertical-align:middle;
      white-space:nowrap;
      pointer-events:auto;
      z-index:1;
    }
    #${f} *{box-sizing:border-box;}
    #${f} .pb-bt-label{
      font-family:inherit;font-size:inherit;font-weight:normal;
      color:var(--sapContent_LabelColor,#6a6d70);
      margin:0;padding:0;border:0;background:transparent;
    }
    #${f} .pb-bt-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:var(--sapFontSize,0.875rem);font-weight:700;
      letter-spacing:.04em;line-height:1.2;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.25rem;
      padding:0.35rem 0.6rem;
      min-width:0;text-align:center;
    }
    #${f} .pb-bt-code:hover{
      filter:brightness(0.97);
    }
    #${f} .pb-bt-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    #${f} .pb-bt-muted{
      font-size:inherit;color:var(--sapContent_LabelColor,#6a6d70);
    }
    /* SAP-like ghost / default toolbar button */
    #${f} .pb-bt-btn{
      appearance:none;cursor:pointer;
      font-family:inherit;font-size:inherit;font-weight:600;
      height:2.25rem;padding:0 0.75rem;
      border-radius:0.375rem;
      border:1px solid var(--sapButton_Lite_BorderColor,#0854a0);
      background:var(--sapButton_Lite_Background,transparent);
      color:var(--sapButton_Lite_TextColor,#0854a0);
    }
    #${f} .pb-bt-btn:hover{
      background:var(--sapButton_Lite_Hover_Background,#ebf5fe);
    }
    #${f} .pb-bt-btn:disabled{opacity:.5;cursor:not-allowed}

    /* Compact bottom chip when check-in toolbar is absent (e.g. reservation detail) */
    #${w}{
      position:fixed;left:50%;bottom:0.65rem;transform:translateX(-50%);
      z-index:2147483000;
      display:inline-flex;align-items:center;gap:0.35rem;
      padding:0.2rem 0.45rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.75rem;
      line-height:1.2;
      color:#6a6d70;
      background:rgba(255,255,255,.96);
      border:1px solid #d9d9d9;
      border-radius:0.25rem;
      box-shadow:0 0.1rem 0.35rem rgba(0,0,0,.1);
      pointer-events:auto;
      white-space:nowrap;
    }
    #${w} .pb-bt-label{font-size:inherit;color:#6a6d70;}
    #${w} .pb-bt-muted{font-size:inherit;color:#6a6d70;}
    #${w} .pb-bt-code{
      appearance:none;cursor:pointer;font-weight:700;letter-spacing:.04em;
      font-size:0.75rem;line-height:1.2;
      color:#aa0808;background:#ffebeb;border:1px solid #f5c1c1;
      border-radius:0.2rem;padding:0.15rem 0.4rem;
    }
    #${w} .pb-bt-code.pb-bt-copied-flash{
      color:#256f3a;background:#f5fae5;border-color:#99cc33;
    }
    #${w} .pb-bt-btn{
      appearance:none;cursor:pointer;font-weight:600;
      font-size:0.75rem;height:1.55rem;padding:0 0.5rem;border-radius:0.25rem;
      border:1px solid #0854a0;background:transparent;color:#0854a0;
    }

    /* Create dialog — Fiori-like modal, not toolbar cramped form */
    #${h}{
      position:fixed;inset:0;z-index:2147483646;
      display:flex;align-items:center;justify-content:center;
      padding:1rem;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
    }
    #${h} .pb-bt-dlg-backdrop{
      position:absolute;inset:0;background:rgba(0,0,0,.45);
    }
    #${h} .pb-bt-dlg{
      position:relative;z-index:1;
      width:min(420px,100%);
      background:var(--sapGroup_ContentBackground,#fff);
      border:1px solid var(--sapGroup_ContentBorderColor,#d9d9d9);
      border-radius:0.5rem;
      box-shadow:0 0.625rem 1.875rem rgba(0,0,0,.25);
      overflow:hidden;
      color:var(--sapTextColor,#32363a);
    }
    #${h} .pb-bt-dlg-head{
      display:flex;align-items:center;justify-content:space-between;
      gap:0.75rem;padding:0.75rem 1rem;
      background:var(--sapPageHeader_Background,#fff);
      border-bottom:1px solid var(--sapPageHeader_BorderColor,#d9d9d9);
    }
    #${h} .pb-bt-dlg-head h2{
      margin:0;font-size:1rem;font-weight:700;color:var(--sapPageHeader_TextColor,#32363a);
    }
    #${h} .pb-bt-dlg-x{
      appearance:none;border:0;background:transparent;cursor:pointer;
      font-size:1.25rem;line-height:1;color:#6a6d70;padding:0.15rem 0.35rem;
    }
    #${h} .pb-bt-dlg-body{padding:1rem;display:flex;flex-direction:column;gap:0.75rem;}
    #${h} .pb-bt-dlg-field{display:flex;flex-direction:column;gap:0.25rem;}
    #${h} .pb-bt-dlg-field label{
      font-size:0.75rem;font-weight:600;color:var(--sapContent_LabelColor,#6a6d70);
    }
    #${h} .pb-bt-dlg-field input{
      height:2.25rem;padding:0 0.5rem;font-size:0.875rem;
      border:1px solid var(--sapField_BorderColor,#89919a);
      border-radius:0.25rem;background:var(--sapField_Background,#fff);
      color:var(--sapField_TextColor,#32363a);
    }
    #${h} .pb-bt-dlg-row{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
    #${h} .pb-bt-dlg-err{font-size:0.8125rem;color:#aa0808;}
    #${h} .pb-bt-dlg-foot{
      display:flex;justify-content:flex-end;gap:0.5rem;
      padding:0.75rem 1rem;border-top:1px solid #d9d9d9;
      background:#f7f7f7;
    }
    #${h} .pb-bt-dlg-foot .pb-bt-btn-ghost{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #0854a0;background:#fff;color:#0854a0;
    }
    #${h} .pb-bt-dlg-foot .pb-bt-btn-accept{
      appearance:none;cursor:pointer;height:2.25rem;padding:0 0.9rem;
      border-radius:0.375rem;font-weight:600;font-size:0.875rem;
      border:1px solid #256f3a;background:#256f3a;color:#fff;
    }
    #${h} .pb-bt-dlg-foot .pb-bt-btn-accept:disabled{opacity:.55;cursor:not-allowed;}
  `,document.documentElement.appendChild(t)}function D(){var e;(e=document.getElementById(h))==null||e.remove()}function Rt(e){var o,r;(o=document.getElementById(w))==null||o.remove();let t=document.getElementById(f);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=f,t.setAttribute("data-prize-bernticket","1"),t.setAttribute("role","region"),t.setAttribute("aria-label",u.emmaBt.brand);const n=e.querySelector(".sapMTBSpacer.sapMTBSpacerFlex")||e.querySelector(".sapMTBSpacer");if(n)n.appendChild(t);else{t.className="sapMBarChild";const a=((r=e.querySelector(".sapMBtnAccept"))==null?void 0:r.closest(".sapMBtn, button"))||[...e.querySelectorAll("button.sapMBtn, .sapMBtn")].find(i=>/check\s*in/i.test(i.textContent||""));a&&a.parentElement===e?e.insertBefore(t,a):e.appendChild(t)}return t}function qt(){var t;(t=document.getElementById(f))==null||t.remove();let e=document.getElementById(w);return e||(e=document.createElement("div"),e.id=w,e.setAttribute("data-prize-bernticket","1"),e.setAttribute("role","region"),e.setAttribute("aria-label",u.emmaBt.brand),document.documentElement.appendChild(e),e)}function A(e,t){e.innerHTML=t}function R(e){return`<span class="pb-bt-label">${y(u.emmaBt.brand)}</span>${e}`}async function _t(e){try{await navigator.clipboard.writeText(e)}catch{}}function Ee(e,t){const n=e.querySelector(".pb-bt-code");n==null||n.addEventListener("click",()=>{_t(t).then(()=>{if(!n.isConnected)return;const o=n.textContent;n.textContent=u.emmaBt.copied,n.classList.add("pb-bt-copied-flash"),window.setTimeout(()=>{n.isConnected&&(n.textContent=o,n.classList.remove("pb-bt-copied-flash"))},1e3)})})}function zt(e,t,n,o){D();const r=document.createElement("div");r.id=h,r.setAttribute("data-prize-bernticket","1"),r.innerHTML=`<div class="pb-bt-dlg-backdrop" data-close="1"></div><div class="pb-bt-dlg" role="dialog" aria-modal="true" aria-label="${E(u.emmaBt.createDialogTitle)}"><div class="pb-bt-dlg-head"><h2>${y(u.emmaBt.createDialogTitle)}</h2><button type="button" class="pb-bt-dlg-x" data-close="1" aria-label="${E(u.emmaBt.cancel)}">×</button></div><div class="pb-bt-dlg-body"><div class="pb-bt-dlg-field"><label>${y(u.emmaBt.bookingLabel)}</label><input class="pb-bt-dlg-booking" value="${E(n.bookingNumber)}" readonly /></div><div class="pb-bt-dlg-field"><label>${y(u.emmaBt.guestNamePlaceholder)}</label><input class="pb-bt-dlg-name" value="${E(n.guestName)}" /></div><div class="pb-bt-dlg-row"><div class="pb-bt-dlg-field"><label>${y(u.emmaBt.arrival)}</label><input class="pb-bt-dlg-from" type="date" value="${E(n.from)}" /></div><div class="pb-bt-dlg-field"><label>${y(u.emmaBt.departure)}</label><input class="pb-bt-dlg-to" type="date" value="${E(n.to)}" /></div></div><div class="pb-bt-dlg-field"><label>${y(u.emmaBt.persons)}</label><input class="pb-bt-dlg-amt" type="number" min="1" value="${n.ticketsAmount}" /></div><div class="pb-bt-dlg-err" hidden></div></div><div class="pb-bt-dlg-foot"><button type="button" class="pb-bt-btn-ghost" data-close="1">${y(u.emmaBt.cancel)}</button><button type="button" class="pb-bt-btn-accept pb-bt-dlg-submit">${y(u.emmaBt.create)}</button></div></div>`,document.documentElement.appendChild(r);const a=r.querySelector(".pb-bt-dlg-err"),i=r.querySelector(".pb-bt-dlg-submit");r.querySelectorAll('[data-close="1"]').forEach(s=>{s.addEventListener("click",()=>D())});const l=s=>{s.key==="Escape"&&(D(),window.removeEventListener("keydown",l))};window.addEventListener("keydown",l),i.addEventListener("click",()=>{(async()=>{const s=r.querySelector(".pb-bt-dlg-name"),c=r.querySelector(".pb-bt-dlg-from"),p=r.querySelector(".pb-bt-dlg-to"),b=r.querySelector(".pb-bt-dlg-amt"),C=(s==null?void 0:s.value.trim())||"";if(!C){a.hidden=!1,a.textContent=u.emmaBt.guestNameMissing;return}i.disabled=!0,i.textContent=u.common.ellipsis,a.hidden=!0;try{const q=await rt({guestName:C,bookingNumber:t,validFrom:Se((c==null?void 0:c.value)||n.from),validTo:Se((p==null?void 0:p.value)||n.to),ticketsAmount:Math.max(1,parseInt((b==null?void 0:b.value)||String(n.ticketsAmount),10)||n.ticketsAmount)});D(),o(ve(q))}catch(q){if(q instanceof at&&q.code===it){const $e=window.prompt(u.emmaBt.twoFaPrompt);if($e)try{await st($e),i.disabled=!1,i.textContent=u.emmaBt.create,i.click();return}catch(Ce){a.hidden=!1,a.textContent=Ce instanceof Error?Ce.message:u.emmaBt.twoFaFailed,i.disabled=!1,i.textContent=u.emmaBt.create;return}}a.hidden=!1,a.textContent=q instanceof Error?q.message:u.emmaBt.error,i.disabled=!1,i.textContent=u.emmaBt.create}})()})}let x=null,K=null,te=0;async function ge(e,t,n){var a,i;const o=++te,r=await ze();if(o===te){if(!r.access){A(e,R(`<span class="pb-bt-muted">${y(u.emmaBt.loginHint)}</span>`));return}A(e,R(`<span class="pb-bt-muted">${y(u.emmaBt.loading)}</span>`));try{const l=await De(t);if(o!==te)return;const s=He(l,t),c=ve(s),p=u.bernticket.copyCode;if(s&&c){A(e,R(`<button type="button" class="pb-bt-code" title="${E(p)}">${y(c)}</button>`)),Ee(e,c);return}if(s&&!c){const C=ce(u.emmaBt.noCode,{status:s.status});A(e,R(`<span class="pb-bt-muted">${y(C)}</span>`));return}const b=Lt(t);A(e,R(`<button type="button" class="pb-bt-btn pb-bt-open-create">${y(u.emmaBt.openCreate)}</button>`)),(a=e.querySelector(".pb-bt-open-create"))==null||a.addEventListener("click",()=>{zt(e,t,b,C=>{C?(A(e,R(`<button type="button" class="pb-bt-code" title="${E(p)}">${y(C)}</button>`)),Ee(e,C)):(x=null,ge(e,t,!0))})})}catch(l){if(o!==te)return;A(e,R(`<span class="pb-bt-muted">${y(l instanceof Error?l.message:u.emmaBt.error)}</span><button type="button" class="pb-bt-btn pb-bt-retry">${y(u.emmaBt.retry)}</button>`)),(i=e.querySelector(".pb-bt-retry"))==null||i.addEventListener("click",()=>{x=null,ge(e,t)})}}}function y(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function E(e){return y(e).replace(/'/g,"&#39;")}function U(){K&&window.clearTimeout(K),K=window.setTimeout(()=>{je()},350)}function Oe(e){return document.documentElement.contains(e)}async function je(){var r,a,i,l;if(!St()){(r=document.getElementById(f))==null||r.remove(),(a=document.getElementById(w))==null||a.remove(),D(),x=null;return}At();const e=Et(),t=Ne();if(!e){(i=document.getElementById(f))==null||i.remove(),(l=document.getElementById(w))==null||l.remove(),x=null;return}const n=t?f:w,o=t?Rt(t):qt();if(e===x&&o.dataset.bound===e&&o.id===n&&Oe(o))if(t&&!t.contains(o))x=null;else return;x=e,o.dataset.bound=e,await ge(o,e)}function Dt(){J().then(t=>{u=T(t),x=null,U()}),ee(t=>{u=T(t),x=null,U()}),je(),window.addEventListener("hashchange",()=>{x=null,U()});const e=new MutationObserver(t=>{let n=!1;for(const a of t){const i=a.target;if(!(i instanceof Element&&(i.id===f||i.id===w||i.id===de||i.id===h||i.closest("[data-prize-bernticket]")))){n=!0;break}}if(!n)return;const o=Ne(),r=document.getElementById(f)||document.getElementById(w);r&&!Oe(r)&&(x=null),o&&(r==null?void 0:r.id)===f&&!o.contains(r)&&(x=null),o&&(r==null?void 0:r.id)===w&&(x=null),!o&&(r==null?void 0:r.id)===f&&(x=null),o&&!r&&(x=null),U()});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(x=null,U())})}catch{}return()=>{var t,n,o;e.disconnect(),K&&window.clearTimeout(K),(t=document.getElementById(f))==null||t.remove(),(n=document.getElementById(w))==null||n.remove(),(o=document.getElementById(de))==null||o.remove(),D()}}const Ge=300*1e3,H=new Map,ae=new Map;function Ue(e){return e.replace(/^0+/,"")||e}function Be(e){const t=H.get(e);return!t||Date.now()-t.at>=Ge?null:{code:t.code}}function Ht(){H.clear(),ae.clear()}async function Ft(e){const t=Ue(e),n=H.get(t);if(n&&Date.now()-n.at<Ge)return n.code;let o=ae.get(t);return o||(o=(async()=>{try{const r=await ze();if(!(r!=null&&r.access))return H.set(t,{code:null,at:Date.now()}),null;const a=await De(t),i=He(a,t),l=ve(i);return H.set(t,{code:l,at:Date.now()}),l}catch{return H.set(t,{code:null,at:Date.now()}),null}finally{ae.delete(t)}})(),ae.set(t,o)),o}async function Pt(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}let j=T("de");const ue="prize-bt-list-style",d="data-prize-bt-chip";let X=null;function Nt(){return document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Ot(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function jt(){const e=new Set,t=[".sapMGT.roomTiles",".sapMGT.roomTiles2",'.sapMGT[id*="roomstatus.roomsHBox"]','.sapMGT[id*="RoomStatus"][id*="roomsHBox"]','[id*="zey_rs_room_status"] .sapMGT','[id*="---RoomStatus--"] .sapMGT','[id*="RoomStatus--roomstatus"] .sapMGT'];for(const n of t)try{for(const o of document.querySelectorAll(n)){const r=o.classList.contains("sapMGT")?o:o.closest(".sapMGT");r&&e.add(r)}}catch{}return[...e]}function Gt(){let e=document.getElementById(ue);e||(e=document.createElement("style"),e.id=ue,document.documentElement.appendChild(e)),e.dataset.v!=="5"&&(e.dataset.v="5",e.textContent=`
    [${d}]{
      display:block !important;
      margin-top:0.12rem;
      line-height:1.15;
      max-width:100%;
      pointer-events:auto;
      z-index:5;
      position:relative;
    }
    /* Check-in list: inline next to reservation number (cell max-height clips below) */
    [${d}][data-surface="list"]{
      display:inline-flex !important;
      align-items:center;
      margin:0 0 0 0.25rem !important;
      vertical-align:middle;
      max-width:none;
      flex-shrink:0;
    }
    .sapUiTableCellInner:has([${d}]),
    .sapMVBox:has([${d}]),
    .sapMHBox:has([${d}]){
      overflow:visible !important;
    }
    /* Room Status: chip on tile root so SAP content re-renders do not wipe it */
    .sapMGT.roomTiles,
    .sapMGT.roomTiles2,
    .sapMGT[id*="roomsHBox"]{
      position:relative !important;
      overflow:visible !important;
    }
    [${d}][data-surface="room"]{
      position:absolute !important;
      left:0.35rem;
      bottom:0.3rem;
      margin:0 !important;
      z-index:30;
      max-width:calc(100% - 0.7rem);
    }
    [${d}] .pb-bt-list-code{
      appearance:none;cursor:pointer;
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.7rem;font-weight:700;letter-spacing:.03em;
      color:var(--sapIndicationColor_3,#aa0808);
      background:var(--sapIndicationColor_3_Background,#ffebeb);
      border:1px solid var(--sapIndicationColor_3_BorderColor,#f5c1c1);
      border-radius:0.15rem;
      padding:0.05rem 0.3rem;
      line-height:1.2;
      max-width:100%;
      white-space:nowrap;
      overflow:hidden;text-overflow:ellipsis;
    }
    [${d}] .pb-bt-list-code:hover{filter:brightness(0.97);}
    [${d}] .pb-bt-list-code.pb-bt-copied-flash{
      color:var(--sapPositiveColor,#256f3a);
      background:var(--sapPositiveBackground,#f5fae5);
      border-color:var(--sapPositiveBorderColor,#99cc33);
    }
    [${d}] .pb-bt-list-muted{
      font-family:var(--sapFontFamily,"72",Arial,Helvetica,sans-serif);
      font-size:0.65rem;color:#6a6d70;
    }
  `)}function We(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk, .sapMLabel bdi")){if(t.closest(`[${d}]`))continue;const n=(t.textContent||"").trim();if(/^\d{6,}$/.test(n))return Ue(n)}return null}function Ut(e){return We(e)}function Wt(e){const t=e.querySelector(".sapMTileCntContent")||e.querySelector(".sapMGTContent")||e.querySelector('[class*="appInfo"]')||e;return We(t)}function Vt(e,t){let n=e.querySelector(`:scope > [${d}]`);if(!n){const o=e.querySelector(`[${d}]`);o&&(n=o,e.appendChild(n))}return n?(n.dataset.booking!==t&&(n.dataset.booking=t,n.dataset.state="",n.innerHTML=""),n.dataset.surface="room",n.parentElement!==e&&e.appendChild(n),n):(n=document.createElement("div"),n.setAttribute(d,"1"),n.dataset.booking=t,n.dataset.surface="room",e.appendChild(n),n)}function Yt(e){return!!e.querySelector('.sapFAvatar, .sapMAvatar, [class*="Avatar"], .roomTitle, .sapMObjStatus')}function Kt(e){const t=/-col0$/;for(const n of e.querySelectorAll('[id*="-col"]'))if(t.test(n.id))return n;return e.querySelector("td.sapUiTableCellFirst")||e.querySelector("td.sapUiTableDataCell")}function Xt(e,t){let n=null;for(const a of e.querySelectorAll(".sapMText, a.sapMLnk"))if(!a.closest(`[${d}]`)&&/^\d{6,}$/.test((a.textContent||"").trim())){n=a;break}const o=(n==null?void 0:n.closest(".sapMHBox"))||(n==null?void 0:n.parentElement)||e.querySelector(".sapMVBox")||e.querySelector(".sapUiTableCellInner")||e;let r=e.querySelector(`[${d}]`);return r?(r.dataset.booking!==t&&(r.dataset.booking=t,r.dataset.state="",r.innerHTML=""),r.dataset.surface="list",r.parentElement!==o&&(n&&n.parentElement===o?n.insertAdjacentElement("afterend",r):o.appendChild(r)),r):(r=document.createElement("span"),r.setAttribute(d,"1"),r.dataset.booking=t,r.dataset.surface="list",n&&n.parentElement===o?n.insertAdjacentElement("afterend",r):n!=null&&n.parentElement?n.parentElement.appendChild(r):o.appendChild(r),r)}function Zt(){return!!document.querySelector('[id*="CheckInList"], [id*="checkInList.table"], [id*="tms.checkInList"]')}function Qt(e,t){e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Pt(t).then(()=>{e.classList.add("pb-bt-copied-flash");const o=e.getAttribute("title")||"";e.setAttribute("title",j.emmaBt.copied),window.setTimeout(()=>{e.classList.remove("pb-bt-copied-flash"),e.setAttribute("title",o||j.emmaBt.clickToCopy)},1200)})})}function Jt(e,t){e.setAttribute(d,"1"),e.dataset.booking=t,e.dataset.state="loading",e.innerHTML='<span class="pb-bt-list-muted">…</span>'}function Me(e,t,n){e.setAttribute(d,"1"),e.dataset.booking=t,e.dataset.state="ok",e.innerHTML="";const o=document.createElement("button");o.type="button",o.className="pb-bt-list-code",o.textContent=n,o.title=j.emmaBt.clickToCopy,o.setAttribute("aria-label",`${j.emmaBt.brand}: ${n}`),Qt(o,n),e.appendChild(o)}function Ie(e,t){e.setAttribute(d,"1"),e.dataset.booking=t,e.dataset.state="none",e.innerHTML=""}async function Ve(e,t){if(e.dataset.booking===t&&e.dataset.state==="ok")return;if(e.dataset.booking===t&&e.dataset.state==="none"){const r=Be(t);if(r&&r.code===null)return;e.dataset.state=""}const n=Be(t);if(n){n.code?Me(e,t,n.code):Ie(e,t);return}Jt(e,t);const o=await Ft(t);e.dataset.booking===t&&document.documentElement.contains(e)&&(o?Me(e,t,o):Ie(e,t))}function en(){const e=Ot();if(!e){Zt()||document.querySelectorAll(`[${d}][data-surface="list"]`).forEach(r=>r.remove());return}const t=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),n=new Set,o=new Set(t);for(const r of t){const a=Kt(r);if(!a)continue;const i=Ut(a),l=a.querySelector(`[${d}]`);if(!i){(l==null?void 0:l.dataset.state)==="ok"&&n.add(l);continue}const s=Xt(a,i);n.add(s),Ve(s,i)}document.querySelectorAll(`[${d}][data-surface="list"]`).forEach(r=>{if(n.has(r))return;const a=r.closest("tr.sapUiTableContentRow, tr.sapUiTableTr");(!a||!o.has(a))&&r.remove()})}function tn(){return!!document.querySelector(['[id*="RoomStatus"]','[id*="zey_rs_room_status"]','[id*="roomstatus.roomsHBox"]',".sapMGT.roomTiles",".sapMGT.roomTiles2"].join(", "))}function nn(){const e=jt(),t=new Set(e);if(e.length===0){tn()||document.querySelectorAll(`[${d}][data-surface="room"]`).forEach(o=>o.remove());return}const n=new Set;for(const o of e){const r=Wt(o),a=o.querySelector(`[${d}]`);if(!r){if((a==null?void 0:a.dataset.state)==="ok"&&Yt(o)){n.add(a);continue}a==null||a.remove();continue}const i=Vt(o,r);n.add(i),Ve(i,r)}document.querySelectorAll(`[${d}][data-surface="room"]`).forEach(o=>{if(n.has(o))return;const r=o.closest(".sapMGT");(!r||!t.has(r))&&o.remove()})}function Ye(){if(!Nt()){document.querySelectorAll(`[${d}]`).forEach(e=>e.remove());return}Gt(),en(),nn()}function W(){X&&window.clearTimeout(X),X=window.setTimeout(()=>{Ye()},280)}function on(){J().then(t=>{j=T(t),W()}),ee(t=>{j=T(t),document.querySelectorAll(`[${d}]`).forEach(n=>{n instanceof HTMLElement&&(n.dataset.state="")}),W()}),Ye(),window.addEventListener("hashchange",()=>W());const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(o instanceof Element&&!(o.id===ue||o.closest(`[${d}]`))&&!(n.type==="childList"&&[...n.addedNodes,...n.removedNodes].every(r=>r instanceof Element&&(r.matches(`[${d}]`)||r.closest(`[${d}]`))))){W();return}}});e.observe(document.documentElement,{childList:!0,subtree:!0});try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&(t.btAccessToken||t.btRefreshToken)&&(Ht(),document.querySelectorAll(`[${d}]`).forEach(o=>{o instanceof HTMLElement&&(o.dataset.state="")}),W())})}catch{}return()=>{var t;e.disconnect(),X&&window.clearTimeout(X),(t=document.getElementById(ue))==null||t.remove(),document.querySelectorAll(`[${d}]`).forEach(n=>n.remove())}}let g=T("de");const m="prize-ra-host",pe="prize-ra-style",$="data-prize-room-assign",F=dt().sort(ut),rn=new Set(F);function an(){return/ReservationId=/i.test(window.location.hash)||document.querySelector(".sapUiBody, .sapMShell, [data-sap-ui-area]")?!0:/emma|radisson|sapui5|fiori/i.test(window.location.hostname+window.location.href)}function Ke(){const e=window.location.hash||"",t=[/ReservationId='(\d+)'/i,/ReservationId=(\d+)/i,/reservationId[=:]['"]?(\d+)/i];for(const n of t){const o=e.match(n);if(o)return o[1].replace(/^0+/,"")||o[1]}for(const n of document.querySelectorAll('.sapMTitle, a.sapMLnk, [id*="ReservationDetail"] .sapMText, [id*="CheckInDetail"] .sapMText')){if(n.closest(`[${$}]`))continue;const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o.replace(/^0+/,"")||o}return null}function Xe(e){if(e.classList.contains("sapUiHiddenPlaceholder"))return!1;const t=e.getBoundingClientRect();return t.width>2&&t.height>2}function G(e){const t=e.replace(/[^\d]/g,"");return t?String(parseInt(t,10)):""}function sn(e){const t=G(e);return!!(t&&rn.has(t))}function ln(){var t;const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const n of e){const o=document.querySelector(n),r=(t=o==null?void 0:o.value)==null?void 0:t.trim();if(r){const a=G(r);if(a)return a}}return null}function Ze(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp-inner"]','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.checkin.roomid.valuehelp-inner"]','[id*="tms.roomid.valuehelp-inner"]','[id*="roomid.valuehelp-inner"]','[id*="roomid"] input.sapMInputBaseInner','[id*="RoomId"] input.sapMInputBaseInner'];for(const t of e){const n=document.querySelector(t);if(n&&Xe(n))return n}for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function cn(){const e=['[id*="ReservationDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.checkin.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="CheckInDetail"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id*="zey_tms_rs"][id*="tms.roomid.valuehelp"]:not([id*="message"]):not([id*="-inner"])','[id$="tms.roomid.valuehelp"]','[id$="tms.checkin.roomid.valuehelp"]'];for(const n of e){const o=document.querySelector(n);if(o&&Xe(o))return o}const t=Ze();return t?t.closest('[id*="roomid.valuehelp"]')||t.closest(".sapUiCompSmartField")||t.parentElement:null}function dn(){const e=cn();if(!e)return null;const t=e.querySelector(".sapUiCompSmartFieldValue")||e.querySelector(".sapMInputBaseContentWrapper")||e.querySelector(".sapMInput")||e;let n=t;for(let o=0;o<6&&n;o++){if(n.classList.contains("sapUiVltCell")||n.classList.contains("sapMVBox")||n.classList.contains("sapMHBox"))return n;n=n.parentElement}return t}function fe(e,t){const n=e.querySelectorAll(".sapMLabel, label, .sapMLabelTextWrapper, bdi");for(const o of n){const r=(o.textContent||"").trim().replace(/:\s*$/,"");if(!t.test(r))continue;let a=o instanceof Element?o:null;for(let i=0;i<6&&a;i++){const l=a.querySelectorAll('.sapUiCompSmartFieldValue, .sapMText, input.sapMInputBaseInner, input[type="text"]');for(const s of l)if(o.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING){const p=(s instanceof HTMLInputElement?s.value:s.textContent||"").trim();if(p&&!t.test(p))return p}a=a.parentElement}}return null}function un(){const e=[document.querySelector('[id*="CheckInDetail"]')||document.querySelector('[id*="ReservationDetail"]')||document.body],t=document.querySelector('[id*="checkinheaderContent"]')||document.querySelector('[id*="reservationheaderContent"]');t&&e.unshift(t);for(const n of e){const o=fe(n,/^Arrival\s*Date$/i)||fe(n,/^Arrival$/i)||fe(n,/^Anreise(datum)?$/i);if(!o)continue;const r=O(o);if(r)return r}return null}function pn(){if(ln())return!1;const e=un();return Pe(e)}function mn(e,t){const n=G(e);if(!n)return e;const o=t&&/^\d+$/.test(t.trim())?t.trim().length:4;return n.padStart(Math.max(o,n.length),"0")}function fn(e){const t=G(e);return F.findIndex(n=>n===t)}function we(e,t,n){const o=n?G(n):null;let r=0;if(o){const s=fn(o);s>=0&&(r=s)}else e&&(r=[...e].reduce((c,p)=>c+p.charCodeAt(0),0)%F.length);t==="higher"?r=Math.min(F.length-1,r+1):t==="lower"?r=Math.max(0,r-1):t==="extra_bed"&&(r=Math.min(F.length-1,r+2));const a=F[r]||"101",i=ct(a),l={default:g.emmaRoom.labelDefault,higher:g.emmaRoom.labelHigher,lower:g.emmaRoom.labelLower,extra_bed:g.emmaRoom.labelExtraBed};return{roomNumber:a,floor:i,kind:t,label:l[t]}}function bn(){let e=document.getElementById(pe);e||(e=document.createElement("style"),e.id=pe,document.documentElement.appendChild(e)),e.dataset.v!=="3"&&(e.dataset.v="3",e.textContent=`
    /* Detail: compact chip inline at the Room field */
    #${m}{
      box-sizing:border-box;
      display:inline-flex;
      flex-direction:column;
      gap:4px;
      margin:2px 0 0 0;
      max-width:min(200px,100%);
      font-family:var(--sapFontFamily,"72",system-ui,-apple-system,sans-serif);
      color:#0f172a;
      background:#fff;
      border:1px solid rgba(45,58,79,.16);
      border-radius:8px;
      box-shadow:0 1px 4px rgba(15,23,42,.08);
      padding:6px 8px;
      z-index:5;
      pointer-events:auto;
      vertical-align:middle;
    }
    #${m} *{box-sizing:border-box;}
    #${m} .pb-ra-top{
      display:flex;align-items:center;justify-content:space-between;gap:4px;
    }
    #${m} .pb-ra-title{
      font-size:9px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;
      color:#475569;display:inline-flex;align-items:center;gap:4px;
    }
    #${m} .pb-ra-dot{
      width:6px;height:6px;border-radius:999px;background:#3b6fa0;
    }
    #${m} .pb-ra-badge{
      font-size:8px;font-weight:600;color:#64748b;background:#eef2f7;
      border-radius:999px;padding:1px 5px;white-space:nowrap;
    }
    #${m} .pb-ra-main{
      display:flex;align-items:center;gap:6px;
    }
    #${m} .pb-ra-room{
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:16px;font-weight:800;letter-spacing:.03em;line-height:1.1;
      color:#1a2332;
    }
    #${m} .pb-ra-meta{
      font-size:9px;color:#64748b;margin-top:1px;font-weight:500;
    }
    #${m} .pb-ra-actions{
      display:flex;align-items:center;gap:3px;flex-shrink:0;margin-left:auto;
    }
    #${m} .pb-ra-btn{
      appearance:none;cursor:pointer;border:1px solid #cbd5e1;background:#fff;
      width:26px;height:26px;border-radius:7px;display:inline-flex;
      align-items:center;justify-content:center;color:#1a2332;padding:0;
    }
    #${m} .pb-ra-btn:hover{background:#f1f5f9;}
    #${m} .pb-ra-btn.pb-ra-accept{
      background:#15803d;border-color:#15803d;color:#fff;
    }
    #${m} .pb-ra-btn svg{width:13px;height:13px;display:block;}
    #${m} .pb-ra-menu{
      padding-top:4px;border-top:1px solid #e2e8f0;
      display:flex;flex-direction:column;gap:3px;
    }
    #${m} .pb-ra-menu.pb-ra-hidden{display:none;}
    #${m} .pb-ra-opt{
      appearance:none;cursor:pointer;border:1px solid #e2e8f0;background:#fff;
      border-radius:6px;padding:4px 6px;text-align:left;font-size:10px;font-weight:600;
      color:#1a2332;width:100%;
    }
    #${m} .pb-ra-status{
      font-size:9px;font-weight:600;color:#15803d;
    }
    #${m} .pb-ra-status.pb-ra-warn{color:#b45309;}
    #${m} .pb-ra-note{
      font-size:8px;color:#94a3b8;line-height:1.25;
    }

    /* Check-in list Room column — inline next to room number (cell max-height clips siblings) */
    [${$}="row"]{
      display:inline-flex;
      align-items:center;
      gap:0.2rem;
      margin:0;
      line-height:1.15;
      max-width:100%;
      vertical-align:middle;
      flex-shrink:0;
    }
    [${$}="row"] .pb-ra-row-code{
      appearance:none;cursor:pointer;
      font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
      font-size:0.75rem;font-weight:700;letter-spacing:.03em;
      color:#0f172a;
      background:#dbeafe;
      border:1px solid #3b82f6;
      border-radius:0.25rem;
      padding:0.12rem 0.4rem;
      white-space:nowrap;
    }
    [${$}="row"] .pb-ra-row-code:hover{filter:brightness(0.97);}
    [${$}="row"] .pb-ra-row-hint{
      font-size:0.6rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;
      color:#3b82f6;
    }
  `)}function hn(e){var o;let t=document.getElementById(m);if(t&&e.contains(t))return t;t==null||t.remove(),t=document.createElement("div"),t.id=m,t.setAttribute($,"detail"),t.setAttribute("role","region"),t.setAttribute("aria-label",g.emmaRoom.title);const n=e.querySelector(".sapMInputBaseContentWrapper")||e.querySelector(".sapUiCompSmartFieldValue")||((o=e.querySelector("input.sapMInputBaseInner"))==null?void 0:o.parentElement);return(n==null?void 0:n.parentElement)===e||n?n.insertAdjacentElement("afterend",t):e.appendChild(t),t}function gn(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>'}function yn(){return'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>'}let I=null,Z=null,v=null,B=!1,P="",Q=!1;function vn(e){const t=Ze();if(!t)return!1;const n=t.value,o=mn(e,n);return t.focus(),t.value=o,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0})),t.blur(),!0}function ie(e){var a,i;if(!v)return;e.setAttribute("aria-label",g.emmaRoom.title);const t=pt(v.floor),n=P?`<div class="pb-ra-status${Q?" pb-ra-warn":""}">${k(P)}</div>`:"",o=g.emmaRoom.accept,r=g.emmaRoom.edit;e.innerHTML=`<div class="pb-ra-top"><span class="pb-ra-title"><span class="pb-ra-dot" aria-hidden="true"></span>${k(g.emmaRoom.title)}</span><span class="pb-ra-badge">${k(v.label)}</span></div><div class="pb-ra-main"><div><div class="pb-ra-room">${k(v.roomNumber)}</div><div class="pb-ra-meta">${k(t)}</div></div><div class="pb-ra-actions"><button type="button" class="pb-ra-btn pb-ra-accept" title="${ne(o)}" aria-label="${ne(o)}">${gn()}</button><button type="button" class="pb-ra-btn pb-ra-edit" title="${ne(r)}" aria-label="${ne(r)}" aria-expanded="${B}">${yn()}</button></div></div><div class="pb-ra-menu${B?"":" pb-ra-hidden"}"><button type="button" class="pb-ra-opt" data-kind="higher">${k(g.emmaRoom.higher)}</button><button type="button" class="pb-ra-opt" data-kind="lower">${k(g.emmaRoom.lower)}</button><button type="button" class="pb-ra-opt" data-kind="extra_bed">${k(g.emmaRoom.extraBed)}</button></div>`+n+`<div class="pb-ra-note">${k(g.emmaRoom.previewNote)}</div>`,(a=e.querySelector(".pb-ra-accept"))==null||a.addEventListener("click",l=>{if(l.preventDefault(),l.stopPropagation(),!v)return;const s=vn(v.roomNumber);P=s?ce(g.emmaRoom.applied,{room:v.roomNumber}):ce(g.emmaRoom.appliedNoField,{room:v.roomNumber}),Q=!s,B=!1,ie(e),V()}),(i=e.querySelector(".pb-ra-edit"))==null||i.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),B=!B,ie(e)}),e.querySelectorAll(".pb-ra-opt").forEach(l=>{l.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation();const c=l.dataset.kind||"default",p=Ke();v=we(p,c,(v==null?void 0:v.roomNumber)||null),P="",Q=!1,B=!1,ie(e)})})}function k(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ne(e){return k(e).replace(/'/g,"&#39;")}function xn(){const e=['table[id*="CheckInList"][id*="checkInList.table-table"]','table[id*="tms.checkInList.table-table"]','table[id*="checkInList.table-table"]'];for(const t of e){const n=document.querySelector(t);if(n)return n}return null}function wn(e){var r;let t=1,n=7;const o=(r=e.closest(".sapUiTableCnt"))==null?void 0:r.querySelector('table.sapUiTableCHT, table[id*="-header"]');return o&&[...o.querySelectorAll('td[role="columnheader"], .sapUiTableHeaderDataCell')].forEach((i,l)=>{const s=(i.textContent||"").replace(/\s+/g," ").trim().toLowerCase();(s==="room"||s==="zimmer"||s.startsWith("room ")||s.startsWith("zimmer"))&&(t=l),(s==="arrival"||s.startsWith("anreise")||s.startsWith("arrival"))&&(n=l)}),{room:t,arrival:n}}function Le(e,t){const n=new RegExp(`-col${t}$`);for(const r of e.querySelectorAll('[id*="-col"]'))if(n.test(r.id))return r;return e.querySelectorAll("td.sapUiTableDataCell")[t]||null}function $n(e){const t=e.querySelector('[id$="-col0"]')||e.querySelector("td.sapUiTableCellFirst");if(!t)return null;for(const n of t.querySelectorAll(".sapMText, a.sapMLnk")){const o=(n.textContent||"").trim();if(/^\d{6,}$/.test(o))return o.replace(/^0+/,"")||o}return null}function Cn(e){for(const t of e.querySelectorAll(".sapMText, a.sapMLnk")){if(t.closest(`[${$}]`))continue;const n=(t.textContent||"").trim();if(/^\d{1,4}$/.test(n)&&sn(n))return G(n)}return null}function Tn(e){for(const o of e.querySelectorAll(".sapMText"))if(!o.closest(`[${$}]`)&&o.parentElement)return o.parentElement;const t=e.querySelector(".sapMHBox");if(t)return t;const n=e.querySelector(".sapMVBox");return n||e.querySelector(".sapUiTableCellInner")||e}function Sn(e){for(const n of e.querySelectorAll(".sapMText")){const o=(n.textContent||"").trim(),r=O(o);if(r)return r}return O((e.textContent||"").trim())}async function kn(e){try{await navigator.clipboard.writeText(e)}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",document.body.appendChild(t),t.select(),document.execCommand("copy"),t.remove()}}function En(e,t,n){const o=Tn(e);let r=e.querySelector(`[${$}="row"]`);if(r&&r.dataset.booking===t&&r.dataset.room===n)return r.parentElement!==o&&o.appendChild(r),r;r?(r.dataset.booking=t,r.dataset.room=n,r.parentElement!==o&&o.appendChild(r)):(r=document.createElement("span"),r.setAttribute($,"row"),r.dataset.booking=t,r.dataset.room=n,o.appendChild(r)),r.innerHTML="";const a=document.createElement("span");a.className="pb-ra-row-hint",a.textContent="→",a.setAttribute("aria-hidden","true");const i=document.createElement("button");i.type="button",i.className="pb-ra-row-code";const l=n.padStart(4,"0");return i.textContent=l,i.title=`${g.emmaRoom.title}: ${l}`,i.setAttribute("aria-label",`${g.emmaRoom.title} ${l}`),i.addEventListener("click",s=>{s.preventDefault(),s.stopPropagation(),kn(l)}),r.appendChild(a),r.appendChild(i),r}function Bn(){var r;const e=xn();if(!e){document.querySelectorAll(`[${$}="row"]`).forEach(a=>a.remove());return}const t=wn(e),n=e.querySelectorAll("tbody tr.sapUiTableContentRow, tbody tr.sapUiTableTr"),o=new Set;for(const a of n){const i=$n(a);if(!i)continue;const l=Le(a,t.room),s=Le(a,t.arrival);if(!l)continue;const c=Cn(l),p=s?Sn(s):null;if(c||!Pe(p)){(r=l.querySelector(`[${$}="row"]`))==null||r.remove();continue}const b=we(i,"default",null),C=En(l,i,b.roomNumber);o.add(C)}e.querySelectorAll(`[${$}="row"]`).forEach(a=>{a instanceof HTMLElement&&!o.has(a)&&a.remove()})}function me(){var e;(e=document.getElementById(m))==null||e.remove(),I=null,v=null,B=!1,P="",Q=!1}async function Mn(){const e=Ke(),t=dn();if(!t||!e){me();return}if(!pn()){me();return}const n=hn(t),o=`${e}:empty`;if(o!==I||!v||!n.querySelector(".pb-ra-room")){const r=!I||!I.startsWith(`${e}:`);I=o,(r||!v)&&(B=!1,P="",Q=!1,v=we(e,"default",null)),ie(n)}}async function Qe(){if(!an()){me(),document.querySelectorAll(`[${$}="row"]`).forEach(e=>e.remove());return}bn(),Bn(),await Mn()}function V(){Z&&window.clearTimeout(Z),Z=window.setTimeout(()=>{Qe()},350)}function In(){J().then(t=>{g=T(t),I=null,V()}),ee(t=>{g=T(t),I=null,V()}),Qe(),window.addEventListener("hashchange",()=>{I=null,v=null,V()});const e=new MutationObserver(t=>{for(const n of t){const o=n.target;if(!(o instanceof Element&&(o.id===m||o.id===pe||o.closest(`[${$}]`)))){V();return}}});return e.observe(document.documentElement,{childList:!0,subtree:!0}),()=>{var t;e.disconnect(),Z&&window.clearTimeout(Z),me(),document.querySelectorAll(`[${$}="row"]`).forEach(n=>n.remove()),(t=document.getElementById(pe))==null||t.remove()}}const Ae="prize-panel-host";let M=T("de");function Je(){return`<img src="${chrome.runtime.getURL("PrizeByRadisson.png")}" alt="Prize by Radisson Bern" style="width:28px;height:auto;max-height:34px;object-fit:contain;filter:brightness(0) invert(1);pointer-events:none" />`}function se(e,t,n){const o=`${le}px 0 0 ${le}px`;n?(e.style.width="0",e.style.opacity="0",e.style.pointerEvents="none",t.style.display="flex",t.innerHTML=Je(),t.title=M.inject.openPanel,t.setAttribute("aria-label",M.inject.openPanel),t.setAttribute("aria-expanded","false")):(e.style.width=`${_e}px`,e.style.opacity="1",e.style.pointerEvents="auto",t.style.display="none",t.title=M.inject.panelTitle,t.setAttribute("aria-expanded","true")),e.style.borderRadius=o,t.style.borderRadius=o}async function Re(e,t,n){var i;const r=!await ye(L.panelCollapsed);await ot({[L.panelCollapsed]:r}),se(e,t,r);const a=e.querySelector("iframe");(i=a==null?void 0:a.contentWindow)==null||i.postMessage({type:r?N.collapsed:N.expanded},"*")}function qe(){if(document.getElementById(Ae))return;let e=!1,t=!0;const n=()=>e&&!t,o=`${le}px 0 0 ${le}px`,r=document.createElement("div");r.id=Ae,Object.assign(r.style,{position:"fixed",top:"50%",right:"0",transform:"translateY(-50%)",zIndex:"2147483646",display:"flex",flexDirection:"row",alignItems:"center",pointerEvents:"none",fontFamily:"system-ui, sans-serif"});const a=document.createElement("div");a.id="prize-panel-shell",Object.assign(a.style,{height:`${tt}px`,maxHeight:"min(72vh, 500px)",overflow:"hidden",background:oe,border:`1px solid ${be}`,borderRight:"none",borderRadius:o,boxShadow:"-4px 0 24px rgba(26, 35, 50, 0.22), -1px 0 0 rgba(45, 58, 79, 0.5)",transition:"width 220ms cubic-bezier(0.4, 0, 0.2, 1), opacity 220ms cubic-bezier(0.4, 0, 0.2, 1)",pointerEvents:"auto"});const i=document.createElement("iframe");i.id="prize-panel-iframe",i.src=chrome.runtime.getURL("src/panel/index.html"),i.title=M.inject.panelTitle,Object.assign(i.style,{width:`${_e}px`,height:"100%",border:"none",display:"block",background:oe}),a.appendChild(i);const l=document.createElement("button");l.id="prize-panel-tab",l.type="button",Object.assign(l.style,{width:`${Te}px`,height:`${nt}px`,minWidth:`${Te}px`,border:`1px solid ${be}`,borderRight:"none",background:`linear-gradient(180deg, ${oe} 0%, #141c28 100%)`,color:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",borderRadius:o,boxShadow:"-4px 0 20px rgba(26, 35, 50, 0.25)",transition:"filter 150ms ease, transform 150ms ease",pointerEvents:"auto"}),l.innerHTML=Je(),l.addEventListener("mouseenter",()=>{l.style.filter="brightness(1.12)"}),l.addEventListener("mouseleave",()=>{l.style.filter=""}),l.addEventListener("click",()=>{Re(a,l)}),r.appendChild(a),r.appendChild(l),document.documentElement.appendChild(r),ye(L.panelCollapsed).then(s=>{t=s,se(a,l,s)}),window.addEventListener("message",s=>{var c,p,b,C;((c=s.data)==null?void 0:c.type)===N.toggle&&Re(a,l),((p=s.data)==null?void 0:p.type)===N.chatOpen&&(e=!0,n()&&((b=document.getElementById("prize-panel-chat-toast"))==null||b.remove())),((C=s.data)==null?void 0:C.type)===N.chatClosed&&(e=!1)}),chrome.storage.onChanged.addListener((s,c)=>{c==="local"&&s[L.panelCollapsed]&&(t=!!s[L.panelCollapsed].newValue)}),$t(n),Dt(),on(),In(),J().then(s=>{M=T(s),se(a,l,t),i.title=M.inject.panelTitle}),ee(s=>{M=T(s),se(a,l,t),i.title=M.inject.panelTitle})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",qe):qe();
